let currentHost = null;
let currentLang = 'ru';

// --- ПЕРЕВОДЫ ДЛЯ СТРАНИЦЫ НАСТРОЕК ---
const i18nOpt = {
    ru: {
        title: "Сохраненные сайты", empty: "Выберите сайт из списка слева", noStyles: "Нет сохраненных стилей",
        save: "Сохранить изменения", saved: "Сохранено!", delete: "Удалить стиль", insert: "Вставить",
        localFile: "Локальный файл (file://)", confirmDelete: "Удалить стили для: ",
        options: {
            "default": "⚡ Добавить скрипт-разрешение...",
            "keep-awake": "🛑 Не давать вкладке засыпать (для ботов в фоне)",
            "anti-spy": "🛡️ Анти-шпион (Заблокировать трекеры)",
            "enable-copy": "🔓 Разблокировать правый клик и выделение",
            "kill-alerts": "🚫 Блокировать всплывающие окна (alert/confirm)",
            "unlock-scroll": "↕️ Разблокировать прокрутку страницы",
            "remove-overlays": "🖼️ Анти-Paywall (удалить размытие и панели)",
            "speed-timers": "⏳ Ускорить таймеры на сайте (x10)",
            "auto-refresh": "🔄 Автообновление вкладки (каждые 60 сек)"
        }
    },
    en: {
        title: "Saved Sites", empty: "Select a site from the left list", noStyles: "No saved styles",
        save: "Save Changes", saved: "Saved!", delete: "Delete Style", insert: "Insert",
        localFile: "Local file (file://)", confirmDelete: "Delete styles for: ",
        options: {
            "default": "⚡ Add script permission...",
            "keep-awake": "🛑 Keep Awake (prevent sleeping for bots)",
            "anti-spy": "🛡️ Anti-Spy (Block trackers & analytics)",
            "enable-copy": "🔓 Unlock right-click and selection",
            "kill-alerts": "🚫 Block popups (alert/confirm)",
            "unlock-scroll": "↕️ Unlock page scrolling",
            "remove-overlays": "🖼️ Anti-Paywall (remove blurs and overlays)",
            "speed-timers": "⏳ Speed up site timers (x10)",
            "auto-refresh": "🔄 Auto-refresh tab (every 60s)"
        }
    }
};

function applyTranslations() {
    document.getElementById('opt-title').textContent = i18nOpt[currentLang].title;
    document.getElementById('empty-state').textContent = i18nOpt[currentLang].empty;
    document.getElementById('btn-save').textContent = i18nOpt[currentLang].save;
    document.getElementById('btn-delete').textContent = i18nOpt[currentLang].delete;
    document.getElementById('btn-insert-template').textContent = i18nOpt[currentLang].insert;

    const select = document.getElementById('template-select');
    select.innerHTML = `
        <option value="">${i18nOpt[currentLang].options["default"]}</option>
        <option value="keep-awake">${i18nOpt[currentLang].options["keep-awake"]}</option>
        <option value="anti-spy">${i18nOpt[currentLang].options["anti-spy"]}</option>
        <option value="enable-copy">${i18nOpt[currentLang].options["enable-copy"]}</option>
        <option value="kill-alerts">${i18nOpt[currentLang].options["kill-alerts"]}</option>
        <option value="unlock-scroll">${i18nOpt[currentLang].options["unlock-scroll"]}</option>
        <option value="remove-overlays">${i18nOpt[currentLang].options["remove-overlays"]}</option>
        <option value="speed-timers">${i18nOpt[currentLang].options["speed-timers"]}</option>
        <option value="auto-refresh">${i18nOpt[currentLang].options["auto-refresh"]}</option>
    `;
}

// Инициализация при загрузке страницы настроек
chrome.storage.local.get(['lang'], (res) => {
    currentLang = res.lang || (navigator.language.startsWith('ru') ? 'ru' : 'en');
    applyTranslations();
    
    // Читаем адрес сайта из URL (переданный из popup.js)
    const urlParams = new URLSearchParams(window.location.search);
    const targetHost = urlParams.get('host');
    
    chrome.storage.local.get(null, (items) => {
        // Если сайт передан и для него уже есть сохраненные стили или флаги - открываем его
        if (targetHost && (items[targetHost] !== undefined || items[targetHost + '_disabled'] !== undefined)) {
            openEditor(targetHost, items[targetHost] || "");
        } else {
            // Если изменений не было или мы открыли настройки вручную - показываем пустую страницу
            loadSites();
        }
    });
});

function loadSites() {
    chrome.storage.local.get(null, (items) => {
        const siteList = document.getElementById('site-list');
        siteList.innerHTML = '';
        
        // Отфильтровываем служебные системные переменные (vsi_*), lang и статусы отключения
        const hosts = Object.keys(items).filter(k => 
            !k.endsWith('_disabled') && 
            k !== 'lang' && 
            !k.startsWith('vsi_')
        );

        if (hosts.length === 0) {
            siteList.innerHTML = `<div style="padding: 15px; color: #666; text-align: center;">${i18nOpt[currentLang].noStyles}</div>`;
            return;
        }

        hosts.forEach(host => {
            const isEnabled = !items[host + '_disabled'];
            const displayHost = host === "" ? i18nOpt[currentLang].localFile : host;
            
            const div = document.createElement('div');
            div.className = `site-item ${currentHost === host ? 'active' : ''}`;
            div.innerHTML = `
                <span style="word-break: break-all; padding-right: 10px;">${displayHost}</span>
                <span class="status-badge ${isEnabled ? 'status-on' : 'status-off'}" style="cursor: pointer;">${isEnabled ? 'ON' : 'OFF'}</span>
            `;
            
            const badge = div.querySelector('.status-badge');
            badge.addEventListener('click', (e) => {
                e.stopPropagation(); 
                chrome.storage.local.set({[host + '_disabled']: isEnabled}, () => loadSites());
            });

            div.addEventListener('click', () => openEditor(host, items[host]));
            siteList.appendChild(div);
        });
    });
}

function openEditor(host, css) {
    currentHost = host;
    const displayHost = host === "" ? i18nOpt[currentLang].localFile : host;
    document.getElementById('empty-state').style.display = 'none';
    document.getElementById('active-editor').style.display = 'flex';
    document.getElementById('current-site-title').textContent = displayHost;
    document.getElementById('css-editor').value = css || '';
    loadSites(); 
}

// РУЧНОЕ СОХРАНЕНИЕ
document.getElementById('btn-save').addEventListener('click', () => {
    if (currentHost === null) return;
    const newCss = document.getElementById('css-editor').value;
    chrome.storage.local.set({[currentHost]: newCss}, () => {
        const btn = document.getElementById('btn-save');
        btn.textContent = i18nOpt[currentLang].saved;
        setTimeout(() => btn.textContent = i18nOpt[currentLang].save, 1500);
    });
});

// --- ЖИВОЙ ПРЕДПРОСМОТР (АВТОСОХРАНЕНИЕ) ---
let autoSaveTimeout = null;
document.getElementById('css-editor').addEventListener('input', (e) => {
    if (currentHost === null) return;
    
    clearTimeout(autoSaveTimeout);
    const newCss = e.target.value;
    
    // Ждем 300мс после последнего нажатия клавиши, чтобы не спамить сохранением
    autoSaveTimeout = setTimeout(() => {
        chrome.storage.local.set({[currentHost]: newCss}, () => {
            // Визуально мигаем кнопкой сохранения, чтобы было понятно, что изменения применены
            const btn = document.getElementById('btn-save');
            btn.textContent = "⚡ " + i18nOpt[currentLang].saved;
            btn.style.background = "#2E7D32"; // Темно-зеленый
            
            setTimeout(() => { 
                if (btn.textContent.includes("⚡")) {
                    btn.textContent = i18nOpt[currentLang].save; 
                    btn.style.background = "#4CAF50"; // Возвращаем обычный зеленый
                }
            }, 1000);
        });
    }, 300);
});

// УДАЛЕНИЕ СТИЛЯ
document.getElementById('btn-delete').addEventListener('click', () => {
    if (currentHost === null) return;
    const displayHost = currentHost === "" ? i18nOpt[currentLang].localFile : currentHost;
    // Используем правильный перевод для диалогового окна
    if (confirm(`${i18nOpt[currentLang].confirmDelete}${displayHost}?`)) {
        chrome.storage.local.remove([currentHost, currentHost + '_disabled'], () => {
            currentHost = null;
            document.getElementById('empty-state').style.display = 'flex';
            document.getElementById('active-editor').style.display = 'none';
            loadSites();
        });
    }
});

// ВСТАВКА ШАБЛОНОВ (Скрипты-разрешения)
document.getElementById('btn-insert-template').addEventListener('click', () => {
    const select = document.getElementById('template-select');
    const val = select.value;
    if (!val) return;

    const textarea = document.getElementById('css-editor');
    
    const titleText = i18nOpt[currentLang].options[val].toUpperCase();
    const template = `\n/* ======================================= */\n/* ${titleText} */\n/* ======================================= */\n/* @action: ${val} */\n`;

    const startPos = textarea.selectionStart;
    const endPos = textarea.selectionEnd;
    textarea.value = textarea.value.substring(0, startPos) + template + textarea.value.substring(endPos);
    
    textarea.selectionStart = startPos + template.length;
    textarea.selectionEnd = startPos + template.length;
    textarea.focus();
    
    // Вызываем событие 'input' принудительно, чтобы сработало наше новое автосохранение
    textarea.dispatchEvent(new Event('input'));
    
    select.value = ''; 
});

chrome.storage.onChanged.addListener((changes, area) => {
    // Проверяем, не вызваны ли изменения нами же (при автосохранении), 
    // чтобы не перерисовывать левое меню зря и не сбивать фокус.
    if (area === 'local' && changes[currentHost] === undefined) {
        loadSites();
    }
});