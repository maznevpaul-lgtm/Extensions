const host = window.location.hostname;
const myFrameToken = Math.random().toString(36).substring(2);

let isPickerActive = false;
let isVisualMode = false;
let hoveredElement = null;
let selectedElement = null; 

let draggedElement = null;
let isDragging = false;
let isResizing = false;
let hasMoved = false; 
let dragStartX, dragStartY;
let initialTransformX = 0, initialTransformY = 0;
let initialWidth = 0, initialHeight = 0; 

let cssHistory = [];
let activeHacks = new Set();
let currentLang = 'ru';

const i18n = {
    ru: {
        msgVisual: "ВИЗУАЛЬНЫЙ РЕЖИМ ВКЛЮЧЕН!\n\n👉 КЛИКНИТЕ на элемент, чтобы открыть Инспектор стилей.\n👉 Кликните в пустое место (фон), чтобы снять выделение.\n👉 ТЯНИТЕ, чтобы переместить.\n👉 Нажмите ALT, чтобы пробить прозрачные слои.",
        text: "Текст", background: "Фон", border: "Рамка", shadow: "Тень", layer: "Слой",
        textSize: "Размер (px)", textColor: "Цвет",
        linkColor: "Цвет Ссылок", boldColor: "Цвет Жирного", italicColor: "Цвет Курсива",
        bgColor: "Цвет", bgOpacity: "Прозрачн.",
        radius: "Скругление", bdWidth: "Толщина", bdStyle: "Тип", bdColor: "Цвет", bdOpacity: "Прозрачн.",
        shX: "Смещение X", shY: "Смещение Y", shBlur: "Размытие", shColor: "Цвет",
        zIndex: "Позиция (Z)", opacity: "Прозрачность",
        solid: "Сплошная", dashed: "Пунктир", dotted: "Точки", none: "Нет",
        selectPrompt: "Кликните на элемент на сайте", tagPrefix: "Выбран: ",
        deleteBtn: "Удалить элемент (Del)"
    },
    en: {
        msgVisual: "VISUAL MODE ENABLED!\n\n👉 CLICK an element to open Style Inspector.\n👉 Click background to deselect.\n👉 DRAG to move.\n👉 Press ALT to pierce transparent overlays.",
        text: "Text", background: "Back", border: "Border", shadow: "Shadow", layer: "Layer",
        textSize: "Size (px)", textColor: "Color",
        linkColor: "Link Color", boldColor: "Bold Color", italicColor: "Italic Color",
        bgColor: "Color", bgOpacity: "Opacity",
        radius: "Radius", bdWidth: "Width", bdStyle: "Style", bdColor: "Color", bdOpacity: "Opacity",
        shX: "Offset X", shY: "Offset Y", shBlur: "Blur", shColor: "Color",
        zIndex: "Z-Index", opacity: "Opacity",
        solid: "Solid", dashed: "Dashed", dotted: "Dotted", none: "None",
        selectPrompt: "Click an element on the site", tagPrefix: "Selected: ",
        deleteBtn: "Delete element (Del)"
    }
};

let customStyleTag = document.createElement('style');
customStyleTag.id = 'style-injector-custom-css';

let tempStyleTag = document.createElement('style');
tempStyleTag.id = 'style-injector-temp-css';

function appendTags() {
    if (document.head) {
        if (!document.getElementById('style-injector-custom-css')) document.head.appendChild(customStyleTag);
        if (!document.getElementById('style-injector-temp-css')) document.head.appendChild(tempStyleTag);
    }
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', appendTags);
} else {
    appendTags();
}

function applyStyles() {
    chrome.storage.local.get([host, host + '_disabled'], (result) => {
        if (result[host] && !result[host + '_disabled']) {
            customStyleTag.textContent = result[host];
            const hacks = ['keep-awake', 'enable-copy', 'kill-alerts', 'unlock-scroll', 'remove-overlays', 'speed-timers', 'auto-refresh', 'anti-spy'];
            hacks.forEach(hack => {
                if (result[host].includes(`@action: ${hack}`) && !activeHacks.has(hack)) {
                    applyHack(hack);
                    activeHacks.add(hack);
                }
            });
        } else {
            customStyleTag.textContent = '';
        }
    });
}

applyStyles();
chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local') {
        if (changes[host] || changes[host + '_disabled']) applyStyles();
        
        if (changes.vsi_force_exit) {
            exitModes();
        }

        if (changes.vsi_active_frame) {
            const activeToken = changes.vsi_active_frame.newValue;
            const myToken = window === window.top ? 'top' : myFrameToken;

            if (activeToken === myToken) {
                if (floatingToolbar && isVisualMode) {
                    floatingToolbar.style.setProperty('display', 'flex', 'important');
                }
            } else {
                if (floatingToolbar) {
                    floatingToolbar.style.setProperty('display', 'none', 'important');
                }
                if (selectedElement) {
                    selectedElement.classList.remove('style-injector-selected');
                    selectedElement = null;
                    const tagDisplay = document.getElementById('vsi-element-tag');
                    if (tagDisplay) tagDisplay.textContent = i18n[currentLang].selectPrompt;
                }
            }
        }
    }
});


chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    sendResponse({status: "ok"}); 
    chrome.storage.local.get(['lang'], (res) => {
        currentLang = res.lang || (navigator.language.startsWith('ru') ? 'ru' : 'en');
        if (request.action === "togglePicker") {
            exitModes(); 
            isPickerActive = true; isVisualMode = false;
            document.documentElement.style.cursor = 'crosshair';
            if (window === window.top) showFloatingToolbar();
        }
        if (request.action === "toggleVisualMode") {
            exitModes(); 
            isVisualMode = true; isPickerActive = false;
            document.documentElement.style.cursor = 'default';
            if (window === window.top) {
                alert(i18n[currentLang].msgVisual);
                showFloatingToolbar();
                chrome.storage.local.set({ vsi_active_frame: 'top' });
            }
        }
    });
});

function isExtensionUI(el) {
    if (!el || !el.closest) return false;
    return el.closest('#style-injector-editor-container') || el.closest('#style-injector-toolbar');
}

// --- УМНАЯ ПАНЕЛЬ ИНСТРУМЕНТОВ ---
let floatingToolbar = null;

function showFloatingToolbar() {
    let toolbar = document.getElementById('style-injector-toolbar');
    if (toolbar) toolbar.remove(); 

    const t = i18n[currentLang];

    toolbar = document.createElement('div');
    toolbar.id = 'style-injector-toolbar';
    floatingToolbar = toolbar;
    
    toolbar.innerHTML = `
        <style>
            #style-injector-toolbar {
                position: fixed !important; top: 20px !important; right: 20px !important; 
                z-index: 2147483647 !important; background: #1e1e1ef0 !important; backdrop-filter: blur(10px) !important; 
                padding: 15px !important; border-radius: 12px !important; box-shadow: 0 10px 40px rgba(0,0,0,0.7) !important;
                font-family: sans-serif !important; border: 1px solid #444 !important; 
                width: ${isVisualMode ? '300px' : 'auto'} !important; 
                color: white !important; display: flex !important; flex-direction: column !important;
            }
            .vsi-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: ${isVisualMode ? '12px' : '0'}; cursor: grab; padding-bottom: ${isVisualMode ? '10px' : '0'}; border-bottom: ${isVisualMode ? '1px solid #444' : 'none'}; }
            .vsi-header button { border: none; border-radius: 4px; font-weight: bold; cursor: pointer; height: 28px; display: flex; align-items: center; justify-content: center; transition: 0.2s; }
            
            #vsi-btn-undo { background: #FF9800; color: white; width: 28px; font-size: 16px; opacity: 0.5; cursor: not-allowed; border-radius: 50%; }
            #vsi-btn-delete { background: #555; color: white; width: 28px; font-size: 14px; border-radius: 4px; }
            #vsi-btn-delete:hover { background: #f44336; }
            #vsi-btn-esc { background: #f44336; color: white; padding: 0 12px; font-size: 12px;}
            #vsi-btn-esc:hover { background: #da190b; }
            
            #vsi-element-tag { font-size: 12px; color: #4CAF50; font-family: monospace; text-align: center; margin-bottom: 10px; word-break: break-all; background: #00000040; padding: 5px; border-radius: 4px; }
            
            .vsi-tabs { display: flex; background: #333; border-radius: 6px; overflow: hidden; margin-bottom: 15px; }
            .vsi-tab { flex: 1; padding: 8px 0; text-align: center; font-size: 11px; color: #ccc; cursor: pointer; border: none; background: transparent; font-weight: bold; }
            .vsi-tab.active { background: #2196F3; color: white; }
            
            .vsi-tab-content { display: none; flex-direction: column; gap: 12px; font-size: 12px; }
            .vsi-tab-content.active { display: flex; }
            
            .vsi-row { display: flex; justify-content: space-between; align-items: center; gap: 10px; }
            .vsi-row span { width: 85px; color: #bbb; }
            .vsi-row input[type="range"] { flex: 1; cursor: pointer; }
            .vsi-row input[type="number"] { width: 45px; background: #111; border: 1px solid #555; color: white; padding: 4px; border-radius: 4px; text-align: center; }
            .vsi-row input[type="color"] { width: 45px; height: 26px; border: none; background: none; cursor: pointer; padding: 0; }
            .vsi-row select { flex: 1; background: #111; border: 1px solid #555; color: white; padding: 4px; border-radius: 4px; outline: none; }
            
            .vsi-icon-btn { flex: 1; background: #333; color: white; border: 1px solid #555; border-radius: 4px; padding: 5px 0; cursor: pointer; font-size: 14px; }
            .vsi-icon-btn:hover { background: #444; }
            .vsi-icon-btn.active { background: #4CAF50; border-color: #4CAF50; }
        </style>

        <div class="vsi-header" id="vsi-drag-handle" title="Drag to move">
            <span style="font-size: 14px; color: #888; margin-right: 10px;">⠿</span>
            <div style="display: flex; gap: 5px;">
                <button id="vsi-btn-undo" title="Undo (Отмена)">↺</button>
                <!-- ДОБАВЛЕНА КНОПКА УДАЛЕНИЯ -->
                <button id="vsi-btn-delete" title="${t.deleteBtn}">🗑️</button>
                <button id="vsi-btn-esc" title="Exit">ESC</button>
            </div>
        </div>

        ${isVisualMode ? `
        <div id="vsi-style-editor">
            <div id="vsi-element-tag">${t.selectPrompt}</div>
            
            <div class="vsi-tabs">
                <button class="vsi-tab active" data-tab="text">${t.text}</button>
                <button class="vsi-tab" data-tab="background">${t.background}</button>
                <button class="vsi-tab" data-tab="border">${t.border}</button>
                <button class="vsi-tab" data-tab="shadow">${t.shadow}</button>
                <button class="vsi-tab" data-tab="layer">${t.layer}</button>
            </div>

            <!-- ТЕКСТ -->
            <div class="vsi-tab-content active" id="tab-text">
                <div class="vsi-row">
                    <span>${t.textSize}</span>
                    <input type="range" id="vsi-txt-s-r" min="8" max="100" value="16">
                    <input type="number" id="vsi-txt-s-n" value="16">
                </div>
                <div class="vsi-row">
                    <span>${t.textColor}</span>
                    <input type="color" id="vsi-txt-c" value="#000000">
                </div>
                <div class="vsi-row" style="margin-top: 5px;">
                    <button class="vsi-icon-btn" id="vsi-btn-bold" style="font-weight:bold;">B</button>
                    <button class="vsi-icon-btn" id="vsi-btn-italic" style="font-style:italic; font-family:serif;">I</button>
                    <div style="width: 10px;"></div>
                    <button class="vsi-icon-btn" id="vsi-btn-align-l" title="Left">⇤</button>
                    <button class="vsi-icon-btn" id="vsi-btn-align-c" title="Center">⇹</button>
                    <button class="vsi-icon-btn" id="vsi-btn-align-r" title="Right">⇥</button>
                </div>
                <!-- ДОПОЛНИТЕЛЬНЫЕ ЦВЕТА (ССЫЛКИ, ЖИРНЫЙ, КУРСИВ) -->
                <hr style="border: 0; border-top: 1px solid #444; width: 100%; margin: 5px 0;">
                <div class="vsi-row">
                    <span>${t.linkColor}</span>
                    <input type="color" id="vsi-txt-a-c" value="#000000">
                </div>
                <div class="vsi-row">
                    <span>${t.boldColor}</span>
                    <input type="color" id="vsi-txt-b-c" value="#000000">
                </div>
                <div class="vsi-row">
                    <span>${t.italicColor}</span>
                    <input type="color" id="vsi-txt-i-c" value="#000000">
                </div>
            </div>

            <!-- ФОН -->
            <div class="vsi-tab-content" id="tab-background">
                <div class="vsi-row">
                    <span>${t.bgColor}</span>
                    <input type="color" id="vsi-bg-c" value="#ffffff">
                </div>
                <div class="vsi-row">
                    <span>${t.bgOpacity}</span>
                    <input type="range" id="vsi-bg-op-r" min="0" max="1" step="0.05" value="1">
                    <input type="number" id="vsi-bg-op-n" step="0.05" value="1">
                </div>
            </div>

            <!-- РАМКА И СКРУГЛЕНИЕ -->
            <div class="vsi-tab-content" id="tab-border">
                <div class="vsi-row">
                    <span>${t.radius}</span>
                    <input type="range" id="vsi-rad-r" min="0" max="100" value="0">
                    <input type="number" id="vsi-rad-n" value="0">
                </div>
                <hr style="border: 0; border-top: 1px solid #444; width: 100%; margin: 5px 0;">
                <div class="vsi-row">
                    <span>${t.bdWidth}</span>
                    <input type="range" id="vsi-bdw-r" min="0" max="30" value="0">
                    <input type="number" id="vsi-bdw-n" value="0">
                </div>
                <div class="vsi-row">
                    <span>${t.bdStyle}</span>
                    <select id="vsi-bds">
                        <option value="solid">${t.solid}</option>
                        <option value="dashed">${t.dashed}</option>
                        <option value="dotted">${t.dotted}</option>
                        <option value="none">${t.none}</option>
                    </select>
                </div>
                <div class="vsi-row">
                    <span>${t.bdColor}</span>
                    <input type="color" id="vsi-bdc" value="#ff0000">
                </div>
                <div class="vsi-row">
                    <span>${t.bdOpacity}</span>
                    <input type="range" id="vsi-bd-op-r" min="0" max="1" step="0.05" value="1">
                    <input type="number" id="vsi-bd-op-n" step="0.05" value="1">
                </div>
            </div>

            <!-- ТЕНЬ -->
            <div class="vsi-tab-content" id="tab-shadow">
                <div class="vsi-row">
                    <span>${t.shX}</span>
                    <input type="range" id="vsi-shx-r" min="-50" max="50" value="0">
                    <input type="number" id="vsi-shx-n" value="0">
                </div>
                <div class="vsi-row">
                    <span>${t.shY}</span>
                    <input type="range" id="vsi-shy-r" min="-50" max="50" value="0">
                    <input type="number" id="vsi-shy-n" value="0">
                </div>
                <div class="vsi-row">
                    <span>${t.shBlur}</span>
                    <input type="range" id="vsi-shb-r" min="0" max="100" value="0">
                    <input type="number" id="vsi-shb-n" value="0">
                </div>
                <div class="vsi-row">
                    <span>${t.shColor}</span>
                    <input type="color" id="vsi-shc" value="#000000">
                </div>
            </div>

            <!-- СЛОИ И ПРОЗРАЧНОСТЬ ЭЛЕМЕНТА -->
            <div class="vsi-tab-content" id="tab-layer">
                <div class="vsi-row">
                    <span>${t.zIndex}</span>
                    <input type="range" id="vsi-z-r" min="-999" max="999" value="0">
                    <input type="number" id="vsi-z-n" value="0">
                </div>
                <div class="vsi-row">
                    <span>${t.opacity}</span>
                    <input type="range" id="vsi-elop-r" min="0" max="1" step="0.05" value="1">
                    <input type="number" id="vsi-elop-n" step="0.05" value="1">
                </div>
            </div>
        </div>
        ` : ''}
    `;

    document.documentElement.appendChild(toolbar);

    toolbar.addEventListener('mouseenter', () => document.body.classList.add('vsi-hide-selection'));
    toolbar.addEventListener('mouseleave', () => document.body.classList.remove('vsi-hide-selection'));

    document.getElementById('vsi-btn-undo').onclick = (e) => { e.stopPropagation(); undoLastAction(); };
    
    // ЛОГИКА НОВОЙ КНОПКИ "УДАЛИТЬ"
    document.getElementById('vsi-btn-delete').onclick = (e) => {
        e.stopPropagation();
        if (!selectedElement) {
            alert(t.selectPrompt);
            return;
        }

        const elTag = selectedElement.tagName.toLowerCase();
        if (elTag === 'body' || elTag === 'html') { alert("Запрещено удалять весь документ целиком!"); return; }
        if (elTag === 'iframe') { if (!confirm("Вы выделили всё ОКНО (iframe) целиком. Точно удалить его?\n\nЧтобы выделить кнопки ВНУТРИ него, наведите мышку и нажмите ALT!")) return; }

        savePropertyToCSS({'display': 'none'}, '🛑 СКРЫТИЕ ЭЛЕМЕНТА / HIDE', "", selectedElement);
        
        selectedElement.classList.remove('style-injector-selected');
        selectedElement = null;
        
        const tagDisplay = document.getElementById('vsi-element-tag');
        if (tagDisplay) tagDisplay.textContent = t.selectPrompt;
        
        if (window !== window.top && floatingToolbar) {
            floatingToolbar.style.setProperty('display', 'none', 'important');
        }
    };

    document.getElementById('vsi-btn-esc').onclick = (e) => { 
        e.stopPropagation(); 
        exitModes(); 
        chrome.storage.local.set({ vsi_force_exit: Math.random() });
    };

    const handle = document.getElementById('vsi-drag-handle');
    handle.onmousedown = function(event) {
        const isInteractive = ['BUTTON', 'INPUT', 'SELECT', 'OPTION'].includes(event.target.tagName);
        if (isInteractive) return;
        event.preventDefault();

        const currentToolbar = document.getElementById('style-injector-toolbar');
        if (!currentToolbar) return;

        let rect = currentToolbar.getBoundingClientRect();
        let shiftX = event.clientX - rect.left;
        let shiftY = event.clientY - rect.top;

        function moveAt(pageX, pageY) {
            if (!currentToolbar) return;
            currentToolbar.style.setProperty('left', (pageX - shiftX) + 'px', 'important');
            currentToolbar.style.setProperty('top', (pageY - shiftY) + 'px', 'important');
            currentToolbar.style.setProperty('right', 'auto', 'important'); 
            currentToolbar.style.setProperty('bottom', 'auto', 'important');
        }

        function onMouseMove(event) { moveAt(event.clientX, event.clientY); }
        document.addEventListener('mousemove', onMouseMove);
        document.onmouseup = function() {
            document.removeEventListener('mousemove', onMouseMove);
            document.onmouseup = null;
        };
    };

    const tabs = toolbar.querySelectorAll('.vsi-tab');
    const contents = toolbar.querySelectorAll('.vsi-tab-content');
    if (tabs.length > 0) {
        tabs.forEach(tab => {
            tab.onclick = () => {
                tabs.forEach(t => t.classList.remove('active'));
                contents.forEach(c => c.classList.remove('active'));
                tab.classList.add('active');
                document.getElementById(`tab-${tab.dataset.tab}`).classList.add('active');
            };
        });
        initPanelControls();
    }

    updateUndoButtonState();
}

function rgbaToHexOp(colorStr) {
    if (!colorStr) return { hex: '#000000', op: 1 };
    let m = colorStr.match(/^rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)$/);
    if (m) {
        let r = parseInt(m[1]).toString(16).padStart(2, '0');
        let g = parseInt(m[2]).toString(16).padStart(2, '0');
        let b = parseInt(m[3]).toString(16).padStart(2, '0');
        return { hex: `#${r}${g}${b}`, op: m[4] !== undefined ? parseFloat(m[4]) : 1 };
    }
    if (colorStr.startsWith('#')) {
        if (colorStr.length === 4) {
            let r = colorStr[1] + colorStr[1];
            let g = colorStr[2] + colorStr[2];
            let b = colorStr[3] + colorStr[3];
            return { hex: `#${r}${g}${b}`, op: 1 };
        }
        return { hex: colorStr.slice(0, 7), op: 1 };
    }
    return { hex: '#000000', op: 1 };
}

function hexToRgba(hex, alpha) {
    let r, g, b;
    if (hex.length === 4) {
        r = parseInt(hex[1] + hex[1], 16);
        g = parseInt(hex[2] + hex[2], 16);
        b = parseInt(hex[3] + hex[3], 16);
    } else {
        r = parseInt(hex.slice(1, 3), 16);
        g = parseInt(hex.slice(3, 5), 16);
        b = parseInt(hex.slice(5, 7), 16);
    }
    return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

function updatePanelFromElement(el) {
    if (!el || !document.getElementById('style-injector-toolbar')) return;
    const style = window.getComputedStyle(el);

    let fSize = parseFloat(style.fontSize) || 16;
    document.getElementById('vsi-txt-s-r').value = fSize; document.getElementById('vsi-txt-s-n').value = fSize;
    let cColor = rgbaToHexOp(style.color);
    document.getElementById('vsi-txt-c').value = cColor.hex;
    
    let isBold = style.fontWeight === 'bold' || parseInt(style.fontWeight) >= 700;
    document.getElementById('vsi-btn-bold').classList.toggle('active', isBold);
    document.getElementById('vsi-btn-italic').classList.toggle('active', style.fontStyle === 'italic');

    ['vsi-btn-align-l','vsi-btn-align-c','vsi-btn-align-r'].forEach(i => document.getElementById(i).classList.remove('active'));
    if (style.textAlign === 'center') document.getElementById('vsi-btn-align-c').classList.add('active');
    else if (style.textAlign === 'right') document.getElementById('vsi-btn-align-r').classList.add('active');
    else document.getElementById('vsi-btn-align-l').classList.add('active');

    let aElem = el.querySelector('a');
    document.getElementById('vsi-txt-a-c').value = aElem ? rgbaToHexOp(window.getComputedStyle(aElem).color).hex : cColor.hex;
    let bElem = el.querySelector('b, strong');
    document.getElementById('vsi-txt-b-c').value = bElem ? rgbaToHexOp(window.getComputedStyle(bElem).color).hex : cColor.hex;
    let iElem = el.querySelector('i, em');
    document.getElementById('vsi-txt-i-c').value = iElem ? rgbaToHexOp(window.getComputedStyle(iElem).color).hex : cColor.hex;

    let bg = rgbaToHexOp(style.backgroundColor);
    document.getElementById('vsi-bg-c').value = bg.hex;
    document.getElementById('vsi-bg-op-r').value = bg.op; document.getElementById('vsi-bg-op-n').value = bg.op;

    let rad = parseFloat(style.borderRadius) || 0;
    document.getElementById('vsi-rad-r').value = rad; document.getElementById('vsi-rad-n').value = rad;

    let bw = parseFloat(style.borderWidth) || 0;
    document.getElementById('vsi-bdw-r').value = bw; document.getElementById('vsi-bdw-n').value = bw;

    let bs = style.borderStyle.split(' ')[0]; 
    if ((bs === 'none' || bs === '') && bw > 0) bs = 'solid';
    let bdsElem = document.getElementById('vsi-bds');
    if(bdsElem.querySelector(`option[value="${bs}"]`)) bdsElem.value = bs;
    else bdsElem.value = 'none';

    let bc = rgbaToHexOp(style.borderColor);
    document.getElementById('vsi-bdc').value = bc.hex;
    document.getElementById('vsi-bd-op-r').value = bc.op; document.getElementById('vsi-bd-op-n').value = bc.op;

    let sh = style.boxShadow;
    if (sh && sh !== 'none') {
        let m = sh.match(/(rgba?\([^)]+\)|#[0-9a-fA-F]+)\s+(-?\d+)px\s+(-?\d+)px\s+(\d+)px/);
        if (m) {
            let sc = rgbaToHexOp(m[1]);
            document.getElementById('vsi-shc').value = sc.hex;
            document.getElementById('vsi-shx-r').value = m[2]; document.getElementById('vsi-shx-n').value = m[2];
            document.getElementById('vsi-shy-r').value = m[3]; document.getElementById('vsi-shy-n').value = m[3];
            document.getElementById('vsi-shb-r').value = m[4]; document.getElementById('vsi-shb-n').value = m[4];
        }
    } else {
        document.getElementById('vsi-shx-r').value = 0; document.getElementById('vsi-shx-n').value = 0;
        document.getElementById('vsi-shy-r').value = 0; document.getElementById('vsi-shy-n').value = 0;
        document.getElementById('vsi-shb-r').value = 0; document.getElementById('vsi-shb-n').value = 0;
    }

    let z = style.zIndex;
    z = (z === 'auto' || isNaN(parseInt(z))) ? 0 : parseInt(z);
    document.getElementById('vsi-z-r').value = z; document.getElementById('vsi-z-n').value = z;

    let op = style.opacity;
    op = (op === '' || isNaN(parseFloat(op))) ? 1 : parseFloat(op);
    document.getElementById('vsi-elop-r').value = op; document.getElementById('vsi-elop-n').value = op;
}

function syncInput(rangeId, numId, callback) {
    const range = document.getElementById(rangeId);
    const num = document.getElementById(numId);
    if(!range || !num) return;
    range.addEventListener('input', () => { num.value = range.value; callback(false); });
    num.addEventListener('input', () => { range.value = num.value; callback(false); });
    range.addEventListener('change', () => { callback(true); });
    num.addEventListener('change', () => { callback(true); });
}

function initPanelControls() {
    syncInput('vsi-txt-s-r', 'vsi-txt-s-n', (save) => {
        if(!selectedElement) return;
        let val = document.getElementById('vsi-txt-s-r').value + 'px';
        if (save) savePropertyToCSS({'font-size': val}, 'ТЕКСТ РАЗМЕР / FONT SIZE');
        else selectedElement.style.setProperty('font-size', val, 'important'); 
    });
    
    const updateTextColor = (save) => {
        if(!selectedElement) return;
        let val = document.getElementById('vsi-txt-c').value;
        if(save) savePropertyToCSS({'color': val}, 'ТЕКСТ ЦВЕТ / TEXT COLOR');
        else selectedElement.style.setProperty('color', val, 'important');
    };
    document.getElementById('vsi-txt-c').addEventListener('input', () => updateTextColor(false));
    document.getElementById('vsi-txt-c').addEventListener('change', () => updateTextColor(true));

    const bindToggle = (id, prop, v1, v2, comment) => {
        document.getElementById(id).onclick = function() {
            if(!selectedElement) return;
            let current = window.getComputedStyle(selectedElement)[prop];
            let newVal = (current === v1 || current.includes(v1) || (current === '700' && v1 === 'bold')) ? v2 : v1;
            savePropertyToCSS({[prop]: newVal}, comment);
            this.classList.toggle('active');
        };
    };
    bindToggle('vsi-btn-bold', 'font-weight', 'bold', 'normal', 'ЖИРНЫЙ / BOLD');
    bindToggle('vsi-btn-italic', 'font-style', 'italic', 'normal', 'КУРСИВ / ITALIC');

    const bindAlign = (id, val) => {
        document.getElementById(id).onclick = function() {
            if(!selectedElement) return;
            savePropertyToCSS({'text-align': val}, 'ВЫРАВНИВАНИЕ / ALIGN');
            ['vsi-btn-align-l','vsi-btn-align-c','vsi-btn-align-r'].forEach(i => document.getElementById(i).classList.remove('active'));
            this.classList.add('active');
        };
    };
    bindAlign('vsi-btn-align-l', 'left'); bindAlign('vsi-btn-align-c', 'center'); bindAlign('vsi-btn-align-r', 'right');

    const updateNestedColor = (id, selector, comment, save) => {
        if(!selectedElement) return;
        let val = document.getElementById(id).value;
        let base = generateSelector(selectedElement);
        if(save) {
            tempStyleTag.textContent = '';
            savePropertyToCSS({'color': val}, comment, selector);
        } else {
            let fullSelector = selector.split(',').map(s => `${base} ${s.trim()}`).join(', ');
            tempStyleTag.textContent = `${fullSelector} { color: ${val} !important; }`;
        }
    };
    document.getElementById('vsi-txt-a-c').addEventListener('input', () => updateNestedColor('vsi-txt-a-c', 'a', 'ЦВЕТ ССЫЛОК / LINK COLOR', false));
    document.getElementById('vsi-txt-a-c').addEventListener('change', () => updateNestedColor('vsi-txt-a-c', 'a', 'ЦВЕТ ССЫЛОК / LINK COLOR', true));
    document.getElementById('vsi-txt-b-c').addEventListener('input', () => updateNestedColor('vsi-txt-b-c', 'b, strong', 'ЦВЕТ ЖИРНОГО / BOLD COLOR', false));
    document.getElementById('vsi-txt-b-c').addEventListener('change', () => updateNestedColor('vsi-txt-b-c', 'b, strong', 'ЦВЕТ ЖИРНОГО / BOLD COLOR', true));
    document.getElementById('vsi-txt-i-c').addEventListener('input', () => updateNestedColor('vsi-txt-i-c', 'i, em', 'ЦВЕТ КУРСИВА / ITALIC COLOR', false));
    document.getElementById('vsi-txt-i-c').addEventListener('change', () => updateNestedColor('vsi-txt-i-c', 'i, em', 'ЦВЕТ КУРСИВА / ITALIC COLOR', true));

    const updateBg = (save) => {
        if(!selectedElement) return;
        let hex = document.getElementById('vsi-bg-c').value;
        let op = document.getElementById('vsi-bg-op-r').value;
        let rgba = hexToRgba(hex, op);
        if (save) savePropertyToCSS({'background-color': rgba}, 'ФОН / BACKGROUND');
        else selectedElement.style.setProperty('background-color', rgba, 'important');
    };
    document.getElementById('vsi-bg-c').addEventListener('input', () => updateBg(false));
    document.getElementById('vsi-bg-c').addEventListener('change', () => updateBg(true));
    syncInput('vsi-bg-op-r', 'vsi-bg-op-n', updateBg);

    syncInput('vsi-rad-r', 'vsi-rad-n', (save) => {
        if(!selectedElement) return;
        let val = document.getElementById('vsi-rad-r').value + 'px';
        if (save) savePropertyToCSS({'border-radius': val}, 'РАДИУС / RADIUS');
        else selectedElement.style.setProperty('border-radius', val, 'important');
    });

    const updateBorder = (save) => {
        if(!selectedElement) return;
        let w = document.getElementById('vsi-bdw-r').value;
        let s = document.getElementById('vsi-bds').value;
        let hex = document.getElementById('vsi-bdc').value;
        let op = document.getElementById('vsi-bd-op-r').value;
        let rgba = hexToRgba(hex, op);
        let val = `${w}px ${s} ${rgba}`;
        if (save) savePropertyToCSS({'border': val}, 'РАМКА / BORDER');
        else selectedElement.style.setProperty('border', val, 'important');
    };
    syncInput('vsi-bdw-r', 'vsi-bdw-n', updateBorder);
    syncInput('vsi-bd-op-r', 'vsi-bd-op-n', updateBorder);
    document.getElementById('vsi-bds').addEventListener('change', () => updateBorder(true));
    document.getElementById('vsi-bdc').addEventListener('input', () => updateBorder(false));
    document.getElementById('vsi-bdc').addEventListener('change', () => updateBorder(true));

    const updateShadow = (save) => {
        if(!selectedElement) return;
        let x = document.getElementById('vsi-shx-r').value;
        let y = document.getElementById('vsi-shy-r').value;
        let b = document.getElementById('vsi-shb-r').value;
        let c = document.getElementById('vsi-shc').value;
        let val = `${x}px ${y}px ${b}px ${c}`;
        if (save) savePropertyToCSS({'box-shadow': val}, 'ТЕНЬ / SHADOW');
        else selectedElement.style.setProperty('box-shadow', val, 'important');
    };
    syncInput('vsi-shx-r', 'vsi-shx-n', updateShadow);
    syncInput('vsi-shy-r', 'vsi-shy-n', updateShadow);
    syncInput('vsi-shb-r', 'vsi-shb-n', updateShadow);
    document.getElementById('vsi-shc').addEventListener('input', () => updateShadow(false));
    document.getElementById('vsi-shc').addEventListener('change', () => updateShadow(true));

    const updateLayer = (save) => {
        if(!selectedElement) return;
        let z = document.getElementById('vsi-z-r').value;
        let op = document.getElementById('vsi-elop-r').value;
        
        let needsRelative = window.getComputedStyle(selectedElement).position === 'static';
        
        if (needsRelative) selectedElement.style.setProperty('position', 'relative', 'important');
        selectedElement.style.setProperty('z-index', z, 'important');
        selectedElement.style.setProperty('opacity', op, 'important');
        
        if (save) {
            let propsToSave = { 'z-index': z, 'opacity': op };
            if (needsRelative) propsToSave['position'] = 'relative';
            savePropertyToCSS(propsToSave, 'СЛОИ И ПРОЗРАЧНОСТЬ / LAYER & OPACITY');
        }
    };
    syncInput('vsi-z-r', 'vsi-z-n', updateLayer);
    syncInput('vsi-elop-r', 'vsi-elop-n', updateLayer);
}

function savePropertyToCSS(propsObj, comment, suffix = "", targetEl = null) {
    let el = targetEl || selectedElement;
    if (!el) return;
    saveToHistory();
    
    const baseSelector = generateSelector(el);
    let fullSelector = baseSelector;
    
    if (suffix) {
        fullSelector = suffix.split(',').map(s => `${baseSelector} ${s.trim()}`).join(', ');
    }
    
    let currentCss = customStyleTag.textContent || "";
    
    for (let prop in propsObj) {
        if (!suffix) el.style.removeProperty(prop); 
    }
    
    let escapedSelector = fullSelector.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
    let blockRegex = new RegExp(`(^|[\\s\\}])(${escapedSelector}\\s*\\{)([^}]*)(\\})`, 'g');
    
    let appliedProps = new Set();
    
    let newCss = currentCss.replace(blockRegex, (match, prefix, openBrace, inner, closeBrace) => {
        for (let prop in propsObj) {
            let propRegex = new RegExp(`(${prop}\\s*:)[^;]+(;|$)`, 'g');
            if (propRegex.test(inner)) {
                inner = inner.replace(propRegex, `$1 ${propsObj[prop]} !important$2`);
            } else {
                inner = inner.replace(/\s+$/, '') + `\n  ${prop}: ${propsObj[prop]} !important;\n`;
            }
            appliedProps.add(prop);
        }
        return prefix + openBrace + inner + closeBrace;
    });
    
    let newRules = [];
    for (let prop in propsObj) {
        if (!appliedProps.has(prop)) {
            newRules.push(`  ${prop}: ${propsObj[prop]} !important;`);
        }
    }
    
    if (newRules.length > 0) {
        let actionComment = comment ? `\n/* 🎨 ${comment} */` : "";
        newCss += `${actionComment}\n${fullSelector} {\n${newRules.join('\n')}\n}`;
    }
    
    customStyleTag.textContent = newCss;
    chrome.storage.local.set({ [host]: newCss });
}

function selectElement(el) {
    chrome.storage.local.set({ vsi_active_frame: window === window.top ? 'top' : myFrameToken });
    
    if (!document.getElementById('style-injector-toolbar')) {
        showFloatingToolbar();
    } else if (floatingToolbar) {
        floatingToolbar.style.setProperty('display', 'flex', 'important');
    }

    if (selectedElement) selectedElement.classList.remove('style-injector-selected');
    selectedElement = el;
    selectedElement.classList.add('style-injector-selected');
    
    const tagDisplay = document.getElementById('vsi-element-tag');
    if (tagDisplay) {
        let name = el.tagName.toLowerCase();
        if (el.id) name += `#${el.id}`;
        else if (el.className && typeof el.className === 'string') name += `.${el.className.split(' ')[0]}`;
        tagDisplay.textContent = i18n[currentLang].tagPrefix + name;
    }
    
    updatePanelFromElement(el);
}

function saveToHistory() {
    cssHistory.push(customStyleTag.textContent || "");
    updateUndoButtonState();
}

function undoLastAction() {
    if (cssHistory.length > 0) {
        customStyleTag.textContent = cssHistory.pop();
        chrome.storage.local.set({ [host]: customStyleTag.textContent });
        updateUndoButtonState();
        
        setTimeout(() => {
            if (selectedElement) updatePanelFromElement(selectedElement);
        }, 50);
    }
}

function updateUndoButtonState() {
    const btnUndo = document.getElementById('vsi-btn-undo');
    if (btnUndo) {
        if (cssHistory.length > 0) {
            btnUndo.style.setProperty('opacity', '1', 'important');
            btnUndo.style.setProperty('cursor', 'pointer', 'important');
            btnUndo.style.setProperty('background', '#FF9800', 'important'); 
        } else {
            btnUndo.style.setProperty('opacity', '0.5', 'important');
            btnUndo.style.setProperty('cursor', 'not-allowed', 'important');
            btnUndo.style.setProperty('background', '#555', 'important');
        }
    }
}

function exitModes() {
    isPickerActive = false;
    isVisualMode = false;
    document.documentElement.style.cursor = ''; 
    document.body.classList.remove('vsi-hide-selection'); 
    tempStyleTag.textContent = ''; 
    
    if (hoveredElement) {
        hoveredElement.classList.remove('style-injector-hover-target', 'style-injector-visual-hover', 'style-injector-active-element');
        hoveredElement = null;
    }
    if (draggedElement) {
        draggedElement.classList.remove('style-injector-visual-hover', 'style-injector-active-element');
        draggedElement = null;
    }
    if (selectedElement) {
        selectedElement.classList.remove('style-injector-selected');
        selectedElement = null;
    }
    if (floatingToolbar) {
        floatingToolbar.remove();
        floatingToolbar = null;
    }
    const editor = document.getElementById('style-injector-editor-container');
    if (editor) {
        chrome.storage.local.get([host], (result) => {
            customStyleTag.textContent = result[host] || "";
            editor.remove();
        });
    }
}

// --- ЛОГИКА МЫШИ ---
document.addEventListener('mouseover', (e) => {
    if (isExtensionUI(e.target)) return; 
    if (isDragging || isResizing) return; 

    if (isPickerActive || isVisualMode) {
        if (hoveredElement && hoveredElement !== e.target) {
            hoveredElement.classList.remove('style-injector-hover-target', 'style-injector-visual-hover');
        }
        hoveredElement = e.target;
        if (isPickerActive) hoveredElement.classList.add('style-injector-hover-target');
        if (isVisualMode && hoveredElement !== selectedElement) hoveredElement.classList.add('style-injector-visual-hover');
    }
});

document.addEventListener('mouseout', (e) => {
    if (isExtensionUI(e.target)) return;
    if (isDragging || isResizing) return; 

    if (!e.relatedTarget && hoveredElement) {
        hoveredElement.classList.remove('style-injector-hover-target', 'style-injector-visual-hover');
        hoveredElement = null;
    }
});

document.addEventListener('click', (e) => {
    if (isExtensionUI(e.target)) return; 
    if (isVisualMode) { e.preventDefault(); e.stopPropagation(); return; }
    if (!isPickerActive) return;

    e.preventDefault(); e.stopPropagation();
    isPickerActive = false;
    document.documentElement.style.cursor = ''; 
    
    if (hoveredElement) hoveredElement.classList.remove('style-injector-hover-target');
    if (selectedElement) {
        selectedElement.classList.remove('style-injector-selected');
        selectedElement = null;
    }

    showEditor(generateSelector(e.target));
}, true);

document.addEventListener('mousedown', (e) => {
    if (isExtensionUI(e.target)) return;
    if (isPickerActive) { e.preventDefault(); e.stopPropagation(); return; }
    if (!isVisualMode) return;

    chrome.storage.local.set({ vsi_active_frame: window === window.top ? 'top' : myFrameToken });

    draggedElement = e.target;
    hasMoved = false; 
    
    draggedElement.classList.add('style-injector-active-element');

    const rect = draggedElement.getBoundingClientRect();
    const isResizeHandle = (e.clientX > rect.right - 18) && (e.clientY > rect.bottom - 18);

    if (isResizeHandle) {
        e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
        isResizing = true;
        dragStartX = e.clientX; dragStartY = e.clientY;
        initialWidth = draggedElement.offsetWidth; initialHeight = draggedElement.offsetHeight;
    } else {
        e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
        isDragging = true;
        dragStartX = e.clientX; dragStartY = e.clientY;

        const style = window.getComputedStyle(draggedElement);
        const transform = style.transform;
        initialTransformX = 0; initialTransformY = 0;
        if (transform && transform !== 'none') {
            try {
                const matrix = new DOMMatrixReadOnly(transform);
                initialTransformX = matrix.m41; initialTransformY = matrix.m42;
            } catch(err) {}
        }
    }
}, true);

document.addEventListener('mousemove', (e) => {
    if (!isVisualMode) return;
    
    if (isDragging || isResizing) {
        if (Math.abs(e.clientX - dragStartX) > 3 || Math.abs(e.clientY - dragStartY) > 3) {
            hasMoved = true;
        }
    }

    if (isDragging && draggedElement && hasMoved) {
        const dx = e.clientX - dragStartX; const dy = e.clientY - dragStartY;
        draggedElement.style.setProperty('transform', `translate(${initialTransformX + dx}px, ${initialTransformY + dy}px)`, 'important');
    } else if (isResizing && draggedElement && hasMoved) {
        const dx = e.clientX - dragStartX; const dy = e.clientY - dragStartY;
        draggedElement.style.setProperty('width', (initialWidth + dx) + 'px', 'important');
        draggedElement.style.setProperty('height', (initialHeight + dy) + 'px', 'important');
    }
});

document.addEventListener('mouseup', (e) => {
    if (isExtensionUI(e.target)) return;
    if (isPickerActive) { e.preventDefault(); e.stopPropagation(); return; }
    
    if (isVisualMode && draggedElement) {
        if (!hasMoved && !isResizing) {
            const elTag = draggedElement.tagName.toLowerCase();
            if (selectedElement === draggedElement || elTag === 'body' || elTag === 'html') {
                if (selectedElement) selectedElement.classList.remove('style-injector-selected');
                selectedElement = null;
                const tagDisplay = document.getElementById('vsi-element-tag');
                if (tagDisplay) tagDisplay.textContent = i18n[currentLang].selectPrompt;
                
                if (window !== window.top) {
                    if (floatingToolbar) floatingToolbar.style.setProperty('display', 'none', 'important');
                    chrome.storage.local.set({ vsi_active_frame: 'top' });
                }
            } else {
                selectElement(draggedElement);
            }
        } 
        else if (hasMoved) {
            if (isDragging) {
                const dx = e.clientX - dragStartX; const dy = e.clientY - dragStartY;
                savePropertyToCSS({'transform': `translate(${initialTransformX + dx}px, ${initialTransformY + dy}px)`}, '↕️ ПЕРЕМЕЩЕНИЕ / DRAG', "", draggedElement);
            } else if (isResizing) {
                const width = initialWidth + (e.clientX - dragStartX); const height = initialHeight + (e.clientY - dragStartY);
                savePropertyToCSS({'width': `${width}px`, 'height': `${height}px`}, '↔️ РАЗМЕР / RESIZE', "", draggedElement);
            }
        }

        draggedElement.classList.remove('style-injector-visual-hover', 'style-injector-active-element');
    }

    isDragging = false; isResizing = false; hasMoved = false;
    draggedElement = null;
}, true);


let ignoredElements = []; 

document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') { 
        exitModes(); 
        chrome.storage.local.set({ vsi_force_exit: Math.random() });
        return; 
    }
    
    if (e.key === 'Alt' && !e.repeat && (isVisualMode || isPickerActive) && hoveredElement) {
        e.preventDefault();
        hoveredElement.classList.add('style-injector-ignore-pointer');
        hoveredElement.classList.remove('style-injector-hover-target', 'style-injector-visual-hover', 'style-injector-active-element');
        ignoredElements.push(hoveredElement);
        hoveredElement = null; 
        return;
    }

    if (!isVisualMode) return;
    
    let targetToDelete = hoveredElement || selectedElement;

    if ((e.key === 'Delete' || e.key === 'Backspace') && targetToDelete) {
        const activeTag = document.activeElement ? document.activeElement.tagName.toLowerCase() : '';
        if (activeTag === 'input' || activeTag === 'textarea' || document.activeElement.isContentEditable) return;

        const elTag = targetToDelete.tagName.toLowerCase();
        if (elTag === 'body' || elTag === 'html') { alert("Запрещено удалять весь документ целиком!"); return; }
        if (elTag === 'iframe') { if (!confirm("Вы выделили всё ОКНО (iframe) целиком. Точно удалить его?\n\nЧтобы выделить кнопки ВНУТРИ него, наведите мышку и нажмите ALT!")) return; }

        e.preventDefault();
        savePropertyToCSS({'display': 'none'}, '🛑 СКРЫТИЕ ЭЛЕМЕНТА / HIDE', "", targetToDelete);
        
        targetToDelete.classList.remove('style-injector-visual-hover', 'style-injector-active-element', 'style-injector-selected');
        if (targetToDelete === hoveredElement) hoveredElement = null;
        if (targetToDelete === selectedElement) {
            selectedElement = null;
            const tagDisplay = document.getElementById('vsi-element-tag');
            if (tagDisplay) tagDisplay.textContent = i18n[currentLang].selectPrompt;
            
            if (window !== window.top && floatingToolbar) {
                floatingToolbar.style.setProperty('display', 'none', 'important');
            }
        }
    }
});

document.addEventListener('keyup', (e) => {
    if (e.key === 'Alt') {
        ignoredElements.forEach(el => el.classList.remove('style-injector-ignore-pointer'));
        ignoredElements = [];
    }
});

window.addEventListener('blur', () => {
    ignoredElements.forEach(el => el.classList.remove('style-injector-ignore-pointer'));
    ignoredElements = [];
    if (draggedElement) draggedElement.classList.remove('style-injector-active-element');
});

function generateSelector(el) {
    if (!el || el.nodeType !== 1) return '';
    if (el.id) return `#${el.id}`;
    
    let tag = el.tagName.toLowerCase();
    let classes = [];
    if (el.className && typeof el.className === 'string') {
        classes = el.className.split(/\s+/).filter(c => c && !c.includes('style-injector'));
    }
    if (classes.length > 0) return `${tag}.${classes.join('.')}`;
    
    let path = [];
    let current = el;
    while (current && current.nodeType === 1 && current.tagName.toLowerCase() !== 'body') {
        let curTag = current.tagName.toLowerCase();
        if (current.id) { path.unshift(`#${current.id}`); break; }
        let curClasses = [];
        if (current.className && typeof current.className === 'string') curClasses = current.className.split(/\s+/).filter(c => c && !c.includes('style-injector'));
        let selectorPart = curTag;
        if (curClasses.length > 0) {
            selectorPart += `.${curClasses[0]}`; path.unshift(selectorPart); break;
        } else {
            let nth = 1; let sibling = current;
            while ((sibling = sibling.previousElementSibling)) nth++;
            selectorPart += `:nth-child(${nth})`; path.unshift(selectorPart);
        }
        current = current.parentNode;
    }
    return path.join(' > ');
}

function showEditor(initialSelector) {
    const existing = document.getElementById('style-injector-editor-container');
    if (existing) existing.remove();

    const container = document.createElement('div');
    container.id = 'style-injector-editor-container';

    let textToInsert = customStyleTag.textContent || "";
    if (initialSelector && !textToInsert.includes(initialSelector)) {
        textToInsert += `\n\n/* ✏️ РУЧНОЕ РЕДАКТИРОВАНИЕ */\n${initialSelector} {\n` +
        `  /* display: none !important; */\n` +
        `  /* z-index: 9999 !important; position: relative !important; */\n` +
        `  /* transform: translate(50px, 50px) !important; */\n` +
        `  /* width: 400px !important; height: 200px !important; */\n` +
        `  /* background-color: #ffcccc !important; */\n` +
        `  /* color: #ff0000 !important; */\n` +
        `}`;
    }

    container.innerHTML = `
        <h4>Редактор CSS: ${host}</h4>
        <textarea id="style-injector-textarea" spellcheck="false">${textToInsert.trim()}</textarea>
        <div class="buttons">
            <button id="style-injector-btn-close">Закрыть</button>
            <button id="style-injector-btn-save">Сохранить</button>
        </div>
    `;

    document.documentElement.appendChild(container);
    document.getElementById('style-injector-btn-save').addEventListener('click', function() {
        saveToHistory(); 
        chrome.storage.local.set({ [host]: document.getElementById('style-injector-textarea').value }, () => {
            this.textContent = "Сохранено!"; this.style.background = "#2E7D32";
            setTimeout(() => { this.textContent = "Сохранить"; this.style.background = "#4CAF50"; }, 1500);
        });
    });
    document.getElementById('style-injector-btn-close').addEventListener('click', () => {
        chrome.storage.local.get([host], (result) => { customStyleTag.textContent = result[host] || ""; container.remove(); });
    });
}

function applyHack(hackName) {
    window.dispatchEvent(new CustomEvent('VSI_INIT_HACK', { detail: hackName }));
    if (hackName === 'enable-copy') {
        const style = document.createElement('style'); style.textContent = `* { user-select: auto !important; -webkit-user-select: auto !important; }`; (document.head || document.documentElement).appendChild(style);
    } else if (hackName === 'unlock-scroll') {
        const style = document.createElement('style'); style.textContent = `html, body { overflow: auto !important; position: static !important; }`; (document.head || document.documentElement).appendChild(style);
    }
}