const host = window.location.hostname;
const myFrameToken = Math.random().toString(36).substring(2);

let isPickerActive = false;
let isVisualMode = false;
let hoveredElement = null;
let selectedElements = new Set(); 
let elementsToDrag = new Set(); 

let draggedElement = null;
let isDragging = false;
let isResizing = false;
let hasMoved = false; 
let dragStartX, dragStartY;

let initialMatrices = new Map();
let initialSizes = new Map(); 
let activeSelectors = new Map(); 

// Переменные для умного прилипания
let snapTargets = []; 
let origDragRects = new Map();
let lastSnappedDx = 0;
let lastSnappedDy = 0;

let cssHistory = [];
let activeHacks = new Set();
let currentLang = 'ru';

// Функция проверки "живости" расширения
function isContextValid() {
    try {
        return typeof chrome !== 'undefined' && chrome.runtime && !!chrome.runtime.id;
    } catch (err) {
        return false;
    }
}

const i18n = {
    ru: {
        msgVisual: "ВИЗУАЛЬНЫЙ РЕЖИМ ВКЛЮЧЕН!\n\n👉 КЛИКНИТЕ на элемент, чтобы выбрать.\n👉 SHIFT + КЛИК для выделения нескольких.\n👉 Оранжевый маркер ✥ — Перемещение.\n👉 Синий маркер ⤡ — Растягивание.\n👉 Нажмите ALT, чтобы пробить слои.",
        tabText: "Текст", tabDesign: "Дизайн", tabBorder: "Рамки", tabSize: "Размер", tabLayout: "Макет", tabOptions: "Опции",
        categoryBg: "Заливка фона", categoryShadow: "Тень элемента", categoryOpacity: "Прозрачность слоя",
        categoryPos: "Позиционирование (Слои)", categoryDim: "Габариты", categoryBehavior: "Поведение контента",
        categoryModel: "Модель отображения", categoryGrid: "Сетки и перестановка", categoryTable: "Таблицы",
        categoryInteract: "Взаимодействие", categoryTools: "Умные инструменты",
        catNested: "Цвета вложенных элементов", catBorderStroke: "Обводка", catBorderRadius: "Радиус углов",
        textSize: "Размер (px)", textColor: "Цвет",
        linkColor: "Цвет Ссылок", boldColor: "Цвет Жирного", italicColor: "Цвет Курсива",
        bgColor: "Цвет", bgOpacity: "Прозрачн.",
        radius: "Скругление", bdWidth: "Толщина", bdStyle: "Тип", bdColor: "Цвет", bdOpacity: "Прозрачн.",
        shX: "Смещение X", shY: "Смещение Y", shBlur: "Размытие", shColor: "Цвет",
        zIndex: "Z-Индекс", opacity: "Прозрачность",
        display: "Вид", wrap: "Текст", overflow: "Контент", resize: "Растягивание", pointer: "Клики",
        width: "Ширина", height: "Высота", tableLayout: "Сетка табл.", borderCol: "Рамки ячеек", vAlign: "Выравн. (Y)",
        order: "Порядок", gridCols: "Колонки (Grid)", editText: "Редактор текста", position: "Позиция", snap: "Прилипание", dragUnits: "Единицы", unitsPx: "Пиксели (px)", unitsVw: "Проценты (vw/vh)",
        solid: "Сплошная", dashed: "Пунктир", dotted: "Точки", none: "Нет",
        selectPrompt: "Кликните на элемент на сайте", tagPrefix: "Выбран: ",
        deleteBtn: "Удалить элементы (Del)",
        optStd: "(стандарт)", optOff: "(выкл)", optOn: "(вкл)",
        optSmart: "Умное (Smart)", optGrid10: "Сетка 10px", optFree: "Выкл (Свободно)",
        optBlock: "Блок (block)", optInlBlock: "Строчно-блоч.", optHidden: "Скрыт (none)",
        optWrapNorm: "Переносить", optWrapNo: "В одну строку", optWrapPre: "С сохранением",
        optOverVis: "Видимый", optOverHid: "Обрезать (hidden)", optOverAuto: "Скролл (auto)",
        optResBoth: "Во все стороны", optResVert: "По вертикали", optResNone: "Запретить",
        optPosStat: "Статич. (static)", optPosRel: "Относит. (rel)", optPosAbs: "Абсолют. (abs)", optPosFix: "Фикс. (fixed)",
        optValBase: "Базовая (baseline)", optValTop: "По верхнему краю", optValMid: "По центру", optValBot: "По нижнему краю",
        optTblAuto: "Авто (auto)", optTblFix: "Фиксированная",
        optBdSep: "Раздельно (separate)", optBdCol: "Слитно (collapse)",
        optPeAuto: "Кликабельно", optPeNone: "Сквозной (none)",
        optEdMod: "Текст (read-write)", optEdArea: "Поле (в Textarea)",
        ttPos: "Для свободного перемещения выберите Абсолют. или Фикс.",
        ttGrid: "Например: 1fr 1fr (две колонки) или repeat(4, 1fr) (четыре колонки)",
        ttEdit: "Настраивает редактирование элементов. Сохраняется навсегда!",
        ttSnap: "Умные направляющие для выравнивания (как в Figma)",
        ttUnits: "Адаптивные единицы измерения (в процентах от экрана) для перетаскивания и изменения размеров",
        ttDrag: "Перетащите, чтобы переместить панель",
        btnUndo: "Отмена (Undo)", btnEsc: "Выйти (ESC)",
        alertUpdate: "Расширение было обновлено в панели разработчика!\nПожалуйста, обновите эту страницу (F5), чтобы продолжить работу.",
        confirmIframe: "Вы выделили всё ОКНО (iframe) целиком. Точно удалить его?",
        alertTextarea: "Чтобы вернуть однострочное поле, обновите страницу (F5).",
        editorTitle: "Редактор CSS:", editorClose: "Закрыть", editorSave: "Сохранить", editorSaved: "Сохранено!", editorManual: "✏️ РУЧНОЕ РЕДАКТИРОВАНИЕ"
    },
    en: {
        msgVisual: "VISUAL MODE ENABLED!\n\n👉 CLICK an element to select.\n👉 SHIFT + CLICK for multi-selection.\n👉 Orange ✥ — Move element.\n👉 Blue ⤡ — Resize element.\n👉 Press ALT to pierce transparent overlays.",
        tabText: "Text", tabDesign: "Design", tabBorder: "Border", tabSize: "Size", tabLayout: "Layout", tabOptions: "Options",
        categoryBg: "Background Fill", categoryShadow: "Element Shadow", categoryOpacity: "Layer Opacity",
        categoryPos: "Positioning (Layers)", categoryDim: "Dimensions", categoryBehavior: "Content Behavior",
        categoryModel: "Display Model", categoryGrid: "Grids & Order", categoryTable: "Tables",
        categoryInteract: "Interaction", categoryTools: "Smart Tools",
        catNested: "Nested Element Colors", catBorderStroke: "Stroke", catBorderRadius: "Corner Radius",
        textSize: "Size (px)", textColor: "Color",
        linkColor: "Link Color", boldColor: "Bold Color", italicColor: "Italic Color",
        bgColor: "Color", bgOpacity: "Opacity",
        radius: "Radius", bdWidth: "Width", bdStyle: "Style", bdColor: "Color", bdOpacity: "Opacity",
        shX: "Offset X", shY: "Offset Y", shBlur: "Blur", shColor: "Color",
        zIndex: "Z-Index", opacity: "Opacity",
        display: "Display", wrap: "Wrap", overflow: "Overflow", resize: "Resize", pointer: "Clicks",
        width: "Width", height: "Height", tableLayout: "Table Layout", borderCol: "Border Col.", vAlign: "V-Align",
        order: "Order", gridCols: "Grid Cols", editText: "Edit Text", position: "Position", snap: "Snapping", dragUnits: "Units", unitsPx: "Pixels (px)", unitsVw: "Percent (vw/vh)",
        solid: "Solid", dashed: "Dashed", dotted: "Dotted", none: "None",
        selectPrompt: "Click an element on the site", tagPrefix: "Selected: ",
        deleteBtn: "Delete elements (Del)",
        optStd: "(default)", optOff: "(off)", optOn: "(on)",
        optSmart: "Smart", optGrid10: "10px Grid", optFree: "Off (Free)",
        optBlock: "Block", optInlBlock: "Inline-Block", optHidden: "Hidden (none)",
        optWrapNorm: "Wrap", optWrapNo: "No Wrap", optWrapPre: "Pre-wrap",
        optOverVis: "Visible", optOverHid: "Hidden", optOverAuto: "Scroll (auto)",
        optResBoth: "Both", optResVert: "Vertical", optResNone: "None",
        optPosStat: "Static", optPosRel: "Relative", optPosAbs: "Absolute", optPosFix: "Fixed",
        optValBase: "Baseline", optValTop: "Top", optValMid: "Middle", optValBot: "Bottom",
        optTblAuto: "Auto", optTblFix: "Fixed",
        optBdSep: "Separate", optBdCol: "Collapse",
        optPeAuto: "Clickable", optPeNone: "Pass-through (none)",
        optEdMod: "Text (read-write)", optEdArea: "Box (Textarea)",
        ttPos: "Choose Absolute or Fixed for free dragging",
        ttGrid: "E.g.: 1fr 1fr (two columns) or repeat(4, 1fr) (four columns)",
        ttEdit: "Enables element editing. Saved permanently!",
        ttSnap: "Smart alignment guides (like in Figma)",
        ttUnits: "Adaptive units (% of screen) for dragging and resizing",
        ttDrag: "Drag to move panel",
        btnUndo: "Undo", btnEsc: "Exit (ESC)",
        alertUpdate: "The extension was updated in the developer panel!\nPlease refresh this page (F5) to continue.",
        confirmIframe: "You have selected the entire WINDOW (iframe). Are you sure you want to delete it?",
        alertTextarea: "Refresh the page (F5) to revert to a single-line input.",
        editorTitle: "CSS Editor:", editorClose: "Close", editorSave: "Save", editorSaved: "Saved!", editorManual: "✏️ MANUAL EDIT"
    }
};

let customStyleTag = document.createElement('style');
customStyleTag.id = 'style-injector-custom-css';

let tempStyleTag = document.createElement('style');
tempStyleTag.id = 'style-injector-temp-css';

function appendTags() {
    if (document.head) {
        if (!document.getElementById('style-injector-custom-css')) document.head.appendChild(customStyleTag);
        if (!document.getElementById('style-injector-temp-css')) document.head.appendChild(tempStyleTag);
        
        if (!document.getElementById('style-injector-grab-fix')) {
            let grabFixStyle = document.createElement('style');
            grabFixStyle.id = 'style-injector-grab-fix';
            grabFixStyle.textContent = `
                .style-injector-visual-hover, 
                .style-injector-active-element,
                .style-injector-selected {
                    position: relative !important; 
                }
                body .style-injector-visual-hover, 
                body .style-injector-active-element,
                body .style-injector-selected {
                    overflow: visible !important;
                }
            `;
            document.head.appendChild(grabFixStyle);
        }

        if (!document.getElementById('vsi-move-handle')) {
            let mh = document.createElement('div');
            mh.id = 'vsi-move-handle';
            mh.innerHTML = '✥';
            mh.style.cssText = 'position: fixed; width: 24px; height: 24px; background: #FF5722; color: white; border-radius: 50%; display: none; align-items: center; justify-content: center; font-size: 14px; cursor: move; z-index: 2147483647; box-shadow: 0 2px 5px rgba(0,0,0,0.3); pointer-events: auto; line-height: 1; margin: 0; padding: 0; box-sizing: border-box; font-family: sans-serif;';
            document.documentElement.appendChild(mh);
        }
        if (!document.getElementById('vsi-resize-handle')) {
            let rh = document.createElement('div');
            rh.id = 'vsi-resize-handle';
            rh.innerHTML = '⤡';
            rh.style.cssText = 'position: fixed; width: 24px; height: 24px; background: #2196F3; color: white; border-radius: 50%; display: none; align-items: center; justify-content: center; font-size: 14px; cursor: nwse-resize; z-index: 2147483647; box-shadow: 0 2px 5px rgba(0,0,0,0.3); pointer-events: auto; line-height: 1; margin: 0; padding: 0; box-sizing: border-box; font-family: sans-serif;';
            document.documentElement.appendChild(rh);
        }
        
        // Линии для умных направляющих
        if (!document.getElementById('vsi-guide-x')) {
            let gx = document.createElement('div');
            gx.id = 'vsi-guide-x';
            gx.style.cssText = 'position: fixed; top: 0; bottom: 0; width: 1px; background: #FF004C; z-index: 2147483647; display: none; pointer-events: none; box-shadow: 0 0 2px rgba(255,0,76,0.5);';
            document.documentElement.appendChild(gx);
        }
        if (!document.getElementById('vsi-guide-y')) {
            let gy = document.createElement('div');
            gy.id = 'vsi-guide-y';
            gy.style.cssText = 'position: fixed; left: 0; right: 0; height: 1px; background: #FF004C; z-index: 2147483647; display: none; pointer-events: none; box-shadow: 0 0 2px rgba(255,0,76,0.5);';
            document.documentElement.appendChild(gy);
        }
    }
}

// Кэширование координат для избежания Layout Thrashing
if (!window.vsiLoopStarted) {
    window.vsiLoopStarted = true;
    let lastRectStr = ""; 
    
    function vsiUpdateHandlesLoop() {
        let mh = document.getElementById('vsi-move-handle');
        let rh = document.getElementById('vsi-resize-handle');

        if (isVisualMode && selectedElements.size > 0) {
            let anchor = Array.from(selectedElements).pop();
            if (anchor && document.body.contains(anchor)) {
                let rect = anchor.getBoundingClientRect();
                
                if (rect.width > 0 || rect.height > 0) {
                    let currentRectStr = `${rect.left},${rect.top},${rect.width},${rect.height}`;
                    
                    if (currentRectStr !== lastRectStr) {
                        lastRectStr = currentRectStr;
                        if (mh) {
                            mh.style.display = 'flex';
                            mh.style.left = (rect.left - 12) + 'px';
                            mh.style.top = (rect.top - 12) + 'px';
                        }
                        if (rh) {
                            rh.style.display = 'flex';
                            rh.style.left = (rect.right - 12) + 'px';
                            rh.style.top = (rect.bottom - 12) + 'px';
                        }
                    }
                } else {
                    if (mh && mh.style.display !== 'none') mh.style.display = 'none';
                    if (rh && rh.style.display !== 'none') rh.style.display = 'none';
                    lastRectStr = "";
                }
            } else {
                if (mh && mh.style.display !== 'none') mh.style.display = 'none';
                if (rh && rh.style.display !== 'none') rh.style.display = 'none';
                lastRectStr = "";
            }
        } else {
            if (mh && mh.style.display !== 'none') mh.style.display = 'none';
            if (rh && rh.style.display !== 'none') rh.style.display = 'none';
            lastRectStr = "";
        }
        requestAnimationFrame(vsiUpdateHandlesLoop);
    }
    requestAnimationFrame(vsiUpdateHandlesLoop);
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', appendTags);
} else {
    appendTags();
}

let forceTextareaInterval = null; 

function applyStyles() {
    chrome.storage.local.get([host, host + '_disabled'], (result) => {
        if (result[host] && !result[host + '_disabled']) {
            customStyleTag.textContent = result[host];
            // ЗДЕСЬ ДОБАВЛЕН ХАК 'keep-screen' В МАССИВ
            const hacks = ['keep-awake', 'keep-screen', 'enable-copy', 'kill-alerts', 'unlock-scroll', 'remove-overlays', 'speed-timers', 'auto-refresh', 'anti-spy'];
            hacks.forEach(hack => {
                if (result[host].includes(`@action: ${hack}`) && !activeHacks.has(hack)) {
                    applyHack(hack);
                    activeHacks.add(hack);
                }
            });

            // Безопасный Ghost Input для React
            if (forceTextareaInterval) clearInterval(forceTextareaInterval);
            let textareasToForce = [...result[host].matchAll(/\/\*\s*@action:\s*force-textarea:\s*(.+?)\s*\*\//g)].map(m => m[1].trim());
            
            if (textareasToForce.length > 0) {
                forceTextareaInterval = setInterval(() => {
                    textareasToForce.forEach(sel => {
                        try {
                            document.querySelectorAll(sel).forEach(el => {
                                if (el.tagName.toLowerCase() === 'input' && !el.dataset.vsiReplaced) {
                                    
                                    if (el.parentNode) {
                                        Array.from(el.parentNode.children).forEach(child => {
                                            if (child.dataset && child.dataset.vsiGhost === 'true') child.remove();
                                        });
                                    }

                                    let ta = document.createElement('textarea');
                                    ta.dataset.vsiGhost = 'true';
                                    ta.className = el.className;
                                    
                                    Array.from(el.attributes).forEach(attr => {
                                        if (attr.name !== 'type' && attr.name !== 'id' && !attr.name.startsWith('data-react') && attr.name !== 'class') {
                                            ta.setAttribute(attr.name, attr.value);
                                        }
                                    });
                                    
                                    ta.value = el.value || "";
                                    ta.style.cssText = el.style.cssText;
                                    ta.style.whiteSpace = 'pre-wrap';
                                    ta.style.wordBreak = 'break-word';
                                    ta.style.resize = 'vertical';
                                    ta.style.overflow = 'auto';
                                    ta.style.display = 'block';
                                    
                                    if (el.offsetHeight > 20) ta.style.minHeight = el.offsetHeight + 'px';
                                    else ta.style.minHeight = '60px';
                                    
                                    el.dataset.vsiReplaced = "true";
                                    el.style.setProperty('display', 'none', 'important');
                                    
                                    if (el.parentNode) {
                                        el.parentNode.insertBefore(ta, el);
                                    }
                                    
                                    ta.addEventListener('input', (e) => {
                                        let val = ta.value;
                                        let nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value").set;
                                        if (nativeInputValueSetter) {
                                            nativeInputValueSetter.call(el, val);
                                        } else {
                                            el.value = val;
                                        }
                                        el.dispatchEvent(new Event('input', { bubbles: true }));
                                        el.dispatchEvent(new Event('change', { bubbles: true }));
                                    });
                                }
                            });
                        } catch (err) {}
                    });
                }, 1000); 
            }

        } else {
            customStyleTag.textContent = '';
            if (forceTextareaInterval) clearInterval(forceTextareaInterval);
        }
    });
}

applyStyles();
chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local') {
        if (changes[host] || changes[host + '_disabled']) applyStyles();
        
        if (changes.vsi_force_exit) {
            exitModes();
        }

        if (changes.vsi_active_frame) {
            const activeToken = changes.vsi_active_frame.newValue;
            const myToken = window === window.top ? 'top' : myFrameToken;

            if (activeToken === myToken) {
                if (floatingToolbar && isVisualMode) {
                    floatingToolbar.style.setProperty('display', 'flex', 'important');
                }
            } else {
                if (floatingToolbar) {
                    floatingToolbar.style.setProperty('display', 'none', 'important');
                }
                if (selectedElements.size > 0) {
                    selectedElements.forEach(el => el.classList.remove('style-injector-selected'));
                    selectedElements.clear();
                    const tagDisplay = document.getElementById('vsi-element-tag');
                    if (tagDisplay) tagDisplay.textContent = i18n[currentLang].selectPrompt;
                }
            }
        }
    }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    sendResponse({status: "ok"}); 
    chrome.storage.local.get(['lang'], (res) => {
        currentLang = res.lang || (navigator.language.startsWith('ru') ? 'ru' : 'en');
        if (request.action === "togglePicker") {
            exitModes(); 
            isPickerActive = true; isVisualMode = false;
            document.documentElement.style.cursor = 'crosshair';
            if (window === window.top) showFloatingToolbar();
        }
        if (request.action === "toggleVisualMode") {
            exitModes(); 
            isVisualMode = true; isPickerActive = false;
            document.documentElement.style.cursor = 'default';
            if (window === window.top) {
                alert(i18n[currentLang].msgVisual);
                showFloatingToolbar();
                chrome.storage.local.set({ vsi_active_frame: 'top' });
            }
        }
    });
});

function isExtensionUI(el) {
    if (!el || !el.closest) return false;
    if (el.id === 'vsi-move-handle' || el.id === 'vsi-resize-handle') return true;
    return el.closest('#style-injector-editor-container') || el.closest('#style-injector-toolbar');
}

// --- УМНАЯ ПАНЕЛЬ ИНСТРУМЕНТОВ ---
let floatingToolbar = null;

function showFloatingToolbar() {
    let toolbar = document.getElementById('style-injector-toolbar');
    if (toolbar) toolbar.remove(); 

    const t = i18n[currentLang];

    toolbar = document.createElement('div');
    toolbar.id = 'style-injector-toolbar';
    floatingToolbar = toolbar;
    
    toolbar.innerHTML = `
        <style>
            #style-injector-toolbar {
                position: fixed !important; top: 20px !important; right: 20px !important; 
                z-index: 2147483647 !important; background: #1e1e1ef0 !important; backdrop-filter: blur(10px) !important; 
                padding: 15px !important; border-radius: 12px !important; box-shadow: 0 10px 40px rgba(0,0,0,0.7) !important;
                font-family: sans-serif !important; border: 1px solid #444 !important; 
                width: ${isVisualMode ? '340px' : 'auto'}; 
                min-width: 310px !important; max-width: 80vw !important; max-height: 90vh !important;
                resize: both !important; overflow: auto !important;
                color: white !important; display: flex !important; flex-direction: column !important;
            }
            #style-injector-toolbar::-webkit-scrollbar { width: 6px; height: 6px; }
            #style-injector-toolbar::-webkit-scrollbar-thumb { background: #666; border-radius: 3px; }
            #style-injector-toolbar::-webkit-scrollbar-corner { background: transparent; }
            
            .vsi-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: ${isVisualMode ? '12px' : '0'}; cursor: grab; padding-bottom: ${isVisualMode ? '10px' : '0'}; border-bottom: ${isVisualMode ? '1px solid #444' : 'none'}; flex-shrink: 0; }
            .vsi-header button { border: none; border-radius: 4px; font-weight: bold; cursor: pointer; height: 28px; display: flex; align-items: center; justify-content: center; transition: 0.2s; }
            
            #vsi-btn-undo { background: #FF9800; color: white; width: 28px; font-size: 16px; opacity: 0.5; cursor: not-allowed; border-radius: 50%; }
            #vsi-btn-delete { background: #555; color: white; width: 28px; font-size: 14px; border-radius: 4px; }
            #vsi-btn-delete:hover { background: #f44336; }
            #vsi-btn-esc { background: #f44336; color: white; padding: 0 12px; font-size: 12px;}
            #vsi-btn-esc:hover { background: #da190b; }
            
            #vsi-element-tag { font-size: 12px; color: #4CAF50; font-family: monospace; text-align: center; margin-bottom: 10px; word-break: break-all; background: #00000040; padding: 5px; border-radius: 4px; flex-shrink: 0; }
            
            .vsi-tabs { display: flex; flex-wrap: wrap; gap: 5px; margin-bottom: 12px; flex-shrink: 0; background: transparent; border: none; }
            .vsi-tab { flex: 1 1 auto; padding: 6px 8px; text-align: center; font-size: 10px; color: #bbb; cursor: pointer; border: 1px solid #444; border-radius: 4px; background: #2a2a2a; font-weight: bold; text-transform: uppercase; margin: 0; white-space: nowrap; transition: 0.2s; }
            .vsi-tab:hover { background: #3a3a3a; color: #fff; border-color: #666; }
            .vsi-tab.active { background: #2196F3; color: white; border-color: #2196F3; }
            
            .vsi-tab-content { display: none; flex-direction: column; gap: 8px; font-size: 12px; }
            .vsi-tab-content.active { display: flex; }
            
            .vsi-category { font-size: 10px; color: #888; text-transform: uppercase; letter-spacing: 0.5px; margin: 8px 0 2px 0; border-bottom: 1px solid #444; padding-bottom: 2px; font-weight: 600; }
            .vsi-tab-content > .vsi-category:first-child { margin-top: 0; }
            
            .vsi-row { display: flex; justify-content: space-between; align-items: center; gap: 10px; }
            .vsi-row span { width: 95px; color: #bbb; }
            .vsi-row input[type="range"] { flex: 1; cursor: pointer; }
            .vsi-row input[type="number"] { width: 45px; background: #111; border: 1px solid #555; color: white; padding: 4px; border-radius: 4px; text-align: center; }
            .vsi-row input[type="color"] { width: 45px; height: 26px; border: none; background: none; cursor: pointer; padding: 0; }
            .vsi-row select { flex: 1; background: #111; border: 1px solid #555; color: white; padding: 4px; border-radius: 4px; outline: none; }
            
            .vsi-icon-btn { flex: 1; background: #333; color: white; border: 1px solid #555; border-radius: 4px; padding: 5px 0; cursor: pointer; font-size: 14px; }
            .vsi-icon-btn:hover { background: #444; }
            .vsi-icon-btn.active { background: #4CAF50; border-color: #4CAF50; }
        </style>

        <div class="vsi-header" id="vsi-drag-handle" title="${t.ttDrag}">
            <span style="font-size: 14px; color: #888; margin-right: 10px;">⠿</span>
            <div style="display: flex; gap: 5px;">
                <button id="vsi-btn-undo" title="${t.btnUndo}">↺</button>
                <button id="vsi-btn-delete" title="${t.deleteBtn}">🗑️</button>
                <button id="vsi-btn-esc" title="${t.btnEsc}">ESC</button>
            </div>
        </div>

        ${isVisualMode ? `
        <div id="vsi-style-editor">
            <div id="vsi-element-tag">${t.selectPrompt}</div>
            
            <div class="vsi-tabs">
                <button class="vsi-tab active" data-tab="text">${t.tabText}</button>
                <button class="vsi-tab" data-tab="design">${t.tabDesign}</button>
                <button class="vsi-tab" data-tab="border">${t.tabBorder}</button>
                <button class="vsi-tab" data-tab="size">${t.tabSize}</button>
                <button class="vsi-tab" data-tab="layout">${t.tabLayout}</button>
                <button class="vsi-tab" data-tab="options">${t.tabOptions}</button>
            </div>

            <!-- Вкладка: ТЕКСТ -->
            <div class="vsi-tab-content active" id="tab-text">
                <div class="vsi-row">
                    <span>${t.textSize}</span>
                    <input type="range" id="vsi-txt-s-r" min="8" max="100" value="16">
                    <input type="number" id="vsi-txt-s-n" value="16">
                </div>
                <div class="vsi-row">
                    <span>${t.textColor}</span>
                    <input type="color" id="vsi-txt-c" value="#000000">
                </div>
                <div class="vsi-row" style="margin-top: 2px;">
                    <button class="vsi-icon-btn" id="vsi-btn-bold" style="font-weight:bold;">B</button>
                    <button class="vsi-icon-btn" id="vsi-btn-italic" style="font-style:italic; font-family:serif;">I</button>
                    <div style="width: 10px;"></div>
                    <button class="vsi-icon-btn" id="vsi-btn-align-l" title="Left">⇤</button>
                    <button class="vsi-icon-btn" id="vsi-btn-align-c" title="Center">⇹</button>
                    <button class="vsi-icon-btn" id="vsi-btn-align-r" title="Right">⇥</button>
                </div>
                
                <div class="vsi-category" style="margin-top: 10px;">${t.catNested}</div>
                <div class="vsi-row">
                    <span>${t.linkColor}</span>
                    <input type="color" id="vsi-txt-a-c" value="#000000">
                </div>
                <div class="vsi-row">
                    <span>${t.boldColor}</span>
                    <input type="color" id="vsi-txt-b-c" value="#000000">
                </div>
                <div class="vsi-row">
                    <span>${t.italicColor}</span>
                    <input type="color" id="vsi-txt-i-c" value="#000000">
                </div>
            </div>

            <!-- Вкладка: ДИЗАЙН (Фон, Тень, Слой) -->
            <div class="vsi-tab-content" id="tab-design">
                <div class="vsi-category">${t.categoryBg}</div>
                <div class="vsi-row">
                    <span>${t.bgColor}</span>
                    <input type="color" id="vsi-bg-c" value="#ffffff">
                </div>
                <div class="vsi-row">
                    <span>${t.bgOpacity}</span>
                    <input type="range" id="vsi-bg-op-r" min="0" max="1" step="0.05" value="1">
                    <input type="number" id="vsi-bg-op-n" step="0.05" value="1">
                </div>
                
                <div class="vsi-category">${t.categoryShadow}</div>
                <div class="vsi-row">
                    <span>${t.shX}</span>
                    <input type="range" id="vsi-shx-r" min="-50" max="50" value="0">
                    <input type="number" id="vsi-shx-n" value="0">
                </div>
                <div class="vsi-row">
                    <span>${t.shY}</span>
                    <input type="range" id="vsi-shy-r" min="-50" max="50" value="0">
                    <input type="number" id="vsi-shy-n" value="0">
                </div>
                <div class="vsi-row">
                    <span>${t.shBlur}</span>
                    <input type="range" id="vsi-shb-r" min="0" max="100" value="0">
                    <input type="number" id="vsi-shb-n" value="0">
                </div>
                <div class="vsi-row">
                    <span>${t.shColor}</span>
                    <input type="color" id="vsi-shc" value="#000000">
                </div>
                
                <div class="vsi-category">${t.categoryOpacity}</div>
                <div class="vsi-row">
                    <span>${t.opacity}</span>
                    <input type="range" id="vsi-elop-r" min="0" max="1" step="0.05" value="1">
                    <input type="number" id="vsi-elop-n" step="0.05" value="1">
                </div>
            </div>
            
            <!-- Вкладка: РАМКА -->
            <div class="vsi-tab-content" id="tab-border">
                <div class="vsi-category">${t.catBorderStroke}</div>
                <div class="vsi-row">
                    <span>${t.bdWidth}</span>
                    <input type="range" id="vsi-bdw-r" min="0" max="30" value="0">
                    <input type="number" id="vsi-bdw-n" value="0">
                </div>
                <div class="vsi-row">
                    <span>${t.bdStyle}</span>
                    <select id="vsi-bds">
                        <option value="solid">${t.solid}</option>
                        <option value="dashed">${t.dashed}</option>
                        <option value="dotted">${t.dotted}</option>
                        <option value="none">${t.none}</option>
                    </select>
                </div>
                <div class="vsi-row">
                    <span>${t.bdColor}</span>
                    <input type="color" id="vsi-bdc" value="#ff0000">
                </div>
                <div class="vsi-row">
                    <span>${t.bdOpacity}</span>
                    <input type="range" id="vsi-bd-op-r" min="0" max="1" step="0.05" value="1">
                    <input type="number" id="vsi-bd-op-n" step="0.05" value="1">
                </div>
                
                <div class="vsi-category">${t.catBorderRadius}</div>
                <div class="vsi-row">
                    <span>${t.radius}</span>
                    <input type="range" id="vsi-rad-r" min="0" max="100" value="0">
                    <input type="number" id="vsi-rad-n" value="0">
                </div>
            </div>

            <!-- Вкладка: РАЗМЕР И ПОЗИЦИЯ -->
            <div class="vsi-tab-content" id="tab-size">
                <div class="vsi-category">${t.categoryDim}</div>
                <div class="vsi-row">
                    <span>${t.width}</span>
                    <input type="text" id="vsi-misc-w" placeholder="auto, 100%, 250px" style="flex: 1; background: #111; border: 1px solid #555; color: white; padding: 4px; border-radius: 4px; outline: none; font-size: 11px;">
                </div>
                <div class="vsi-row">
                    <span>${t.height}</span>
                    <input type="text" id="vsi-misc-h" placeholder="auto, 100vh, 50px" style="flex: 1; background: #111; border: 1px solid #555; color: white; padding: 4px; border-radius: 4px; outline: none; font-size: 11px;">
                </div>
                
                <div class="vsi-category">${t.categoryBehavior}</div>
                <div class="vsi-row">
                    <span>${t.overflow}</span>
                    <select id="vsi-misc-over">
                        <option value="">${t.optStd}</option>
                        <option value="visible">${t.optOverVis}</option>
                        <option value="hidden">${t.optOverHid}</option>
                        <option value="auto">${t.optOverAuto}</option>
                    </select>
                </div>
                <div class="vsi-row">
                    <span>${t.resize}</span>
                    <select id="vsi-misc-resize">
                        <option value="">${t.optStd}</option>
                        <option value="both">${t.optResBoth}</option>
                        <option value="vertical">${t.optResVert}</option>
                        <option value="none">${t.optResNone}</option>
                    </select>
                </div>
                
                <div class="vsi-category">${t.categoryPos}</div>
                <div class="vsi-row" title="${t.ttPos}">
                    <span>${t.position}</span>
                    <select id="vsi-misc-pos">
                        <option value="">${t.optStd}</option>
                        <option value="static">${t.optPosStat}</option>
                        <option value="relative">${t.optPosRel}</option>
                        <option value="absolute">${t.optPosAbs}</option>
                        <option value="fixed">${t.optPosFix}</option>
                    </select>
                </div>
                <div class="vsi-row">
                    <span>${t.zIndex}</span>
                    <input type="range" id="vsi-z-r" min="-999" max="999" value="0">
                    <input type="number" id="vsi-z-n" value="0">
                </div>
            </div>

            <!-- Вкладка: МАКЕТ (Сетки, Flex) -->
            <div class="vsi-tab-content" id="tab-layout">
                <div class="vsi-category">${t.categoryModel}</div>
                <div class="vsi-row">
                    <span>${t.display}</span>
                    <select id="vsi-misc-disp">
                        <option value="">${t.optStd}</option>
                        <option value="block">${t.optBlock}</option>
                        <option value="inline-block">${t.optInlBlock}</option>
                        <option value="flex">Flexbox</option>
                        <option value="none">${t.optHidden}</option>
                    </select>
                </div>
                
                <div class="vsi-category">${t.categoryGrid}</div>
                <div class="vsi-row">
                    <span>${t.order}</span>
                    <input type="number" id="vsi-misc-order" placeholder="0, 1, -1" style="flex: 1; background: #111; border: 1px solid #555; color: white; padding: 4px; border-radius: 4px; outline: none; font-size: 11px; text-align: center;">
                </div>
                <div class="vsi-row" title="${t.ttGrid}">
                    <span>${t.gridCols}</span>
                    <input type="text" id="vsi-misc-grid-cols" placeholder="1fr 1fr" style="flex: 1; background: #111; border: 1px solid #555; color: white; padding: 4px; border-radius: 4px; outline: none; font-size: 11px;">
                </div>
                <div class="vsi-row">
                    <span>${t.vAlign}</span>
                    <select id="vsi-misc-valign">
                        <option value="">${t.optStd}</option>
                        <option value="baseline">${t.optValBase}</option>
                        <option value="top">${t.optValTop}</option>
                        <option value="middle">${t.optValMid}</option>
                        <option value="bottom">${t.optValBot}</option>
                    </select>
                </div>
                
                <div class="vsi-category">${t.categoryTable}</div>
                <div class="vsi-row">
                    <span>${t.tableLayout}</span>
                    <select id="vsi-misc-tbl">
                        <option value="">${t.optStd}</option>
                        <option value="auto">${t.optTblAuto}</option>
                        <option value="fixed">${t.optTblFix}</option>
                    </select>
                </div>
                <div class="vsi-row">
                    <span>${t.borderCol}</span>
                    <select id="vsi-misc-border-col">
                        <option value="">${t.optStd}</option>
                        <option value="separate">${t.optBdSep}</option>
                        <option value="collapse">${t.optBdCol}</option>
                    </select>
                </div>
            </div>
            
            <!-- Вкладка: ОПЦИИ -->
            <div class="vsi-tab-content" id="tab-options">
                <div class="vsi-category">${t.categoryInteract}</div>
                <div class="vsi-row">
                    <span>${t.pointer}</span>
                    <select id="vsi-misc-pe">
                        <option value="">${t.optStd}</option>
                        <option value="auto">${t.optPeAuto}</option>
                        <option value="none">${t.optPeNone}</option>
                    </select>
                </div>
                <div class="vsi-row">
                    <span>${t.wrap}</span>
                    <select id="vsi-misc-wrap">
                        <option value="">${t.optStd}</option>
                        <option value="normal">${t.optWrapNorm}</option>
                        <option value="nowrap">${t.optWrapNo}</option>
                        <option value="pre-wrap">${t.optWrapPre}</option>
                    </select>
                </div>
                
                <div class="vsi-category">${t.categoryTools}</div>
                <div class="vsi-row" title="${t.ttEdit}">
                    <span style="color: #FF9800;">${t.editText} ✏️</span>
                    <select id="vsi-misc-editable">
                        <option value="false">${t.optOff}</option>
                        <option value="modify">${t.optEdMod}</option>
                        <option value="textarea">${t.optEdArea}</option>
                    </select>
                </div>
                <div class="vsi-row" title="${t.ttSnap}">
                    <span style="color: #4CAF50;">${t.snap} 🧲</span>
                    <select id="vsi-misc-snap">
                        <option value="smart">${t.optSmart}</option>
                        <option value="grid10">${t.optGrid10}</option>
                        <option value="none">${t.optFree}</option>
                    </select>
                </div>
                <div class="vsi-row" title="${t.ttUnits}">
                    <span style="color: #2196F3;">${t.dragUnits} 📏</span>
                    <select id="vsi-misc-units">
                        <option value="px">${t.unitsPx}</option>
                        <option value="vwvh">${t.unitsVw}</option>
                    </select>
                </div>
            </div>
        </div>
        ` : ''}
    `;

    document.documentElement.appendChild(toolbar);

    toolbar.addEventListener('mouseenter', () => document.body.classList.add('vsi-hide-selection'));
    toolbar.addEventListener('mouseleave', () => document.body.classList.remove('vsi-hide-selection'));

    document.getElementById('vsi-btn-undo').onclick = (e) => { e.stopPropagation(); undoLastAction(); };
    
    document.getElementById('vsi-btn-delete').onclick = (e) => {
        e.stopPropagation();
        if (selectedElements.size === 0) {
            alert(t.selectPrompt);
            return;
        }

        let updates = [];
        selectedElements.forEach(el => {
            const elTag = el.tagName.toLowerCase();
            if (elTag === 'body' || elTag === 'html') return;
            if (elTag === 'iframe' && !confirm(t.confirmIframe)) return;
            
            updates.push({ el: el, selector: generateSelector(el), props: {'display': 'none'} });
            el.classList.remove('style-injector-selected');
        });
        
        saveMultiplePropertiesToCSS(updates, '🛑 СКРЫТИЕ ЭЛЕМЕНТОВ / HIDE');
        
        selectedElements.clear();
        const tagDisplay = document.getElementById('vsi-element-tag');
        if (tagDisplay) tagDisplay.textContent = t.selectPrompt;
        
        if (window !== window.top && floatingToolbar) {
            floatingToolbar.style.setProperty('display', 'none', 'important');
        }
    };

    document.getElementById('vsi-btn-esc').onclick = (e) => { 
        e.stopPropagation(); 
        exitModes(); 
        chrome.storage.local.set({ vsi_force_exit: Math.random() });
    };

    const handle = document.getElementById('vsi-drag-handle');
    handle.onmousedown = function(event) {
        const isInteractive = ['BUTTON', 'INPUT', 'SELECT', 'OPTION'].includes(event.target.tagName);
        if (isInteractive) return;
        event.preventDefault();

        const currentToolbar = document.getElementById('style-injector-toolbar');
        if (!currentToolbar) return;

        let rect = currentToolbar.getBoundingClientRect();
        let shiftX = event.clientX - rect.left;
        let shiftY = event.clientY - rect.top;

        function moveAt(pageX, pageY) {
            if (!currentToolbar) return;
            currentToolbar.style.setProperty('left', (pageX - shiftX) + 'px', 'important');
            currentToolbar.style.setProperty('top', (pageY - shiftY) + 'px', 'important');
            currentToolbar.style.setProperty('right', 'auto', 'important'); 
            currentToolbar.style.setProperty('bottom', 'auto', 'important');
        }

        function onMouseMove(event) { moveAt(event.clientX, event.clientY); }
        document.addEventListener('mousemove', onMouseMove);
        document.onmouseup = function() {
            document.removeEventListener('mousemove', onMouseMove);
            document.onmouseup = null;
        };
    };

    const tabs = toolbar.querySelectorAll('.vsi-tab');
    const contents = toolbar.querySelectorAll('.vsi-tab-content');
    if (tabs.length > 0) {
        tabs.forEach(tab => {
            tab.onclick = () => {
                tabs.forEach(t => t.classList.remove('active'));
                contents.forEach(c => c.classList.remove('active'));
                tab.classList.add('active');
                document.getElementById(`tab-${tab.dataset.tab}`).classList.add('active');
            };
        });
        initPanelControls();
    }

    updateUndoButtonState();
}

function rgbaToHexOp(colorStr) {
    if (!colorStr) return { hex: '#000000', op: 1 };
    let m = colorStr.match(/^rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)$/);
    if (m) {
        let r = parseInt(m[1]).toString(16).padStart(2, '0');
        let g = parseInt(m[2]).toString(16).padStart(2, '0');
        let b = parseInt(m[3]).toString(16).padStart(2, '0');
        return { hex: `#${r}${g}${b}`, op: m[4] !== undefined ? parseFloat(m[4]) : 1 };
    }
    if (colorStr.startsWith('#')) {
        if (colorStr.length === 4) {
            let r = colorStr[1] + colorStr[1];
            let g = colorStr[2] + colorStr[2];
            let b = colorStr[3] + colorStr[3];
            return { hex: `#${r}${g}${b}`, op: 1 };
        }
        return { hex: colorStr.slice(0, 7), op: 1 };
    }
    return { hex: '#000000', op: 1 };
}

function hexToRgba(hex, alpha) {
    let r, g, b;
    if (hex.length === 4) {
        r = parseInt(hex[1] + hex[1], 16);
        g = parseInt(hex[2] + hex[2], 16);
        b = parseInt(hex[3] + hex[3], 16);
    } else {
        r = parseInt(hex.slice(1, 3), 16);
        g = parseInt(hex.slice(3, 5), 16);
        b = parseInt(hex.slice(5, 7), 16);
    }
    return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

function updatePanelFromElement(el) {
    if (!el || !document.getElementById('style-injector-toolbar')) return;
    const style = window.getComputedStyle(el);

    let fSize = parseFloat(style.fontSize) || 16;
    document.getElementById('vsi-txt-s-r').value = fSize; document.getElementById('vsi-txt-s-n').value = fSize;
    let cColor = rgbaToHexOp(style.color);
    document.getElementById('vsi-txt-c').value = cColor.hex;
    
    let isBold = style.fontWeight === 'bold' || parseInt(style.fontWeight) >= 700;
    document.getElementById('vsi-btn-bold').classList.toggle('active', isBold);
    document.getElementById('vsi-btn-italic').classList.toggle('active', style.fontStyle === 'italic');

    ['vsi-btn-align-l','vsi-btn-align-c','vsi-btn-align-r'].forEach(i => document.getElementById(i).classList.remove('active'));
    if (style.textAlign === 'center') document.getElementById('vsi-btn-align-c').classList.add('active');
    else if (style.textAlign === 'right') document.getElementById('vsi-btn-align-r').classList.add('active');
    else document.getElementById('vsi-btn-align-l').classList.add('active');

    let aElem = el.querySelector('a');
    document.getElementById('vsi-txt-a-c').value = aElem ? rgbaToHexOp(window.getComputedStyle(aElem).color).hex : cColor.hex;
    let bElem = el.querySelector('b, strong');
    document.getElementById('vsi-txt-b-c').value = bElem ? rgbaToHexOp(window.getComputedStyle(bElem).color).hex : cColor.hex;
    let iElem = el.querySelector('i, em');
    document.getElementById('vsi-txt-i-c').value = iElem ? rgbaToHexOp(window.getComputedStyle(iElem).color).hex : cColor.hex;

    let bg = rgbaToHexOp(style.backgroundColor);
    document.getElementById('vsi-bg-c').value = bg.hex;
    document.getElementById('vsi-bg-op-r').value = bg.op; document.getElementById('vsi-bg-op-n').value = bg.op;

    let rad = parseFloat(style.borderRadius) || 0;
    document.getElementById('vsi-rad-r').value = rad; document.getElementById('vsi-rad-n').value = rad;

    let bw = parseFloat(style.borderWidth) || 0;
    document.getElementById('vsi-bdw-r').value = bw; document.getElementById('vsi-bdw-n').value = bw;

    let bs = style.borderStyle.split(' ')[0]; 
    if ((bs === 'none' || bs === '') && bw > 0) bs = 'solid';
    let bdsElem = document.getElementById('vsi-bds');
    if(bdsElem.querySelector(`option[value="${bs}"]`)) bdsElem.value = bs;
    else bdsElem.value = 'none';

    let bc = rgbaToHexOp(style.borderColor);
    document.getElementById('vsi-bdc').value = bc.hex;
    document.getElementById('vsi-bd-op-r').value = bc.op; document.getElementById('vsi-bd-op-n').value = bc.op;

    let sh = style.boxShadow;
    if (sh && sh !== 'none') {
        let m = sh.match(/(rgba?\([^)]+\)|#[0-9a-fA-F]+)\s+(-?\d+)px\s+(-?\d+)px\s+(\d+)px/);
        if (m) {
            let sc = rgbaToHexOp(m[1]);
            document.getElementById('vsi-shc').value = sc.hex;
            document.getElementById('vsi-shx-r').value = m[2]; document.getElementById('vsi-shx-n').value = m[2];
            document.getElementById('vsi-shy-r').value = m[3]; document.getElementById('vsi-shy-n').value = m[3];
            document.getElementById('vsi-shb-r').value = m[4]; document.getElementById('vsi-shb-n').value = m[4];
        }
    } else {
        document.getElementById('vsi-shx-r').value = 0; document.getElementById('vsi-shx-n').value = 0;
        document.getElementById('vsi-shy-r').value = 0; document.getElementById('vsi-shy-n').value = 0;
        document.getElementById('vsi-shb-r').value = 0; document.getElementById('vsi-shb-n').value = 0;
    }

    let z = style.zIndex;
    z = (z === 'auto' || isNaN(parseInt(z))) ? 0 : parseInt(z);
    document.getElementById('vsi-z-r').value = z; document.getElementById('vsi-z-n').value = z;

    let op = style.opacity;
    op = (op === '' || isNaN(parseFloat(op))) ? 1 : parseFloat(op);
    document.getElementById('vsi-elop-r').value = op; document.getElementById('vsi-elop-n').value = op;

    document.getElementById('vsi-misc-pos').value = (['static', 'relative', 'absolute', 'fixed'].includes(style.position)) ? style.position : '';
    document.getElementById('vsi-misc-disp').value = (['block', 'inline-block', 'flex', 'none'].includes(style.display)) ? style.display : '';
    document.getElementById('vsi-misc-wrap').value = (['normal', 'nowrap', 'pre-wrap'].includes(style.whiteSpace)) ? style.whiteSpace : '';
    document.getElementById('vsi-misc-over').value = (['visible', 'hidden', 'auto'].includes(style.overflow)) ? style.overflow : '';
    document.getElementById('vsi-misc-resize').value = (['both', 'vertical', 'none'].includes(style.resize)) ? style.resize : '';
    document.getElementById('vsi-misc-pe').value = (['auto', 'none'].includes(style.pointerEvents)) ? style.pointerEvents : '';

    let wVal = style.width;
    document.getElementById('vsi-misc-w').value = (wVal && wVal !== 'auto') ? wVal : '';
    
    let hVal = style.height;
    document.getElementById('vsi-misc-h').value = (hVal && hVal !== 'auto') ? hVal : '';
    
    document.getElementById('vsi-misc-valign').value = (['baseline', 'top', 'middle', 'bottom'].includes(style.verticalAlign)) ? style.verticalAlign : '';
    document.getElementById('vsi-misc-tbl').value = (['auto', 'fixed'].includes(style.tableLayout)) ? style.tableLayout : '';
    document.getElementById('vsi-misc-border-col').value = (['separate', 'collapse'].includes(style.borderCollapse)) ? style.borderCollapse : '';

    let ordVal = style.order;
    document.getElementById('vsi-misc-order').value = (ordVal && ordVal !== '0') ? ordVal : '';
    
    let gridVal = style.gridTemplateColumns;
    document.getElementById('vsi-misc-grid-cols').value = (gridVal && gridVal !== 'none') ? gridVal : '';

    let cssText = customStyleTag.textContent || "";
    let isForceTa = cssText.includes(`/* @action: force-textarea: ${generateSelector(el)} */`);
    let isModify = style.webkitUserModify === 'read-write' || style.webkitUserModify === 'read-write-plaintext-only';
    
    if (isForceTa) {
        document.getElementById('vsi-misc-editable').value = 'textarea';
    } else if (isModify || el.isContentEditable) {
        document.getElementById('vsi-misc-editable').value = 'modify';
    } else {
        document.getElementById('vsi-misc-editable').value = 'false';
    }
}

function syncInput(rangeId, numId, callback) {
    const range = document.getElementById(rangeId);
    const num = document.getElementById(numId);
    if(!range || !num) return;
    range.addEventListener('input', () => { num.value = range.value; callback(false); });
    num.addEventListener('input', () => { range.value = num.value; callback(false); });
    range.addEventListener('change', () => { callback(true); });
    num.addEventListener('change', () => { callback(true); });
}

function initPanelControls() {
    syncInput('vsi-txt-s-r', 'vsi-txt-s-n', (save) => {
        if(selectedElements.size === 0) return;
        let val = document.getElementById('vsi-txt-s-r').value + 'px';
        if (save) {
            tempStyleTag.textContent = '';
            savePropertyToCSS({'font-size': val}, 'ТЕКСТ РАЗМЕР / FONT SIZE');
        } else {
            let tempCss = '';
            selectedElements.forEach(el => tempCss += `${generateSelector(el)} { font-size: ${val} !important; }\n`);
            tempStyleTag.textContent = tempCss;
        }
    });
    
    const updateTextColor = (save) => {
        if(selectedElements.size === 0) return;
        let val = document.getElementById('vsi-txt-c').value;
        if(save) {
            tempStyleTag.textContent = '';
            savePropertyToCSS({'color': val}, 'ТЕКСТ ЦВЕТ / TEXT COLOR');
        } else {
            let tempCss = '';
            selectedElements.forEach(el => tempCss += `${generateSelector(el)} { color: ${val} !important; }\n`);
            tempStyleTag.textContent = tempCss;
        }
    };
    document.getElementById('vsi-txt-c').addEventListener('input', () => updateTextColor(false));
    document.getElementById('vsi-txt-c').addEventListener('change', () => updateTextColor(true));

    const bindToggle = (id, prop, v1, v2, comment) => {
        document.getElementById(id).onclick = function() {
            if(selectedElements.size === 0) return;
            let current = window.getComputedStyle(selectedElements.values().next().value)[prop];
            let newVal = (current === v1 || current.includes(v1) || (current === '700' && v1 === 'bold')) ? v2 : v1;
            savePropertyToCSS({[prop]: newVal}, comment);
            this.classList.toggle('active');
        };
    };
    bindToggle('vsi-btn-bold', 'font-weight', 'bold', 'normal', 'ЖИРНЫЙ / BOLD');
    bindToggle('vsi-btn-italic', 'font-style', 'italic', 'normal', 'КУРСИВ / ITALIC');

    const bindAlign = (id, val) => {
        document.getElementById(id).onclick = function() {
            if(selectedElements.size === 0) return;
            savePropertyToCSS({'text-align': val}, 'ВЫРАВНИВАНИЕ / ALIGN');
            ['vsi-btn-align-l','vsi-btn-align-c','vsi-btn-align-r'].forEach(i => document.getElementById(i).classList.remove('active'));
            this.classList.add('active');
        };
    };
    bindAlign('vsi-btn-align-l', 'left'); bindAlign('vsi-btn-align-c', 'center'); bindAlign('vsi-btn-align-r', 'right');

    const updateNestedColor = (id, selector, comment, save) => {
        if(selectedElements.size === 0) return;
        let val = document.getElementById(id).value;
        if(save) {
            tempStyleTag.textContent = '';
            savePropertyToCSS({'color': val}, comment, selector);
        } else {
            let tempCss = '';
            selectedElements.forEach(el => {
                let base = generateSelector(el);
                let fullSelector = selector.split(',').map(s => `${base} ${s.trim()}`).join(', ');
                tempCss += `${fullSelector} { color: ${val} !important; }\n`;
            });
            tempStyleTag.textContent = tempCss;
        }
    };
    document.getElementById('vsi-txt-a-c').addEventListener('input', () => updateNestedColor('vsi-txt-a-c', 'a', 'ЦВЕТ ССЫЛОК / LINK COLOR', false));
    document.getElementById('vsi-txt-a-c').addEventListener('change', () => updateNestedColor('vsi-txt-a-c', 'a', 'ЦВЕТ ССЫЛОК / LINK COLOR', true));
    document.getElementById('vsi-txt-b-c').addEventListener('input', () => updateNestedColor('vsi-txt-b-c', 'b, strong', 'ЦВЕТ ЖИРНОГО / BOLD COLOR', false));
    document.getElementById('vsi-txt-b-c').addEventListener('change', () => updateNestedColor('vsi-txt-b-c', 'b, strong', 'ЦВЕТ ЖИРНОГО / BOLD COLOR', true));
    document.getElementById('vsi-txt-i-c').addEventListener('input', () => updateNestedColor('vsi-txt-i-c', 'i, em', 'ЦВЕТ КУРСИВА / ITALIC COLOR', false));
    document.getElementById('vsi-txt-i-c').addEventListener('change', () => updateNestedColor('vsi-txt-i-c', 'i, em', 'ЦВЕТ КУРСИВА / ITALIC COLOR', true));

    const updateBg = (save) => {
        if(selectedElements.size === 0) return;
        let hex = document.getElementById('vsi-bg-c').value;
        let op = document.getElementById('vsi-bg-op-r').value;
        let rgba = hexToRgba(hex, op);
        if (save) {
            tempStyleTag.textContent = '';
            savePropertyToCSS({'background-color': rgba}, 'ФОН / BACKGROUND');
        } else {
            let tempCss = '';
            selectedElements.forEach(el => tempCss += `${generateSelector(el)} { background-color: ${rgba} !important; }\n`);
            tempStyleTag.textContent = tempCss;
        }
    };
    document.getElementById('vsi-bg-c').addEventListener('input', () => updateBg(false));
    document.getElementById('vsi-bg-c').addEventListener('change', () => updateBg(true));
    syncInput('vsi-bg-op-r', 'vsi-bg-op-n', updateBg);

    syncInput('vsi-rad-r', 'vsi-rad-n', (save) => {
        if(selectedElements.size === 0) return;
        let val = document.getElementById('vsi-rad-r').value + 'px';
        if (save) {
            tempStyleTag.textContent = '';
            savePropertyToCSS({'border-radius': val}, 'РАДИУС / RADIUS');
        } else {
            let tempCss = '';
            selectedElements.forEach(el => tempCss += `${generateSelector(el)} { border-radius: ${val} !important; }\n`);
            tempStyleTag.textContent = tempCss;
        }
    });

    const updateBorder = (save) => {
        if(selectedElements.size === 0) return;
        let w = document.getElementById('vsi-bdw-r').value;
        let s = document.getElementById('vsi-bds').value;
        let hex = document.getElementById('vsi-bdc').value;
        let op = document.getElementById('vsi-bd-op-r').value;
        let rgba = hexToRgba(hex, op);
        let val = `${w}px ${s} ${rgba}`;
        if (save) {
            tempStyleTag.textContent = '';
            savePropertyToCSS({'border': val}, 'РАМКА / BORDER');
        } else {
            let tempCss = '';
            selectedElements.forEach(el => tempCss += `${generateSelector(el)} { border: ${val} !important; }\n`);
            tempStyleTag.textContent = tempCss;
        }
    };
    syncInput('vsi-bdw-r', 'vsi-bdw-n', updateBorder);
    syncInput('vsi-bd-op-r', 'vsi-bd-op-n', updateBorder);
    document.getElementById('vsi-bds').addEventListener('change', () => updateBorder(true));
    document.getElementById('vsi-bdc').addEventListener('input', () => updateBorder(false));
    document.getElementById('vsi-bdc').addEventListener('change', () => updateBorder(true));

    const updateShadow = (save) => {
        if(selectedElements.size === 0) return;
        let x = document.getElementById('vsi-shx-r').value;
        let y = document.getElementById('vsi-shy-r').value;
        let b = document.getElementById('vsi-shb-r').value;
        let c = document.getElementById('vsi-shc').value;
        let val = `${x}px ${y}px ${b}px ${c}`;
        if (save) {
            tempStyleTag.textContent = '';
            savePropertyToCSS({'box-shadow': val}, 'ТЕНЬ / SHADOW');
        } else {
            let tempCss = '';
            selectedElements.forEach(el => tempCss += `${generateSelector(el)} { box-shadow: ${val} !important; }\n`);
            tempStyleTag.textContent = tempCss;
        }
    };
    syncInput('vsi-shx-r', 'vsi-shx-n', updateShadow);
    syncInput('vsi-shy-r', 'vsi-shy-n', updateShadow);
    syncInput('vsi-shb-r', 'vsi-shb-n', updateShadow);
    document.getElementById('vsi-shc').addEventListener('input', () => updateShadow(false));
    document.getElementById('vsi-shc').addEventListener('change', () => updateShadow(true));

    const updateLayer = (save) => {
        if(selectedElements.size === 0) return;
        let z = document.getElementById('vsi-z-r').value;
        let op = document.getElementById('vsi-elop-r').value;
        
        if (save) {
            tempStyleTag.textContent = '';
            let updates = [];
            selectedElements.forEach(el => {
                let needsRelative = window.getComputedStyle(el).position === 'static';
                let propsToSave = { 'z-index': z, 'opacity': op };
                if (needsRelative) propsToSave['position'] = 'relative';
                updates.push({el: el, selector: generateSelector(el), props: propsToSave});
            });
            saveMultiplePropertiesToCSS(updates, 'СЛОИ И ПРОЗРАЧНОСТЬ / LAYER & OPACITY');
        } else {
            let tempCss = '';
            selectedElements.forEach(el => {
                let needsRelative = window.getComputedStyle(el).position === 'static';
                let pos = needsRelative ? 'position: relative !important;' : '';
                tempCss += `${generateSelector(el)} { z-index: ${z} !important; opacity: ${op} !important; ${pos} }\n`;
            });
            tempStyleTag.textContent = tempCss;
        }
    };
    syncInput('vsi-z-r', 'vsi-z-n', updateLayer);
    syncInput('vsi-elop-r', 'vsi-elop-n', updateLayer);

    const bindSelect = (id, prop, comment) => {
        document.getElementById(id).addEventListener('change', function() {
            if(selectedElements.size === 0) return;
            let val = this.value || 'unset';
            savePropertyToCSS({[prop]: val}, comment);
        });
    };
    bindSelect('vsi-misc-pos', 'position', 'ПОЗИЦИОНИРОВАНИЕ / POSITION');
    bindSelect('vsi-misc-disp', 'display', 'ВИД / DISPLAY');
    bindSelect('vsi-misc-wrap', 'white-space', 'ПЕРЕНОС ТЕКСТА / WHITE SPACE');
    bindSelect('vsi-misc-pe', 'pointer-events', 'КЛИКИ / POINTER EVENTS');
    bindSelect('vsi-misc-valign', 'vertical-align', 'ВЕРТИК. ВЫРАВНИВАНИЕ / VERTICAL ALIGN');
    bindSelect('vsi-misc-tbl', 'table-layout', 'СЕТКА ТАБЛИЦЫ / TABLE LAYOUT');
    bindSelect('vsi-misc-border-col', 'border-collapse', 'ГРАНИЦЫ ЯЧЕЕК / BORDER COLLAPSE');

    const bindTextInput = (id, prop, comment) => {
        const el = document.getElementById(id);
        const applyStyle = function() {
            if(selectedElements.size === 0) return;
            let val = this.value || 'unset';
            savePropertyToCSS({[prop]: val}, comment);
        };
        el.addEventListener('change', applyStyle);
        el.addEventListener('keydown', function(e) { if(e.key === 'Enter') applyStyle.call(this); });
    };
    
    bindTextInput('vsi-misc-w', 'width', 'ШИРИНА / WIDTH');
    bindTextInput('vsi-misc-h', 'height', 'ВЫСОТА / HEIGHT');
    bindTextInput('vsi-misc-grid-cols', 'grid-template-columns', 'КОЛОНКИ СЕТКИ / GRID COLUMNS');
    
    const elOrder = document.getElementById('vsi-misc-order');
    const applyOrder = function() {
        if(selectedElements.size === 0) return;
        let val = this.value || 'unset';
        savePropertyToCSS({'order': val}, 'ПОРЯДОК / ORDER');
    };
    elOrder.addEventListener('change', applyOrder);
    elOrder.addEventListener('keydown', function(e) { if(e.key === 'Enter') applyOrder.call(this); });
    
    document.getElementById('vsi-misc-resize').addEventListener('change', function() {
        if(selectedElements.size === 0) return;
        let val = this.value || 'unset';
        let props = {'resize': val};
        if (val === 'both' || val === 'vertical') {
            props['overflow'] = 'auto'; 
            document.getElementById('vsi-misc-over').value = 'auto';
        }
        savePropertyToCSS(props, 'РАСТЯГИВАНИЕ / RESIZE');
    });
    
    document.getElementById('vsi-misc-over').addEventListener('change', function() {
        if(selectedElements.size === 0) return;
        let val = this.value || 'unset';
        savePropertyToCSS({'overflow': val}, 'КОНТЕНТ / OVERFLOW');
    });

    document.getElementById('vsi-misc-editable').addEventListener('change', function() {
        if(selectedElements.size === 0) return;
        let val = this.value;
        const t = i18n[currentLang];
        
        selectedElements.forEach(el => {
            let sel = generateSelector(el);
            let css = customStyleTag.textContent || "";
            let actionString = `\n/* @action: force-textarea: ${sel} */`;
            
            if (val === 'modify') {
                if (css.includes(`force-textarea: ${sel}`)) {
                    css = css.replace(actionString, '');
                    customStyleTag.textContent = css;
                }
                
                savePropertyToCSS({
                    '-webkit-user-modify': 'read-write',
                    'word-break': 'break-word',
                    'white-space': 'pre-wrap',
                    'outline': '2px dashed #FF9800'
                }, '✏️ РЕДАКТИРУЕМЫЙ ТЕКСТ', "", el, sel);
                
                setTimeout(() => el.focus(), 100);
                
            } else if (val === 'textarea') {
                savePropertyToCSS({
                    '-webkit-user-modify': 'read-only',
                    'outline': 'none'
                }, '🔒 ОТМЕНА РЕДАКТИРОВАНИЯ', "", el, sel);
                
                if (!css.includes(`force-textarea: ${sel}`)) {
                    css += actionString;
                    customStyleTag.textContent = css;
                    if (isContextValid()) {
                        try { chrome.storage.local.set({ [host]: css }); } catch(err){}
                    }
                    applyStyles(); 
                }
            } else {
                savePropertyToCSS({
                    '-webkit-user-modify': 'read-only',
                    'outline': 'none'
                }, '🔒 ОТМЕНА РЕДАКТИРОВАНИЯ', "", el, sel);
                
                if (css.includes(`force-textarea: ${sel}`)) {
                    css = css.replace(actionString, '');
                    customStyleTag.textContent = css;
                    if (isContextValid()) {
                        try { chrome.storage.local.set({ [host]: css }); } catch(err){}
                    }
                    alert(t.alertTextarea);
                }
            }
        });
    });
}

function savePropertyToCSS(propsObj, comment, suffix = "", targetEl = null, explicitSelector = null) {
    let updates = [];
    if (targetEl) {
        updates.push({ el: targetEl, selector: explicitSelector, props: propsObj, suffix: suffix });
    } else if (selectedElements.size > 0) {
        selectedElements.forEach(el => {
            updates.push({ el: el, selector: explicitSelector, props: propsObj, suffix: suffix });
        });
    }
    saveMultiplePropertiesToCSS(updates, comment);
}

function saveMultiplePropertiesToCSS(updates, comment) {
    if (updates.length === 0) return;
    saveToHistory();
    
    let currentCss = customStyleTag.textContent || "";
    let newRulesBlock = "";
    let actionComment = "";
    
    if (comment) {
        let maxNum = 0;
        let match;
        const regex = /\/\*\s*(\d+)\.\s*🎨/g;
        while ((match = regex.exec(currentCss)) !== null) {
            let num = parseInt(match[1]);
            if (num > maxNum) maxNum = num;
        }
        let nextNum = maxNum + 1;
        actionComment = `\n/* ${nextNum}. 🎨 ${comment} */`;
    }
    
    updates.forEach(update => {
        let { el, selector, props, suffix } = update;
        let baseSelector = selector || generateSelector(el);
        let fullSelector = suffix ? suffix.split(',').map(s => `${baseSelector} ${s.trim()}`).join(', ') : baseSelector;
        
        let escapedSelector = fullSelector.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
        let blockRegex = new RegExp(`(^|[\\s\\}])(${escapedSelector}\\s*\\{)([^}]*)(\\})`, 'g');
        
        let appliedProps = new Set();
        let matched = false;
        
        currentCss = currentCss.replace(blockRegex, (match, prefix, openBrace, inner, closeBrace) => {
            matched = true;
            for (let prop in props) {
                let propRegex = new RegExp(`(${prop}\\s*:)[^;]+(;|$)`, 'g');
                if (propRegex.test(inner)) {
                    inner = inner.replace(propRegex, `$1 ${props[prop]} !important$2`);
                } else {
                    inner = inner.replace(/\s+$/, '') + `\n  ${prop}: ${props[prop]} !important;\n`;
                }
                appliedProps.add(prop);
            }
            return prefix + openBrace + inner + closeBrace;
        });
        
        let newRules = [];
        for (let prop in props) {
            if (!appliedProps.has(prop)) {
                newRules.push(`  ${prop}: ${props[prop]} !important;`);
            }
        }
        
        if (newRules.length > 0) {
            newRulesBlock += `\n${fullSelector} {\n${newRules.join('\n')}\n}`;
        }
    });
    
    if (newRulesBlock) {
        currentCss += `${actionComment}${newRulesBlock}`;
    }
    
    customStyleTag.textContent = currentCss;
    
    if (isContextValid()) {
        try {
            chrome.storage.local.set({ [host]: currentCss });
        } catch(e) {}
    }
}

function selectElement(el, isShiftPressed = false) {
    if (isContextValid()) {
        try {
            chrome.storage.local.set({ vsi_active_frame: window === window.top ? 'top' : myFrameToken });
        } catch(e) {}
    }
    
    if (!document.getElementById('style-injector-toolbar')) {
        showFloatingToolbar();
    } else if (floatingToolbar) {
        floatingToolbar.style.setProperty('display', 'flex', 'important');
    }

    if (!isShiftPressed) {
        selectedElements.forEach(e => e.classList.remove('style-injector-selected'));
        selectedElements.clear();
    }
    
    if (isShiftPressed && selectedElements.has(el)) {
        selectedElements.delete(el);
        el.classList.remove('style-injector-selected');
    } else {
        selectedElements.add(el);
        el.classList.add('style-injector-selected');
    }
    
    const tagDisplay = document.getElementById('vsi-element-tag');
    if (tagDisplay) {
        if (selectedElements.size === 0) {
            tagDisplay.textContent = i18n[currentLang].selectPrompt;
        } else if (selectedElements.size === 1) {
            let first = selectedElements.values().next().value;
            let name = first.tagName.toLowerCase();
            if (first.id) name += `#${first.id}`;
            else if (first.className && typeof first.className === 'string') name += `.${first.className.split(' ')[0]}`;
            tagDisplay.textContent = i18n[currentLang].tagPrefix + name;
        } else {
            tagDisplay.textContent = `Выбрано элементов: ${selectedElements.size}`;
        }
    }
    
    if (selectedElements.size > 0) {
        updatePanelFromElement(selectedElements.values().next().value);
    }
}

function saveToHistory() {
    cssHistory.push(customStyleTag.textContent || "");
    updateUndoButtonState();
}

function undoLastAction() {
    if (cssHistory.length > 0) {
        customStyleTag.textContent = cssHistory.pop();
        
        if (isContextValid()) {
            try {
                chrome.storage.local.set({ [host]: customStyleTag.textContent });
            } catch(e) {}
        }
        
        updateUndoButtonState();
        
        setTimeout(() => {
            if (selectedElements.size > 0) updatePanelFromElement(selectedElements.values().next().value);
        }, 50);
    }
}

function updateUndoButtonState() {
    const btnUndo = document.getElementById('vsi-btn-undo');
    if (btnUndo) {
        if (cssHistory.length > 0) {
            btnUndo.style.setProperty('opacity', '1', 'important');
            btnUndo.style.setProperty('cursor', 'pointer', 'important');
            btnUndo.style.setProperty('background', '#FF9800', 'important'); 
        } else {
            btnUndo.style.setProperty('opacity', '0.5', 'important');
            btnUndo.style.setProperty('cursor', 'not-allowed', 'important');
            btnUndo.style.setProperty('background', '#555', 'important');
        }
    }
}

function exitModes() {
    isPickerActive = false;
    isVisualMode = false;
    document.documentElement.style.cursor = ''; 
    document.body.classList.remove('vsi-hide-selection'); 
    tempStyleTag.textContent = ''; 
    
    if (hoveredElement) {
        hoveredElement.classList.remove('style-injector-hover-target', 'style-injector-visual-hover', 'style-injector-active-element');
        hoveredElement = null;
    }
    if (draggedElement) {
        draggedElement.classList.remove('style-injector-visual-hover', 'style-injector-active-element');
        draggedElement = null;
    }
    if (selectedElements.size > 0) {
        selectedElements.forEach(el => el.classList.remove('style-injector-selected'));
        selectedElements.clear();
    }
    if (floatingToolbar) {
        floatingToolbar.remove();
        floatingToolbar = null;
    }
    const editor = document.getElementById('style-injector-editor-container');
    if (editor) {
        chrome.storage.local.get([host], (result) => {
            customStyleTag.textContent = result[host] || "";
            editor.remove();
        });
    }
}

// --- ЛОГИКА МЫШИ ---
document.addEventListener('mouseover', (e) => {
    if (isExtensionUI(e.target)) return; 
    if (isDragging || isResizing) return; 

    if (isPickerActive || isVisualMode) {
        if (hoveredElement && hoveredElement !== e.target) {
            hoveredElement.classList.remove('style-injector-hover-target', 'style-injector-visual-hover');
        }
        hoveredElement = e.target;
        if (isPickerActive) hoveredElement.classList.add('style-injector-hover-target');
        if (isVisualMode && !selectedElements.has(hoveredElement)) {
            hoveredElement.classList.add('style-injector-visual-hover');
        }
    }
});

document.addEventListener('mouseout', (e) => {
    if (isExtensionUI(e.target)) return;
    if (isDragging || isResizing) return; 

    if (!e.relatedTarget && hoveredElement) {
        hoveredElement.classList.remove('style-injector-hover-target', 'style-injector-visual-hover');
        hoveredElement = null;
    }
});

// Блокировка нативного DND браузера (для картинок и ссылок)
document.addEventListener('dragstart', (e) => {
    if (isVisualMode || isPickerActive) {
        e.preventDefault();
        e.stopPropagation();
    }
}, true);

// Блокировка отправки форм
document.addEventListener('submit', (e) => {
    if (isVisualMode || isPickerActive) {
        e.preventDefault();
        e.stopPropagation();
    }
}, true);

document.addEventListener('click', (e) => {
    let mh = document.getElementById('vsi-move-handle');
    let rh = document.getElementById('vsi-resize-handle');
    let isHandle = (e.target === mh || e.target === rh);

    if (isExtensionUI(e.target) && !isHandle) return; 
    
    if (isHandle) { e.preventDefault(); e.stopPropagation(); return; }

    if (isVisualMode) { 
        e.preventDefault(); 
        e.stopPropagation(); 
        return; 
    }
    if (!isPickerActive) return;

    e.preventDefault(); e.stopPropagation();
    isPickerActive = false;
    document.documentElement.style.cursor = ''; 
    
    if (hoveredElement) hoveredElement.classList.remove('style-injector-hover-target');
    if (selectedElements.size > 0) {
        selectedElements.forEach(el => el.classList.remove('style-injector-selected'));
        selectedElements.clear();
    }

    showEditor(generateSelector(e.target));
}, true);

document.addEventListener('mousedown', (e) => {
    let mh = document.getElementById('vsi-move-handle');
    let rh = document.getElementById('vsi-resize-handle');
    let isHandle = (e.target === mh || e.target === rh);

    if (isExtensionUI(e.target) && !isHandle) return;

    if (isPickerActive) { e.preventDefault(); e.stopPropagation(); return; }
    if (!isVisualMode) return;

    if (!isContextValid()) {
        const t = i18n[currentLang];
        alert(t.alertUpdate);
        isVisualMode = false;
        return;
    }

    try {
        chrome.storage.local.set({ vsi_active_frame: window === window.top ? 'top' : myFrameToken });
    } catch(err) {}

    if (isHandle) {
        e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
        draggedElement = Array.from(selectedElements).pop();
    } else {
        draggedElement = e.target;
    }
    
    if (!draggedElement) return;

    hasMoved = false; 
    lastSnappedDx = 0;
    lastSnappedDy = 0;
    
    elementsToDrag = new Set();
    if (selectedElements.has(draggedElement)) {
        elementsToDrag = new Set(selectedElements);
    } else {
        elementsToDrag.add(draggedElement);
    }

    initialMatrices.clear();
    activeSelectors.clear();
    initialSizes.clear();
    snapTargets = [];
    origDragRects.clear();

    elementsToDrag.forEach(el => {
        el.classList.add('style-injector-active-element');
        activeSelectors.set(el, generateSelector(el));

        const style = window.getComputedStyle(el);
        let mat = new DOMMatrix();
        if (style.transform && style.transform !== 'none') {
            try { mat = new DOMMatrix(style.transform); } catch(err) {}
        }
        initialMatrices.set(el, mat);
        let rect = el.getBoundingClientRect();
        initialSizes.set(el, { w: rect.width, h: rect.height });
        origDragRects.set(el, rect);
    });

    // Собираем элементы для умного прилипания
    let mainDragEl = Array.from(elementsToDrag).pop();
    if (mainDragEl && mainDragEl.parentElement) {
        snapTargets.push(mainDragEl.parentElement.getBoundingClientRect());
        Array.from(mainDragEl.parentElement.children).forEach(sibling => {
            if (!elementsToDrag.has(sibling) && sibling.tagName !== 'STYLE' && sibling.tagName !== 'SCRIPT' && sibling.id !== 'vsi-move-handle' && sibling.id !== 'vsi-resize-handle') {
                let r = sibling.getBoundingClientRect();
                if (r.width > 0 && r.height > 0) snapTargets.push(r);
            }
        });
        snapTargets.push({ left: 0, right: window.innerWidth, width: window.innerWidth, top: 0, bottom: window.innerHeight, height: window.innerHeight });
    }

    if (e.target === rh) {
        isResizing = true;
        dragStartX = e.clientX; dragStartY = e.clientY;
        
        elementsToDrag.forEach(el => {
            const style = window.getComputedStyle(el);
            if (style.display === 'inline') {
                savePropertyToCSS({'display': 'inline-block'}, 'АВТО: БЛОЧНОСТЬ ДЛЯ ИЗМЕНЕНИЯ РАЗМЕРА', "", el, activeSelectors.get(el));
            }
        });
        
    } else if (e.target === mh) {
        isDragging = true;
        dragStartX = e.clientX; dragStartY = e.clientY;
    } else {
        isDragging = true;
        dragStartX = e.clientX; dragStartY = e.clientY;
    }
}, true);

document.addEventListener('mousemove', (e) => {
    if (!isVisualMode) return;
    
    if (isDragging || isResizing) {
        if (Math.abs(e.clientX - dragStartX) > 3 || Math.abs(e.clientY - dragStartY) > 3) {
            hasMoved = true;
        }
    }

    if (isDragging && hasMoved) {
        const dx = e.clientX - dragStartX; 
        const dy = e.clientY - dragStartY;
        
        // --- ЛОГИКА ПРИЛИПАНИЯ (SNAPPING) ---
        let snappedDx = dx;
        let snappedDy = dy;
        
        let guideX = document.getElementById('vsi-guide-x');
        let guideY = document.getElementById('vsi-guide-y');
        if (guideX) guideX.style.display = 'none';
        if (guideY) guideY.style.display = 'none';

        let snapMode = document.getElementById('vsi-misc-snap') ? document.getElementById('vsi-misc-snap').value : 'smart';
        
        if (snapMode === 'grid10') {
            snappedDx = Math.round(dx / 10) * 10;
            snappedDy = Math.round(dy / 10) * 10;
        } else if (snapMode === 'smart') {
            let mainDragEl = Array.from(elementsToDrag).pop();
            let origRect = origDragRects.get(mainDragEl);
            if (origRect) {
                let curLeft = origRect.left + dx;
                let curRight = origRect.right + dx;
                let curCenterX = origRect.left + origRect.width / 2 + dx;

                let curTop = origRect.top + dy;
                let curBottom = origRect.bottom + dy;
                let curCenterY = origRect.top + origRect.height / 2 + dy;

                let snapThreshold = 6;
                let foundX = false;
                let foundY = false;

                // Ось X
                for (let target of snapTargets) {
                    let targetXs = [target.left, target.right, target.left + target.width / 2];
                    let currentXs = [curLeft, curRight, curCenterX];
                    for (let tx of targetXs) {
                        for (let cx of currentXs) {
                            if (Math.abs(tx - cx) < snapThreshold && !foundX) {
                                snappedDx = dx + (tx - cx);
                                if (guideX) { guideX.style.display = 'block'; guideX.style.left = tx + 'px'; }
                                foundX = true; break;
                            }
                        }
                        if(foundX) break;
                    }
                    if(foundX) break;
                }
                
                // Ось Y
                for (let target of snapTargets) {
                    let targetYs = [target.top, target.bottom, target.top + target.height / 2];
                    let currentYs = [curTop, curBottom, curCenterY];
                    for (let ty of targetYs) {
                        for (let cy of currentYs) {
                            if (Math.abs(ty - cy) < snapThreshold && !foundY) {
                                snappedDy = dy + (ty - cy);
                                if (guideY) { guideY.style.display = 'block'; guideY.style.top = ty + 'px'; }
                                foundY = true; break;
                            }
                        }
                        if(foundY) break;
                    }
                    if(foundY) break;
                }
            }
        }
        
        lastSnappedDx = snappedDx;
        lastSnappedDy = snappedDy;
        // --- КОНЕЦ ЛОГИКИ ПРИЛИПАНИЯ ---

        let tempCss = '';
        const units = document.getElementById('vsi-misc-units') ? document.getElementById('vsi-misc-units').value : 'px';
        
        elementsToDrag.forEach(el => {
            const mat = initialMatrices.get(el);
            if (!mat) return;
            
            let totalX = mat.e + snappedDx;
            let totalY = mat.f + snappedDy;
            let newTransform;
            
            if (units === 'vwvh') {
                let vw = (totalX / window.innerWidth * 100).toFixed(2);
                let vh = (totalY / window.innerHeight * 100).toFixed(2);
                if (mat.a === 1 && mat.b === 0 && mat.c === 0 && mat.d === 1) {
                    newTransform = `translate(${vw}vw, ${vh}vh)`;
                } else {
                    newTransform = `matrix(${mat.a}, ${mat.b}, ${mat.c}, ${mat.d}, 0, 0) translate(${vw}vw, ${vh}vh)`;
                }
            } else {
                newTransform = `matrix(${mat.a}, ${mat.b}, ${mat.c}, ${mat.d}, ${totalX}, ${totalY})`;
            }
            
            const sel = activeSelectors.get(el);
            if (sel) {
                tempCss += `${sel} { transform: ${newTransform} !important; transition: none !important; }\n`;
            }
        });
        tempStyleTag.textContent = tempCss;

    } else if (isResizing && hasMoved) {
        const dx = e.clientX - dragStartX; 
        const dy = e.clientY - dragStartY;
        
        // Прилипание для ресайза
        let snappedDx = dx;
        let snappedDy = dy;
        let snapMode = document.getElementById('vsi-misc-snap') ? document.getElementById('vsi-misc-snap').value : 'smart';
        
        if (snapMode === 'grid10') {
            snappedDx = Math.round(dx / 10) * 10;
            snappedDy = Math.round(dy / 10) * 10;
        }
        
        lastSnappedDx = snappedDx;
        lastSnappedDy = snappedDy;

        let tempCss = '';
        const units = document.getElementById('vsi-misc-units') ? document.getElementById('vsi-misc-units').value : 'px';
        
        elementsToDrag.forEach(el => {
            const initSize = initialSizes.get(el);
            if (!initSize) return;
            // Не даем элементу стать меньше 10px
            const newW = Math.max(10, initSize.w + snappedDx);
            const newH = Math.max(10, initSize.h + snappedDy);
            
            let wVal, hVal;
            if (units === 'vwvh') {
                wVal = (newW / window.innerWidth * 100).toFixed(2) + 'vw';
                hVal = (newH / window.innerHeight * 100).toFixed(2) + 'vh';
            } else {
                wVal = newW + 'px';
                hVal = newH + 'px';
            }
            
            const sel = activeSelectors.get(el);
            if (sel) {
                tempCss += `${sel} { width: ${wVal} !important; height: ${hVal} !important; transition: none !important; }\n`;
            }
        });
        tempStyleTag.textContent = tempCss;
    }
});

document.addEventListener('mouseup', (e) => {
    let mh = document.getElementById('vsi-move-handle');
    let rh = document.getElementById('vsi-resize-handle');
    let isHandle = (e.target === mh || e.target === rh);

    if (isExtensionUI(e.target) && !isHandle) return;
    if (isPickerActive) { e.preventDefault(); e.stopPropagation(); return; }
    
    if (isVisualMode && draggedElement) {
        if (!hasMoved && !isResizing) {
            const elTag = draggedElement.tagName.toLowerCase();
            if (elTag === 'body' || elTag === 'html') {
                if (!e.shiftKey) {
                    selectedElements.forEach(el => el.classList.remove('style-injector-selected'));
                    selectedElements.clear();
                    const tagDisplay = document.getElementById('vsi-element-tag');
                    if (tagDisplay) tagDisplay.textContent = i18n[currentLang].selectPrompt;
                    if (window !== window.top && floatingToolbar) {
                        floatingToolbar.style.setProperty('display', 'none', 'important');
                    }
                }
            } else {
                if (!isHandle) selectElement(draggedElement, e.shiftKey); 
            }
        } 
        else if (hasMoved) {
            let units = document.getElementById('vsi-misc-units') ? document.getElementById('vsi-misc-units').value : 'px';
            
            if (isDragging) {
                let updates = [];
                elementsToDrag.forEach(el => {
                    const mat = initialMatrices.get(el);
                    
                    let totalX = mat.e + lastSnappedDx;
                    let totalY = mat.f + lastSnappedDy;
                    let newTransform;
                    
                    if (units === 'vwvh') {
                        let vw = (totalX / window.innerWidth * 100).toFixed(2);
                        let vh = (totalY / window.innerHeight * 100).toFixed(2);
                        if (mat.a === 1 && mat.b === 0 && mat.c === 0 && mat.d === 1) {
                            newTransform = `translate(${vw}vw, ${vh}vh)`;
                        } else {
                            newTransform = `matrix(${mat.a}, ${mat.b}, ${mat.c}, ${mat.d}, 0, 0) translate(${vw}vw, ${vh}vh)`;
                        }
                    } else {
                        newTransform = `matrix(${mat.a}, ${mat.b}, ${mat.c}, ${mat.d}, ${totalX}, ${totalY})`;
                    }
                    
                    updates.push({ el: el, selector: activeSelectors.get(el), props: {'transform': newTransform} });
                });
                saveMultiplePropertiesToCSS(updates, '↕️ ПЕРЕМЕЩЕНИЕ / DRAG');
                
            } else if (isResizing) {
                let updates = [];
                elementsToDrag.forEach(el => {
                    const initSize = initialSizes.get(el);
                    const newW = Math.max(10, initSize.w + lastSnappedDx);
                    const newH = Math.max(10, initSize.h + lastSnappedDy);
                    
                    let wVal, hVal;
                    if (units === 'vwvh') {
                        wVal = (newW / window.innerWidth * 100).toFixed(2) + 'vw';
                        hVal = (newH / window.innerHeight * 100).toFixed(2) + 'vh';
                    } else {
                        wVal = newW + 'px';
                        hVal = newH + 'px';
                    }
                    
                    updates.push({ el: el, selector: activeSelectors.get(el), props: {'width': wVal, 'height': hVal} });
                });
                saveMultiplePropertiesToCSS(updates, '↔️ РАЗМЕР / RESIZE');
            }
        }

        elementsToDrag.forEach(el => {
            el.classList.remove('style-injector-visual-hover', 'style-injector-active-element');
        });
        tempStyleTag.textContent = ''; 
        
        let guideX = document.getElementById('vsi-guide-x');
        let guideY = document.getElementById('vsi-guide-y');
        if (guideX) guideX.style.display = 'none';
        if (guideY) guideY.style.display = 'none';
    }

    isDragging = false; isResizing = false; hasMoved = false;
    draggedElement = null;
    elementsToDrag.clear();
}, true);


let ignoredElements = []; 

document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') { 
        exitModes(); 
        if (isContextValid()) {
            try { chrome.storage.local.set({ vsi_force_exit: Math.random() }); } catch(err){}
        }
        return; 
    }
    
    // Ctrl+Z (Отмена) с защитой от ввода текста
    if ((e.ctrlKey || e.metaKey) && (e.code === 'KeyZ' || e.key.toLowerCase() === 'z')) {
        const activeTag = document.activeElement ? document.activeElement.tagName.toLowerCase() : '';
        const isTyping = activeTag === 'input' || activeTag === 'textarea' || document.activeElement.isContentEditable;
        
        if (!isTyping && isVisualMode && cssHistory.length > 0) {
            e.preventDefault(); 
            e.stopPropagation();
            
            undoLastAction();
            
            let undoBtn = document.getElementById('vsi-btn-undo');
            if (undoBtn) {
                undoBtn.style.setProperty('transform', 'scale(0.8)', 'important');
                undoBtn.style.setProperty('transition', 'transform 0.1s', 'important');
                setTimeout(() => undoBtn.style.setProperty('transform', 'none', 'important'), 150);
            }
            return;
        }
    }

    if (e.key === 'Alt' && !e.repeat && (isVisualMode || isPickerActive) && hoveredElement) {
        e.preventDefault();
        hoveredElement.classList.add('style-injector-ignore-pointer');
        hoveredElement.classList.remove('style-injector-hover-target', 'style-injector-visual-hover', 'style-injector-active-element');
        ignoredElements.push(hoveredElement);
        hoveredElement = null; 
        return;
    }

    if (!isVisualMode) return;
    
    let targetToDelete = hoveredElement || (selectedElements.size > 0 ? true : false);

    if ((e.key === 'Delete' || e.key === 'Backspace') && targetToDelete) {
        const activeTag = document.activeElement ? document.activeElement.tagName.toLowerCase() : '';
        if (activeTag === 'input' || activeTag === 'textarea' || document.activeElement.isContentEditable) return;
        e.preventDefault();
        
        let toDelete = hoveredElement ? [hoveredElement] : Array.from(selectedElements);
        let updates = [];
        
        toDelete.forEach(el => {
            const elTag = el.tagName.toLowerCase();
            if (elTag === 'body' || elTag === 'html') return;
            updates.push({ el: el, selector: generateSelector(el), props: {'display': 'none'} });
            el.classList.remove('style-injector-visual-hover', 'style-injector-active-element', 'style-injector-selected');
            selectedElements.delete(el);
        });

        if (updates.length > 0) {
            saveMultiplePropertiesToCSS(updates, '🛑 СКРЫТИЕ ЭЛЕМЕНТОВ / HIDE');
        }
        
        if (hoveredElement) hoveredElement = null;
        if (selectedElements.size === 0) {
            const tagDisplay = document.getElementById('vsi-element-tag');
            if (tagDisplay) tagDisplay.textContent = i18n[currentLang].selectPrompt;
            if (window !== window.top && floatingToolbar) {
                floatingToolbar.style.setProperty('display', 'none', 'important');
            }
        }
    }
});

document.addEventListener('keyup', (e) => {
    if (e.key === 'Alt') {
        ignoredElements.forEach(el => el.classList.remove('style-injector-ignore-pointer'));
        ignoredElements = [];
    }
});

window.addEventListener('blur', () => {
    ignoredElements.forEach(el => el.classList.remove('style-injector-ignore-pointer'));
    ignoredElements = [];
    if (draggedElement) draggedElement.classList.remove('style-injector-active-element');
});

function generateSelector(el) {
    if (!el || el.nodeType !== 1) return '';
    
    const isDynamicId = (id) => {
        if (!id) return true;
        if (['root', '__next', 'app', 'main', 'site-content', 'yandex'].includes(id)) return false; 
        if (id.includes('/')) return true;
        return /(:[a-zA-Z0-9]+:|^react-|^headlessui-|^radix-|\d{3,})/.test(id);
    };

    if (el.id && !isDynamicId(el.id)) return `#${CSS.escape(el.id)}`;
    
    let path = [];
    let current = el;
    
    const strongAttributes = ['data-tid', 'data-zone-name', 'data-auto', 'data-marker', 'data-test-id', 'data-component'];
    
    while (current && current.nodeType === 1 && current.tagName.toLowerCase() !== 'body' && current.tagName.toLowerCase() !== 'html') {
        let curTag = current.tagName.toLowerCase();
        
        if (current.id && !isDynamicId(current.id)) {
            path.unshift(`#${CSS.escape(current.id)}`);
            break; 
        }

        let foundStrongAttr = false;
        for (let attr of strongAttributes) {
            if (current.hasAttribute(attr)) {
                let attrValue = current.getAttribute(attr);
                if (attrValue) {
                    path.unshift(`${curTag}[${CSS.escape(attr)}="${CSS.escape(attrValue)}"]`);
                    foundStrongAttr = true;
                    break;
                }
            }
        }
        
        if (foundStrongAttr) {
            break;
        }
        
        let nth = 1; 
        let sibling = current;
        while ((sibling = sibling.previousElementSibling)) nth++;
        
        let classAttr = current.getAttribute('class') || '';
        let curClasses = [];
        if (typeof classAttr === 'string' && classAttr.trim() !== '') {
            curClasses = classAttr.split(/\s+/).filter(c => 
                c && 
                !c.includes('style-injector') && 
                !['active', 'focus', 'hover', 'open'].includes(c) &&
                !c.includes('/') && !c.includes(':') && !c.includes('[') 
            );
        }
        
        let selectorPart = curTag;
        if (curClasses.length > 0) {
            selectorPart += `.${CSS.escape(curClasses[0])}`; 
        }
        
        selectorPart += `:nth-child(${nth})`;
        
        path.unshift(selectorPart);
        current = current.parentNode;
    }
    
    if (path.length === 0) return 'body';
    
    let finalSelector = path.join(' > ');
    if (!finalSelector.startsWith('#') && !finalSelector.includes('[')) {
        finalSelector = `:root body > ${finalSelector}`;
    } else {
        finalSelector = `:root body ${finalSelector}`;
    }
    
    return finalSelector;
}

function showEditor(initialSelector) {
    const existing = document.getElementById('style-injector-editor-container');
    if (existing) existing.remove();

    const container = document.createElement('div');
    container.id = 'style-injector-editor-container';

    let textToInsert = customStyleTag.textContent || "";
    if (initialSelector && !textToInsert.includes(initialSelector)) {
        const t = i18n[currentLang];
        textToInsert += `\n\n/* ${t.editorManual} */\n${initialSelector} {\n` +
        `  /* display: none !important; */\n` +
        `  /* z-index: 9999 !important; position: relative !important; */\n` +
        `  /* transform: translate(50px, 50px) !important; */\n` +
        `  /* width: 400px !important; height: 200px !important; */\n` +
        `  /* background-color: #ffcccc !important; */\n` +
        `  /* color: #ff0000 !important; */\n` +
        `}`;
    }

    const t = i18n[currentLang];
    container.innerHTML = `
        <h4>${t.editorTitle} ${host}</h4>
        <textarea id="style-injector-textarea" spellcheck="false">${textToInsert.trim()}</textarea>
        <div class="buttons">
            <button id="style-injector-btn-close">${t.editorClose}</button>
            <button id="style-injector-btn-save">${t.editorSave}</button>
        </div>
    `;

    document.documentElement.appendChild(container);
    document.getElementById('style-injector-btn-save').addEventListener('click', function() {
        saveToHistory(); 
        chrome.storage.local.set({ [host]: document.getElementById('style-injector-textarea').value }, () => {
            this.textContent = t.editorSaved; this.style.background = "#2E7D32";
            setTimeout(() => { this.textContent = t.editorSave; this.style.background = "#4CAF50"; }, 1500);
        });
    });
    document.getElementById('style-injector-btn-close').addEventListener('click', () => {
        chrome.storage.local.get([host], (result) => { customStyleTag.textContent = result[host] || ""; container.remove(); });
    });
}

function applyHack(hackName) {
    window.dispatchEvent(new CustomEvent('VSI_INIT_HACK', { detail: hackName }));
    
    // Перенесли отправку сообщения сюда! Здесь есть доступ к chrome.runtime
    if (hackName === 'keep-awake') {
        if (isContextValid()) {
            chrome.runtime.sendMessage({ action: "protect-tab" }).catch(() => {});
            console.log('[Visual Style Injector] 🛡️ Команда на снятие галочки выгрузки отправлена!');
        }
    }
    
    if (hackName === 'enable-copy') {
        const style = document.createElement('style'); style.textContent = `* { user-select: auto !important; -webkit-user-select: auto !important; }`; (document.head || document.documentElement).appendChild(style);
    } else if (hackName === 'unlock-scroll') {
        const style = document.createElement('style'); style.textContent = `html, body { overflow: auto !important; position: static !important; }`; (document.head || document.documentElement).appendChild(style);
    }
}