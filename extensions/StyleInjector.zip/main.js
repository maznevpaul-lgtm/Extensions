// Этот скрипт работает в контексте самой страницы (MAIN world),
// поэтому он имеет доступ к глобальным переменным сайта и полностью обходит CSP (Content Security Policy).

window.addEventListener('VSI_INIT_HACK', (e) => {
    const hackType = e.detail;

    if (hackType === 'keep-awake') {
        Object.defineProperty(document, 'visibilityState', {get: () => 'visible'});
        Object.defineProperty(document, 'hidden', {get: () => false});
        const stopProp = (ev) => ev.stopImmediatePropagation();
        document.addEventListener('visibilitychange', stopProp, true);
        document.addEventListener('webkitvisibilitychange', stopProp, true);
        window.addEventListener('blur', stopProp, true);
        document.addEventListener('blur', stopProp, true);
        
        console.log('[Visual Style Injector] 🛑 Защита от сна вкладки активирована (MAIN).');
    } 
    
    else if (hackType === 'keep-screen') {
        let wakeLock = null;
        const requestWakeLock = async () => {
            try {
                wakeLock = await navigator.wakeLock.request('screen');
                console.log('[Visual Style Injector] ☀️ Защита от выключения экрана (Wake Lock) активна.');
            } catch (err) {
                console.error('[Visual Style Injector] Ошибка Wake Lock:', err.name, err.message);
            }
        };

        if ('wakeLock' in navigator) {
            requestWakeLock();
            // Браузер может сбросить Wake Lock, если мы свернули окно. Восстанавливаем при возвращении.
            document.addEventListener('visibilitychange', () => {
                if (wakeLock !== null && document.visibilityState === 'visible') {
                    requestWakeLock();
                }
            });
        } else {
            console.log('[Visual Style Injector] ⚠️ Ваш браузер не поддерживает Wake Lock API.');
        }
    }

    else if (hackType === 'enable-copy') {
        const blockEvents = ['contextmenu', 'copy', 'paste', 'cut', 'selectstart', 'dragstart'];
        blockEvents.forEach(ev => {
            document.addEventListener(ev, ev => ev.stopPropagation(), true);
        });
        console.log('[Visual Style Injector] 🔓 Копирование разблокировано.');
    }

    else if (hackType === 'kill-alerts') {
        window.alert = () => { console.log('[Visual Style Injector] Заблокирован alert.'); };
        window.confirm = () => { console.log('[Visual Style Injector] Заблокирован confirm. Возвращено true.'); return true; };
        window.prompt = () => { console.log('[Visual Style Injector] Заблокирован prompt. Возвращено null.'); return null; };
        console.log('[Visual Style Injector] 🚫 Всплывающие окна заблокированы.');
    }

    else if (hackType === 'remove-overlays') {
        setInterval(() => {
            document.querySelectorAll('*').forEach(el => {
                const style = window.getComputedStyle(el);
                if (style.backdropFilter.includes('blur') || style.filter.includes('blur')) {
                    el.style.setProperty('backdrop-filter', 'none', 'important');
                    el.style.setProperty('filter', 'none', 'important');
                }
                if (style.position === 'fixed' && style.zIndex > 99 && (style.height === '100%' || style.height === '100vh')) {
                    el.style.setProperty('display', 'none', 'important');
                }
            });
        }, 2000);
        console.log('[Visual Style Injector] 🖼️ Размытия и прозрачные панели удаляются.');
    }

    else if (hackType === 'speed-timers') {
        const originalSetTimeout = window.setTimeout;
        window.setTimeout = function(fn, delay, ...args) {
            return originalSetTimeout(fn, delay ? delay / 10 : 0, ...args); 
        };
        const originalSetInterval = window.setInterval;
        window.setInterval = function(fn, delay, ...args) {
            return originalSetInterval(fn, delay ? delay / 10 : 0, ...args);
        };
        console.log('[Visual Style Injector] ⏳ Таймеры на сайте ускорены в 10 раз.');
    }

    else if (hackType === 'auto-refresh') {
        setTimeout(() => { window.location.reload(); }, 60000); 
        console.log('[Visual Style Injector] 🔄 Страница автоматически обновится через 60 секунд.');
    }

    else if (hackType === 'anti-spy') {
        // 1. Отключаем фоновую отправку аналитики (Beacon API)
        window.navigator.sendBeacon = function() { return true; };
        
        // 2. Глушим популярные метрики
        window.ga = function() {};
        window.gtag = function() {};
        window.ym = function() {};
        window.fbq = function() {};
        window._mQ = window._mQ || [];
        
        // 3. БЛОКИРУЕМ ГЕОЛОКАЦИЮ (Сайт моментально получит отказ)
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition = function(success, error) {
                if (error) error({ code: 1, message: "User denied Geolocation" });
            };
            navigator.geolocation.watchPosition = function(success, error) {
                if (error) error({ code: 1, message: "User denied Geolocation" });
                return Math.floor(Math.random() * 10000); // Фейковый ID подписки
            };
        }
        
        console.log('[Visual Style Injector] 🛡️ Анти-шпион: трекеры и геолокация заблокированы.');
    }
});