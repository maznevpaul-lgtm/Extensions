// --- ПЕРЕВОД (ЛОКАЛИЗАЦИЯ) ---
const i18n = {
    ru: {
        title: "Visual Style Injector", site: "Сайт:", apply: "Применять стили",
        antispy: "🛡️ Анти-шпион (Блок трекеров)",
        visual: "Визуальный режим", picker: "Пипетка (Редактор)",
        options: "Управление стилями", export: "Экспорт", import: "Импорт", langBtn: "EN",
        alertSys: "Расширения не работают на системных страницах Chrome.\nОткройте обычный сайт!",
        alertConn: "Связь с сайтом потеряна.\nПожалуйста, ОБНОВИТЕ СТРАНИЦУ (F5).",
        alertImport: "Настройки импортированы!\nОбновите страницы.", alertErr: "Ошибка чтения файла."
    },
    en: {
        title: "Visual Style Injector", site: "Site:", apply: "Apply styles",
        antispy: "🛡️ Anti-Spy (Block trackers)",
        visual: "Visual Mode", picker: "CSS Picker",
        options: "Manage styles", export: "Export", import: "Import", langBtn: "RU",
        alertSys: "Extensions don't work on Chrome system pages.\nOpen a normal website!",
        alertConn: "Connection to the site lost.\nPlease REFRESH THIS PAGE (F5).",
        alertImport: "Settings imported!\nRefresh your pages.", alertErr: "Error reading file."
    }
};

let currentLang = 'ru';

function applyTranslations() {
    document.getElementById('txt-title').textContent = i18n[currentLang].title;
    document.getElementById('txt-site').textContent = i18n[currentLang].site;
    document.getElementById('txt-apply').textContent = i18n[currentLang].apply;
    document.getElementById('txt-antispy').textContent = i18n[currentLang].antispy;
    document.getElementById('txt-visual').textContent = i18n[currentLang].visual;
    document.getElementById('txt-picker').textContent = i18n[currentLang].picker;
    document.getElementById('txt-options').textContent = i18n[currentLang].options;
    document.getElementById('txt-export').textContent = i18n[currentLang].export;
    document.getElementById('txt-import').textContent = i18n[currentLang].import;
    document.getElementById('btn-lang').textContent = i18n[currentLang].langBtn;
}

// ВМЕСТО ALERT ИСПОЛЬЗУЕМ ВНУТРЕННИЕ ОПОВЕЩЕНИЯ
function showNotification(text, type = 'error') {
    const box = document.getElementById('notification-box');
    box.textContent = text; 
    box.style.display = 'block';
    
    if (type === 'error') {
        box.style.background = '#f44336'; // Красный
    } else {
        box.style.background = '#4CAF50'; // Зеленый
    }

    // Если это успех, скрываем через 3 секунды
    if (type === 'success') {
        setTimeout(() => { box.style.display = 'none'; }, 3000);
    }
}

// Загрузка языка или автоопределение по браузеру
chrome.storage.local.get(['lang'], (res) => {
    if (res.lang) {
        currentLang = res.lang;
    } else {
        currentLang = navigator.language.startsWith('ru') ? 'ru' : 'en';
    }
    applyTranslations();
});

// Смена языка по клику на кнопку
document.getElementById('btn-lang').addEventListener('click', () => {
    currentLang = currentLang === 'ru' ? 'en' : 'ru';
    chrome.storage.local.set({lang: currentLang});
    applyTranslations();
});
// -----------------------------

// Определяем текущий сайт
chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0] && tabs[0].url) {
        try {
            const url = new URL(tabs[0].url);
            const host = url.hostname;
            document.getElementById('current-host').textContent = host || "неизвестно";

            const toggle = document.getElementById('toggle-site');
            const toggleAntiSpy = document.getElementById('toggle-antispy');

            chrome.storage.local.get([host + '_disabled', host], (result) => {
                toggle.checked = !result[host + '_disabled'];
                const css = result[host] || "";
                toggleAntiSpy.checked = css.includes('@action: anti-spy'); // Проверяем, есть ли уже хак в коде
            });

            toggle.addEventListener('change', (e) => {
                chrome.storage.local.set({[host + '_disabled']: !e.target.checked});
            });

            // Логика быстрой кнопки "Анти-Шпион"
            toggleAntiSpy.addEventListener('change', (e) => {
                chrome.storage.local.get([host], (result) => {
                    let css = result[host] || "";
                    if (e.target.checked && !css.includes('@action: anti-spy')) {
                        // Добавляем красивый комментарий
                        let comment = currentLang === 'ru' ? "🛡️ АНТИ-ШПИОН" : "🛡️ ANTI-SPY";
                        css += `\n/* ===== ${comment} ===== */\n/* @action: anti-spy */\n`;
                    } else if (!e.target.checked) {
                        // Удаляем блок с хаком из кода
                        css = css.replace(/\/\* ===== 🛡️.*? ===== \*\/\n\/\* @action: anti-spy \*\/\n?/g, '');
                        css = css.replace(/\/\* @action: anti-spy \*\/\n?/g, ''); // на случай если пользователь стер заголовок вручную
                    }
                    chrome.storage.local.set({[host]: css});
                });
            });

        } catch (e) {
            document.getElementById('current-host').textContent = "системная страница";
            document.getElementById('toggle-site').disabled = true;
            document.getElementById('toggle-antispy').disabled = true;
        }
    }
});

// Отправка команд на вкладку
async function sendMessage(action) {
    document.getElementById('notification-box').style.display = 'none'; // Скрываем старые ошибки

    let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    // Проверяем, что это не системная страница Chrome
    if (tab && tab.url && (tab.url.startsWith('chrome://') || tab.url.startsWith('edge://'))) {
        showNotification(i18n[currentLang].alertSys, 'error');
        return;
    }

    if (tab) {
        try {
            await chrome.tabs.sendMessage(tab.id, { action: action });
            window.close(); // Успешно - закрываем меню
        } catch (error) {
            // ОШИБКА: Показываем уведомление внутри меню, браузер не зависнет!
            showNotification(i18n[currentLang].alertConn, 'error');
        }
    }
}

// Обработчики кнопок
document.getElementById('btn-pick').addEventListener('click', () => sendMessage("togglePicker"));
document.getElementById('btn-visual').addEventListener('click', () => sendMessage("toggleVisualMode"));

// Управление и экспорт
document.getElementById('btn-options').addEventListener('click', () => chrome.runtime.openOptionsPage());

document.getElementById('btn-export').addEventListener('click', () => {
    chrome.storage.local.get(null, (items) => {
        const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(items, null, 2));
        const a = document.createElement('a');
        a.href = dataStr;
        a.download = "styles_backup.json";
        document.body.appendChild(a);
        a.click();
        a.remove();
    });
});

document.getElementById('file-import').addEventListener('change', (event) => {
    const file = event.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
        try {
            chrome.storage.local.set(JSON.parse(e.target.result), () => {
                showNotification(i18n[currentLang].alertImport, 'success');
            });
        } catch (err) { 
            showNotification(i18n[currentLang].alertErr, 'error');
        }
    };
    reader.readAsText(file);
});