// Этот скрипт работает в фоне и имеет системный доступ к вкладкам
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    // Когда скрипт на странице просит защитить вкладку от выгрузки (засыпания)
    if (request.action === "protect-tab" && sender.tab) {
        chrome.tabs.update(sender.tab.id, { autoDiscardable: false });
        console.log(`[VSI Background] Вкладка ${sender.tab.id} защищена от выгрузки из памяти.`);
    }
});