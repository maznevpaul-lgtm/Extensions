// Определение языка браузера
const lang = navigator.language.startsWith('ru') ? 'ru' : 'en';

const i18n = {
  ru: {
    drag: 'Потяните, чтобы переместить',
    save: 'Сохранить оригинал',
    jpg: 'Сохранить как JPG',
    png: 'Сохранить как PNG',
    copying: 'Копирование',
    downloading: 'Загрузка',
    copied: 'Скопировано',
    ready: 'Готово',
    error_fetch: 'Ошибка получения',
    error_copy: 'Ошибка копирования!',
    error: 'Ошибка!',
    file: 'ФАЙЛ',
    update_msg: 'Расширение было обновлено. Пожалуйста, обновите эту страницу (F5).'
  },
  en: {
    drag: 'Drag to move',
    save: 'Save original',
    jpg: 'Save as JPG',
    png: 'Save as PNG',
    copying: 'Copying',
    downloading: 'Downloading',
    copied: 'Copied',
    ready: 'Done',
    error_fetch: 'Fetch error',
    error_copy: 'Copy error!',
    error: 'Error!',
    file: 'FILE',
    update_msg: 'Extension was updated. Please refresh the page (F5).'
  }
};

const styles = `
  .save-ext-overlay {
    position: absolute;
    pointer-events: auto !important; 
    display: flex;
    opacity: 0;
    visibility: hidden;
    transition: opacity 0.1s ease, visibility 0.1s ease, top 0.08s ease-out, left 0.08s ease-out !important;
    flex-direction: column;
    gap: 6px;
    padding: 6px;
    background-color: rgba(255, 255, 255, 0.15) !important;
    border-radius: 8px !important;
    backdrop-filter: blur(4px);
    -webkit-backdrop-filter: blur(4px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.15) !important;
    border: 1px solid rgba(0, 0, 0, 0.05) !important;
  }
  .save-ext-overlay.save-ext-dragging {
    transition: opacity 0.1s ease, visibility 0.1s ease !important;
  }
  .save-ext-overlay.save-ext-horizontal {
    flex-direction: row !important;
  }
  .save-ext-overlay.save-ext-visible {
    opacity: 1;
    visibility: visible;
  }
  
  .save-ext-btn-secondary {
    transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1) !important;
    overflow: hidden !important;
  }
  .save-ext-overlay.save-ext-compact .save-ext-btn-secondary {
    width: 0 !important;
    height: 0 !important;
    opacity: 0 !important;
    margin: 0 !important;
    padding: 0 !important;
    border-width: 0 !important;
  }
  .save-ext-overlay.save-ext-compact:hover .save-ext-btn-secondary {
    width: 32px !important;
    height: 32px !important;
    opacity: 1 !important;
    border-width: 1px !important;
  }

  .save-ext-drag-handle {
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: grab;
    color: rgba(0, 0, 0, 0.4) !important;
    padding: 2px !important;
    border-radius: 4px !important;
    transition: background-color 0.15s;
  }
  .save-ext-drag-handle:hover {
    background-color: rgba(0, 0, 0, 0.1) !important;
    color: rgba(0, 0, 0, 0.7) !important;
  }
  .save-ext-overlay:active .save-ext-drag-handle {
    cursor: grabbing !important;
  }
  .save-ext-btn {
    -webkit-appearance: none !important;
    appearance: none !important;
    background-color: rgba(255, 255, 255, 0.7) !important;
    border: 1px solid rgba(0, 0, 0, 0.1) !important;
    border-radius: 6px !important;
    width: 32px !important;
    height: 32px !important;
    font-size: 14px !important;
    font-family: Arial, sans-serif !important;
    font-weight: bold !important;
    color: #333333 !important;
    cursor: pointer !important;
    backdrop-filter: blur(2px);
    -webkit-backdrop-filter: blur(2px);
    box-shadow: 0 2px 4px rgba(0,0,0,0.1) !important;
    display: flex !important;
    justify-content: center !important;
    align-items: center !important;
    padding: 0 !important;
    margin: 0 !important;
    transition: background-color 0.15s, color 0.15s, border-color 0.15s, transform 0.1s !important;
  }
  .save-ext-btn:hover {
    background-color: rgba(74, 144, 226, 0.95) !important;
    color: white !important;
    border-color: rgba(74, 144, 226, 1) !important;
    transform: scale(1.1) !important;
  }
  .save-ext-btn:active {
    transform: scale(0.95) !important;
  }
  .save-ext-btn svg {
    stroke: currentColor !important;
    flex-shrink: 0 !important;
  }

  @keyframes saveExtProgressFill {
    0% { width: 0%; }
    15% { width: 40%; }
    50% { width: 75%; }
    80% { width: 90%; }
    100% { width: 95%; } 
  }

  .save-ext-btn.save-ext-downloading {
    position: relative !important;
    overflow: hidden !important;
    pointer-events: none !important; 
  }

  .save-ext-btn.save-ext-downloading::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    bottom: 0;
    background-color: rgba(74, 144, 226, 0.4); 
    animation: saveExtProgressFill 3.5s cubic-bezier(0.1, 0.8, 0.2, 1) forwards;
    z-index: 1;
  }

  .save-ext-btn.save-ext-success {
    background-color: rgba(76, 175, 80, 0.9) !important; 
    color: white !important;
    border-color: rgb(76, 175, 80) !important;
  }

  .save-ext-btn > * {
    position: relative;
    z-index: 2;
  }

  .save-ext-overlay.save-ext-source-only .save-ext-btn-secondary {
    display: none !important;
  }
`;

const hostWrapper = document.createElement('div');
hostWrapper.id = 'save-ext-host-wrapper';
hostWrapper.style.cssText = 'all: initial; position: absolute; top: 0; left: 0; width: 0; height: 0; overflow: visible; pointer-events: none; z-index: 2147483647;';

const shadowRoot = hostWrapper.attachShadow({ mode: 'closed' });
const styleSheet = document.createElement("style");
styleSheet.innerText = styles;
shadowRoot.appendChild(styleSheet);

const overlay = document.createElement('div');
overlay.className = 'save-ext-overlay';

const dragHandle = document.createElement('div');
dragHandle.className = 'save-ext-drag-handle';
dragHandle.title = i18n[lang].drag;
dragHandle.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><circle cx="9" cy="5" r="1.5"/><circle cx="15" cy="5" r="1.5"/><circle cx="9" cy="12" r="1.5"/><circle cx="15" cy="12" r="1.5"/><circle cx="9" cy="19" r="1.5"/><circle cx="15" cy="19" r="1.5"/></svg>`;

const btnSave = document.createElement('button');
btnSave.className = 'save-ext-btn';
btnSave.title = i18n[lang].save;
btnSave.innerHTML = `<span><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"></path><polyline points="17 21 17 13 7 13 7 21"></polyline><polyline points="7 3 7 8 15 8"></polyline></svg></span>`;

const btnJpg = document.createElement('button');
btnJpg.className = 'save-ext-btn save-ext-btn-secondary'; 
btnJpg.innerHTML = `<span>J</span>`;
btnJpg.title = i18n[lang].jpg;

const btnPng = document.createElement('button');
btnPng.className = 'save-ext-btn save-ext-btn-secondary'; 
btnPng.innerHTML = `<span>P</span>`;
btnPng.title = i18n[lang].png;

overlay.appendChild(dragHandle);
overlay.appendChild(btnSave);
overlay.appendChild(btnJpg);
overlay.appendChild(btnPng);
shadowRoot.appendChild(overlay); 

function injectHost() {
  if (document.body) {
    if (!document.getElementById('save-ext-host-wrapper')) {
      document.body.appendChild(hostWrapper);
    }
  } else {
    requestAnimationFrame(injectHost);
  }
}
injectHost();

let isOverlayEnabled = true;
let isClipboardEnabled = false;
let isCopyOnlyEnabled = false;
let isHotkeysEnabled = true;
let isBlacklisted = false;
let currentBlacklist = "";
let anchorX = 1.0; 
let anchorY = 0.5; 

function checkBlacklist(blacklistStr) {
  if (!blacklistStr) return false;
  const domains = blacklistStr.split('\n').map(d => d.trim().toLowerCase()).filter(d => d);
  const currentHost = window.location.hostname.toLowerCase();
  return domains.some(domain => currentHost === domain || currentHost.endsWith('.' + domain));
}

chrome.storage.local.get({ showButtons: true, copyToClipboard: false, copyOnly: false, hotkeysEnabled: true, anchorX: 1.0, anchorY: 0.5, blacklist: '' }, (result) => {
  isOverlayEnabled = result.showButtons;
  isClipboardEnabled = result.copyToClipboard;
  isCopyOnlyEnabled = result.copyOnly;
  isHotkeysEnabled = result.hotkeysEnabled;
  anchorX = result.anchorX;
  anchorY = result.anchorY;
  currentBlacklist = result.blacklist;
  isBlacklisted = checkBlacklist(currentBlacklist);
});

chrome.storage.onChanged.addListener((changes, namespace) => {
  if (namespace === 'local') {
    if (changes.showButtons !== undefined) isOverlayEnabled = changes.showButtons.newValue;
    if (!isOverlayEnabled) hideOverlay();
    if (changes.copyToClipboard !== undefined) isClipboardEnabled = changes.copyToClipboard.newValue;
    if (changes.copyOnly !== undefined) isCopyOnlyEnabled = changes.copyOnly.newValue;
    if (changes.hotkeysEnabled !== undefined) isHotkeysEnabled = changes.hotkeysEnabled.newValue;
    if (changes.blacklist !== undefined) {
      currentBlacklist = changes.blacklist.newValue;
      isBlacklisted = checkBlacklist(currentBlacklist);
      if (isBlacklisted) hideOverlayInstantly();
    }
  }
});

let currentImgElement = null;
let currentImgSrc = null;
let currentImgFallback = null; 
let hideTimeout = null;
let showTimeout = null;
let isDragging = false; 

function hideOverlay() {
  if (isDragging) return; 
  clearTimeout(showTimeout);
  clearTimeout(hideTimeout); 
  hideTimeout = setTimeout(() => {
    if (isDragging) return; 
    overlay.classList.remove('save-ext-visible');
    setTimeout(() => {
      if (!overlay.classList.contains('save-ext-visible')) {
        currentImgElement = null;
        currentImgSrc = null;
        currentImgFallback = null;
      }
    }, 150); 
  }, 600); 
}

function hideOverlayInstantly() {
  if (isDragging) return;
  clearTimeout(showTimeout);
  clearTimeout(hideTimeout);
  
  if (overlay.classList.contains('save-ext-visible')) {
    overlay.classList.remove('save-ext-visible');
    overlay.style.transition = 'none';
    overlay.style.opacity = '0';
    overlay.style.visibility = 'hidden';
    
    setTimeout(() => {
      overlay.style.transition = '';
      overlay.style.opacity = '';
      overlay.style.visibility = '';
      currentImgElement = null;
      currentImgSrc = null;
      currentImgFallback = null;
    }, 50);
  }
}

function requestShowOverlay(targetData) {
  if (isDragging || isBlacklisted) return;
  clearTimeout(hideTimeout);

  if (currentImgSrc === targetData.src) {
    clearTimeout(showTimeout);
    showOverlay(targetData);
    return;
  }

  // ЗАЩИТА ОТ ПРЫЖКОВ: Даем небольшую задержку (150ms) при переходе на НОВУЮ картинку.
  // Это предотвращает мигание, если мышка случайно пересекла границу картинок на долю секунды.
  clearTimeout(showTimeout);
  showTimeout = setTimeout(() => {
    showOverlay(targetData);
  }, 150);
}

function showOverlay(targetData) {
  clearTimeout(hideTimeout);
  if (isBlacklisted) return;
  
  overlay.classList.add('save-ext-visible');

  if (isDragging) return; 

  if (currentImgSrc === targetData.src) {
    currentImgElement = targetData.el;
    currentImgFallback = targetData.fallback;
    return;
  }

  currentImgElement = targetData.el;
  currentImgSrc = targetData.src;
  currentImgFallback = targetData.fallback;
  
  if (targetData.isSource) {
    overlay.classList.add('save-ext-source-only');
  } else {
    overlay.classList.remove('save-ext-source-only');
  }

  if (currentImgSrc) {
    btnSave.title = `${i18n[lang].save} (${getFileInfo(currentImgSrc)})`;
  } else {
    btnSave.title = i18n[lang].save;
  }

  const rect = targetData.rect;
  
  if (rect.width < 200 || rect.height < 200) {
    overlay.classList.add('save-ext-compact');
  } else {
    overlay.classList.remove('save-ext-compact');
  }

  if (anchorY < 0.25 || anchorY > 0.75) overlay.classList.add('save-ext-horizontal');
  else overlay.classList.remove('save-ext-horizontal');

  let top = window.scrollY + rect.top + (rect.height * anchorY) - (overlay.offsetHeight / 2);
  let left = window.scrollX + rect.left + (rect.width * anchorX) - (overlay.offsetWidth / 2);

  const pad = 12;
  top = Math.max(window.scrollY + pad, Math.min(top, window.scrollY + window.innerHeight - overlay.offsetHeight - pad));
  left = Math.max(window.scrollX + pad, Math.min(left, window.scrollX + window.innerWidth - overlay.offsetWidth - pad));

  overlay.style.top = `${top}px`;
  overlay.style.left = `${left}px`;
  
  updateOrientation();
}

function updateOrientation() {
  if (!currentImgElement) return;
  const imgRect = currentImgElement.getBoundingClientRect();
  const overlayRect = overlay.getBoundingClientRect();

  const centerX = overlayRect.left + overlayRect.width / 2;
  const centerY = overlayRect.top + overlayRect.height / 2;

  const distToTop = Math.abs(centerY - imgRect.top);
  const distToBottom = Math.abs(imgRect.bottom - centerY);
  const distToLeft = Math.abs(centerX - imgRect.left);
  const distToRight = Math.abs(imgRect.right - centerX);

  if (Math.min(distToTop, distToBottom) < Math.min(distToLeft, distToRight)) {
    overlay.classList.add('save-ext-horizontal');
  } else {
    overlay.classList.remove('save-ext-horizontal');
  }
}

let dragStartX, dragStartY, initialTop, initialLeft;

function onDragMove(e) {
  if (!isDragging) return;
  overlay.style.top = `${initialTop + (e.clientY - dragStartY)}px`;
  overlay.style.left = `${initialLeft + (e.clientX - dragStartX)}px`;
  updateOrientation();
}

function onDragUp(e) {
  if (isDragging) {
    isDragging = false;
    overlay.classList.remove('save-ext-dragging');
    if (currentImgElement) {
      const rect = currentImgElement.getBoundingClientRect();
      const overlayRect = overlay.getBoundingClientRect();
      
      anchorX = ((overlayRect.left + overlayRect.width / 2) - rect.left) / rect.width;
      anchorY = ((overlayRect.top + overlayRect.height / 2) - rect.top) / rect.height;
      
      anchorX = Math.max(-0.2, Math.min(1.2, anchorX));
      anchorY = Math.max(-0.2, Math.min(1.2, anchorY));
      
      chrome.storage.local.set({ anchorX: anchorX, anchorY: anchorY });
    }
    
    // Безопасная проверка клика вне хоста
    const isClickInExtension = e.target === hostWrapper || (e.composedPath && e.composedPath().includes(hostWrapper));
    if (currentImgElement && !currentImgElement.contains(e.target) && !isClickInExtension) {
       hideOverlay();
    }
  }
  document.removeEventListener('mousemove', onDragMove);
  document.removeEventListener('mouseup', onDragUp);
}

dragHandle.addEventListener('mousedown', (e) => {
  isDragging = true;
  overlay.classList.add('save-ext-dragging');
  dragStartX = e.clientX;
  dragStartY = e.clientY;
  initialTop = parseFloat(overlay.style.top);
  initialLeft = parseFloat(overlay.style.left);
  e.preventDefault(); 
  
  document.addEventListener('mousemove', onDragMove);
  document.addEventListener('mouseup', onDragUp);
});

window.addEventListener('scroll', () => {
  hideOverlayInstantly();
}, { passive: true, capture: true });

function getAbsoluteUrl(url) {
  if (!url) return null;
  if (url.startsWith('data:image')) return url; 
  try { return new URL(url, document.baseURI).href; } catch (e) { return url; }
}

function getHighResFromSrcset(srcset) {
  if (!srcset || typeof srcset !== 'string') return null;
  const regex = /([^,\s]+)\s+([\d\.]+)(w|x)/gi;
  let match;
  let maxW = -1;
  let bestUrl = null;

  while ((match = regex.exec(srcset)) !== null) {
      let url = match[1];
      let val = parseFloat(match[2]);
      let unit = match[3].toLowerCase();
      let width = unit === 'w' ? val : val * 1000;

      if (width > maxW) {
          maxW = width;
          bestUrl = url;
      }
  }

  return bestUrl || srcset.split(',')[0].trim().split(/\s+/)[0] || null;
}

// Хелпер для получения фоновых картинок
function getComputedBgImage(el) {
  try {
    const style = window.getComputedStyle(el);
    const bgImg = style.backgroundImage;
    if (bgImg && bgImg !== 'none' && bgImg.startsWith('url(')) {
       return bgImg.slice(4, -1).replace(/["']/g, "");
    }
  } catch(e) {}
  return null;
}

function checkElementForImage(el, mouseX, mouseY) {
  if (!el || typeof el.getBoundingClientRect !== 'function') return null;
  let rect = el.getBoundingClientRect();
  
  if (rect.width < 45 || rect.height < 45) return null;

  if (typeof el.closest === 'function') {
    const ignoredAncestor = el.closest('svg, button, [role="button"], .icon, .avatar, .profile-pic, input, textarea, select');
    if (ignoredAncestor) {
      const ancestorRect = ignoredAncestor.getBoundingClientRect();
      if (ancestorRect.width < 150 && ancestorRect.height < 150) {
         return null; 
      }
    }
  }

  let targetEl = el;
  let fallbackUrl = null;

  if (el.tagName === 'IMG') {
     fallbackUrl = getHighResFromSrcset(el.srcset) || el.currentSrc || el.src;
  } else if (el.tagName === 'CANVAS') {
     try { fallbackUrl = el.toDataURL('image/png'); } catch(e) {}
  } else {
     fallbackUrl = getComputedBgImage(el);
  }

  // ПРОБИТИЕ СЛОЕВ: Ищем картинки (IMG, CANVAS, bg-image) под невидимыми/прозрачными блоками
  if (!fallbackUrl) {
      const elementsUnderCursor = document.elementsFromPoint(mouseX, mouseY);
      if (elementsUnderCursor && elementsUnderCursor.length > 0) {
          for (let underEl of elementsUnderCursor) {
              if (underEl === hostWrapper) continue; // Пропускаем наш собственный интерфейс
              
              if (underEl.tagName === 'IMG') {
                  fallbackUrl = getHighResFromSrcset(underEl.srcset) || underEl.currentSrc || underEl.src;
                  if (fallbackUrl) {
                      targetEl = underEl;
                      break;
                  }
              } else if (underEl.tagName === 'SOURCE') {
                  fallbackUrl = getHighResFromSrcset(underEl.srcset);
                  if (fallbackUrl) {
                      targetEl = typeof underEl.closest === 'function' ? (underEl.closest('picture')?.querySelector('img') || underEl) : underEl;
                      break;
                  }
              } else if (underEl.tagName === 'CANVAS') {
                  try { fallbackUrl = underEl.toDataURL('image/png'); } catch(e) {}
                  if (fallbackUrl) {
                      targetEl = underEl;
                      break;
                  }
              } else {
                  // ПРОВЕРКА ФОНА ПОД КУРСОРОМ (Лечит проблему с прыжками на сетках вроде Facebook Ads)
                  const bg = getComputedBgImage(underEl);
                  if (bg) {
                      fallbackUrl = bg;
                      targetEl = underEl;
                      break;
                  }
              }
          }
      }
  }

  if (!fallbackUrl && (el.tagName === 'DIV' || el.tagName === 'A' || el.tagName === 'FIGURE' || el.tagName === 'PICTURE' || el.tagName === 'BUTTON' || el.getAttribute('role') === 'button')) {
     const textLen = el.innerText ? el.innerText.trim().length : 0;
     if (textLen < 300) {
        if (typeof el.querySelectorAll === 'function') {
           const childImgs = el.querySelectorAll('img, canvas, picture source');
           for (let child of childImgs) {
              const childRect = child.getBoundingClientRect();
              if (mouseX >= childRect.left && mouseX <= childRect.right && mouseY >= childRect.top && mouseY <= childRect.bottom) {
                 if (child.tagName === 'IMG') {
                    fallbackUrl = getHighResFromSrcset(child.srcset) || child.currentSrc || child.src;
                 } else if (child.tagName === 'SOURCE') {
                    fallbackUrl = getHighResFromSrcset(child.srcset);
                 } else {
                    try { fallbackUrl = child.toDataURL('image/png'); } catch(e) {}
                 }
                 
                 if (fallbackUrl) {
                    targetEl = child.tagName === 'SOURCE' && typeof child.closest === 'function' ? (child.closest('picture').querySelector('img') || child) : child;
                    break;
                 }
              }
           }
        }
     }
  }

  if (!fallbackUrl) return null;

  let bestUrl = fallbackUrl;
  let foundPriority = false;
  let isSourceFile = false;

  let searchContainer = typeof targetEl.closest === 'function' ? targetEl.parentElement : null;
  let depth = 0;
  let processedLinks = new Set();
  
  while (searchContainer && searchContainer.tagName !== 'BODY' && depth < 5) {
      if (typeof searchContainer.querySelectorAll === 'function') {
          let validImgsCount = 0;
          const containerImgs = searchContainer.querySelectorAll('img, canvas');
          for (let img of containerImgs) {
              if (img.offsetWidth > 30 && img.offsetHeight > 30) validImgsCount++;
          }
          if (validImgsCount > 1) {
              break; 
          }

          const links = searchContainer.querySelectorAll('a, button, [data-href], [data-url], [data-src], [href]');
          for (let link of links) {
              if (processedLinks.has(link)) continue;
              processedLinks.add(link);
              
              const text = link.innerText ? link.innerText.trim().toLowerCase() : '';
              const href = link.href || link.getAttribute('href') || link.getAttribute('data-href') || link.getAttribute('data-url') || link.getAttribute('data-src') || '';
              
              if (typeof href === 'string' && href.length > 2 && !href.startsWith('javascript:') && href !== '#' && href !== '/') {
                  try {
                      const urlPath = new URL(href, document.baseURI).pathname;
                      const isSourceFormat = urlPath.match(/\.(psd|ai|eps|tiff|tif|raw)$/i);
                      const hasPsdText = text.includes('psd') || text.includes('исходник');

                      if (isSourceFormat || hasPsdText) {
                          const linkRect = link.getBoundingClientRect();
                          if (linkRect.width > 0 && linkRect.height > 0) {
                              let dx = Math.max(rect.left - linkRect.right, 0, linkRect.left - rect.right);
                              let dy = Math.max(rect.top - linkRect.bottom, 0, linkRect.top - rect.bottom);
                              let dist = Math.sqrt(dx*dx + dy*dy);
                              
                              if (dist < 100) {
                                  bestUrl = href;
                                  foundPriority = true;
                                  isSourceFile = true;
                                  break;
                              }
                          } else {
                              bestUrl = href;
                              foundPriority = true;
                              isSourceFile = true;
                              break;
                          }
                      }
                  } catch(e) {}
              }
          }
      }
      if (foundPriority || searchContainer.offsetHeight > 800) break;
      searchContainer = searchContainer.parentElement;
      depth++;
  }

  if (!foundPriority) {
      const allLinks = document.querySelectorAll('a, button, [data-href], [data-url], [data-src], [href]');
      let closestDist = Infinity;
      let closestUrl = null;
      rect = targetEl.getBoundingClientRect(); 

      for (let link of allLinks) {
          const href = link.href || link.getAttribute('href') || link.getAttribute('data-href') || link.getAttribute('data-url') || link.getAttribute('data-src') || '';
          
          let isPsd = false;
          if (typeof href === 'string' && href.length > 2 && !href.startsWith('javascript:') && href !== '#' && href !== '/') {
              try {
                  const urlPath = new URL(href, document.baseURI).pathname;
                  const text = link.innerText ? link.innerText.trim().toLowerCase() : '';
                  isPsd = urlPath.match(/\.(psd|ai|eps|tiff|tif|raw)$/i) || text.includes('psd') || text.includes('исходник');
              } catch(e) {}
          }

          if (isPsd) {
              const linkRect = link.getBoundingClientRect();
              
              if (linkRect.width > 0 && linkRect.height > 0) {
                  let isFloating = false;
                  let parent = link;
                  let checkDepth = 0;
                  
                  while (parent && parent.tagName !== 'BODY' && checkDepth < 6) {
                      const style = window.getComputedStyle(parent);
                      if (style.position === 'absolute' || style.position === 'fixed' || parseInt(style.zIndex) > 5) {
                          isFloating = true;
                          break;
                      }
                      parent = parent.parentElement;
                      checkDepth++;
                  }

                  if (isFloating) {
                      let dx = Math.max(rect.left - linkRect.right, 0, linkRect.left - rect.right);
                      let dy = Math.max(rect.top - linkRect.bottom, 0, linkRect.top - rect.bottom);
                      let dist = Math.sqrt(dx*dx + dy*dy);

                      if (dist < 80 && dist < closestDist) {
                          closestDist = dist;
                          closestUrl = href;
                      }
                  }
              }
          }
      }
      
      if (closestUrl) {
          bestUrl = closestUrl;
          foundPriority = true;
          isSourceFile = true;
      }
  }

  if (!foundPriority) {
      const dataSrc = typeof targetEl.getAttribute === 'function' ? 
          (targetEl.getAttribute('data-src') || targetEl.getAttribute('data-original') || targetEl.getAttribute('data-large') || targetEl.getAttribute('data-url')) : null;
      
      if (dataSrc && typeof dataSrc === 'string' && dataSrc.match(/\.(jpeg|jpg|gif|png|webp|avif|bmp|svg)/i)) {
          bestUrl = dataSrc;
      }

      const parentLink = typeof targetEl.closest === 'function' ? targetEl.closest('a') : null;
      if (parentLink) {
          const aData = parentLink.getAttribute('data-href') || parentLink.getAttribute('data-url') || parentLink.getAttribute('data-image') || parentLink.getAttribute('data-src');
          if (aData && typeof aData === 'string' && aData.match(/\.(jpeg|jpg|gif|png|webp|avif|bmp|svg)/i)) {
              bestUrl = aData;
          } else if (parentLink.href && typeof parentLink.href === 'string') {
              const hrefWithoutParams = parentLink.href.split('?')[0].toLowerCase();
              if (hrefWithoutParams.match(/\.(jpeg|jpg|gif|png|webp|avif|bmp|svg)$/i)) {
                  bestUrl = parentLink.href;
              }
          }
      }
  }

  if (bestUrl && typeof bestUrl === 'string') {
      bestUrl = bestUrl.trim();
      rect = targetEl.getBoundingClientRect(); 

      if (rect.width < 45 || rect.height < 45) return null;

      if (!isSourceFile && bestUrl.match(/\.(psd|ai|eps|tiff|tif|raw)$/i)) {
          isSourceFile = true;
      }

      return { 
         el: targetEl, 
         src: getAbsoluteUrl(bestUrl), 
         fallback: fallbackUrl ? getAbsoluteUrl(fallbackUrl) : getAbsoluteUrl(bestUrl),
         rect: rect,
         isSource: isSourceFile
      };
  }

  return null;
}

// Проверка: Находится ли мышь над интерфейсом расширения?
function isMouseOverExtension(e) {
  return e.target === hostWrapper || (e.composedPath && e.composedPath().includes(hostWrapper));
}

document.addEventListener('mouseover', (e) => {
  if (!isOverlayEnabled || isDragging || isBlacklisted) return;
  
  if (isMouseOverExtension(e)) {
    clearTimeout(hideTimeout);
    clearTimeout(showTimeout); // Магнитная зона: запрещаем перескоки!
    return;
  }
  
  const targetData = checkElementForImage(e.target, e.clientX, e.clientY);
  if (targetData) requestShowOverlay(targetData);
});

let mouseCheckTimeout = null;
document.addEventListener('mousemove', (e) => {
  if (!isOverlayEnabled || isDragging || isBlacklisted) return;

  // МАГНИТНАЯ ЗОНА: Если мышь на нашей панели — намертво стопорим поиск новых картинок
  if (isMouseOverExtension(e)) {
    clearTimeout(hideTimeout);
    clearTimeout(showTimeout); // Запрет смены таргета!
    return;
  }

  if (mouseCheckTimeout) return; 
  mouseCheckTimeout = setTimeout(() => {
    mouseCheckTimeout = null;
    
    const elements = document.elementsFromPoint(e.clientX, e.clientY);
    let found = false;
    
    if (elements && elements.length) {
      for (const el of elements) {
        if (!el) continue;
        if (el === hostWrapper) continue;
        
        const targetData = checkElementForImage(el, e.clientX, e.clientY);
        if (targetData) {
          requestShowOverlay(targetData);
          found = true;
          break; 
        }
      }
    }
    if (!found) hideOverlay();
  }, 80); 
});

document.addEventListener('mouseout', (e) => {
  // Если курсор переходит на нашу панель - не прячем её
  if (e.relatedTarget && (e.relatedTarget === hostWrapper || (e.relatedTarget.composedPath && e.relatedTarget.composedPath().includes(hostWrapper)))) {
      return; 
  }
  if (e.target.tagName === 'IMG' || e.target.tagName === 'CANVAS') hideOverlay();
});

overlay.addEventListener('mouseenter', () => clearTimeout(hideTimeout));
overlay.addEventListener('mouseleave', () => { if (!isDragging) hideOverlay(); });

document.addEventListener('click', (e) => {
  if (isMouseOverExtension(e)) return; // Игнорируем хоткеи при клике в саму панель
  
  if (!e.altKey && !e.shiftKey) return;
  if (!isHotkeysEnabled || isBlacklisted) return;

  const targetData = checkElementForImage(e.target, e.clientX, e.clientY);
  if (targetData && targetData.src) {
    e.preventDefault();
    e.stopPropagation();

    const flashColor = e.shiftKey ? 'rgba(33, 150, 243, 0.5)' : 'rgba(76, 175, 80, 0.5)';
    showFlash(targetData.el, targetData.rect, flashColor);

    if (checkExtensionContext()) {
      if (e.shiftKey) {
        copyToClipboard(targetData.src, targetData.fallback, null, targetData.src);
      } else {
        if (isCopyOnlyEnabled) {
          copyToClipboard(targetData.src, targetData.fallback, null, targetData.src);
        } else {
          chrome.runtime.sendMessage({ action: 'download_original', srcUrl: targetData.src, fallbackUrl: targetData.fallback });
          if (isClipboardEnabled) copyToClipboard(targetData.src, targetData.fallback, null, targetData.src);
        }
      }
    }
  }
}, { capture: true });

function showFlash(el, rect, color = 'rgba(76, 175, 80, 0.5)') {
  const flash = document.createElement('div');
  flash.style.position = 'absolute';
  flash.style.zIndex = '2147483647';
  flash.style.pointerEvents = 'none';
  flash.style.backgroundColor = color;
  flash.style.transition = 'opacity 0.4s ease-out';
  flash.style.opacity = '1';
  
  try {
    flash.style.borderRadius = window.getComputedStyle(el).borderRadius || '0px';
  } catch (err) {}

  const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
  const scrollLeft = window.pageXOffset || document.documentElement.scrollLeft;

  flash.style.top = (rect.top + scrollTop) + 'px';
  flash.style.left = (rect.left + scrollLeft) + 'px';
  flash.style.width = rect.width + 'px';
  flash.style.height = rect.height + 'px';

  if (document.body) document.body.appendChild(flash);

  requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      flash.style.opacity = '0';
    });
  });

  setTimeout(() => {
    flash.remove();
  }, 400);
}

function checkExtensionContext() {
  if (!chrome.runtime || !chrome.runtime.sendMessage) {
    alert(i18n[lang].update_msg);
    return false;
  }
  return true;
}

function getFileInfo(formatOrUrl) {
  let ext = '';
  let name = 'image';

  if (formatOrUrl === 'jpeg') { ext = 'JPG'; }
  else if (formatOrUrl === 'png') { ext = 'PNG'; }
  else if (formatOrUrl) {
    try {
      const urlObj = new URL(formatOrUrl, document.baseURI);
      const urlPath = urlObj.pathname;
      const lastSegment = urlPath.split('/').filter(Boolean).pop();
      if (lastSegment && lastSegment.includes('.')) {
        const parts = lastSegment.split('.');
        ext = parts.pop().toUpperCase();
        name = decodeURIComponent(parts.join('.'));
      } else {
        const match = formatOrUrl.match(/\.(psd|ai|eps|tiff|tif|raw|jpeg|jpg|gif|png|webp|avif|bmp|svg)(?:\?|$)/i);
        if (match) ext = match[1].toUpperCase();
      }
    } catch(e) {}
  }

  if (!ext) ext = i18n[lang].file;
  if (name.length > 15) name = name.substring(0, 15) + '..';

  return `${name}.${ext}`;
}

function copyToClipboard(srcUrl, fallbackUrl, btnElement, formatOrUrl) {
  if (!checkExtensionContext()) return;
  
  let fileInfo = getFileInfo(formatOrUrl || srcUrl);
  let originalContent = '';
  let originalTitle = '';
  
  if (btnElement) {
    originalContent = btnElement.innerHTML;
    originalTitle = btnElement.title;
    btnElement.classList.add('save-ext-downloading');
    btnElement.innerHTML = '⏳';
    btnElement.title = `${i18n[lang].copying}: ${fileInfo}`;
  }

  const imagePromise = new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({ action: 'get_png_for_clipboard', srcUrl: srcUrl, fallbackUrl: fallbackUrl }, async (response) => {
      if (chrome.runtime.lastError || !response || !response.dataUrl) {
        return reject(new Error(i18n[lang].error_fetch));
      }
      try {
        const res = await fetch(response.dataUrl);
        resolve(await res.blob());
      } catch (err) {
        reject(err);
      }
    });
  });

  imagePromise.then(() => {
    navigator.clipboard.write([
      new ClipboardItem({ 'image/png': imagePromise })
    ]).then(() => {
      if (btnElement) {
        btnElement.classList.remove('save-ext-downloading');
        btnElement.classList.add('save-ext-success');
        btnElement.innerHTML = '✅';
        btnElement.title = `${i18n[lang].copied}: ${fileInfo}`;
        setTimeout(() => { 
          btnElement.classList.remove('save-ext-success');
          btnElement.innerHTML = originalContent; 
          btnElement.title = originalTitle;
        }, 2000);
      }
    }).catch(() => {
      if (btnElement) {
        btnElement.classList.remove('save-ext-downloading');
        btnElement.innerHTML = '❌';
        btnElement.title = i18n[lang].error_copy;
        setTimeout(() => { 
          btnElement.innerHTML = originalContent; 
          btnElement.title = originalTitle;
        }, 2000);
      }
    });
  }).catch((err) => {
    if (btnElement) {
      btnElement.classList.remove('save-ext-downloading');
      btnElement.innerHTML = '❌';
      btnElement.title = i18n[lang].error;
      setTimeout(() => { 
        btnElement.innerHTML = originalContent; 
        btnElement.title = originalTitle;
      }, 2000);
    }
  });
}

function showDownloadFeedback(btnElement, formatOrUrl) {
  if (!btnElement || btnElement.classList.contains('save-ext-downloading') || btnElement.classList.contains('save-ext-success')) return;
  
  let fileInfo = getFileInfo(formatOrUrl);
  const originalContent = btnElement.innerHTML;
  const originalTitle = btnElement.title;
  
  btnElement.classList.add('save-ext-downloading');
  btnElement.innerHTML = '⏳';
  btnElement.title = `${i18n[lang].downloading}: ${fileInfo}`;
  
  setTimeout(() => {
    btnElement.classList.remove('save-ext-downloading');
    btnElement.classList.add('save-ext-success');
    btnElement.innerHTML = '✅';
    btnElement.title = `${i18n[lang].ready}: ${fileInfo}`;
    setTimeout(() => { 
      btnElement.classList.remove('save-ext-success');
      btnElement.innerHTML = originalContent; 
      btnElement.title = originalTitle;
    }, 2000);
  }, 3500);
}

btnSave.addEventListener('click', (e) => {
  e.preventDefault(); e.stopPropagation();
  if (currentImgSrc && checkExtensionContext()) {
    if (isCopyOnlyEnabled) {
      copyToClipboard(currentImgSrc, currentImgFallback, btnSave, currentImgSrc);
    } else {
      if (!isClipboardEnabled) showDownloadFeedback(btnSave, currentImgSrc);
      chrome.runtime.sendMessage({ action: 'download_original', srcUrl: currentImgSrc, fallbackUrl: currentImgFallback });
      if (isClipboardEnabled) copyToClipboard(currentImgSrc, currentImgFallback, btnSave, currentImgSrc);
    }
  }
});

btnJpg.addEventListener('click', (e) => {
  e.preventDefault(); e.stopPropagation();
  if (currentImgSrc && checkExtensionContext()) {
    if (isCopyOnlyEnabled) {
      copyToClipboard(currentImgSrc, currentImgFallback, btnJpg, 'jpeg');
    } else {
      if (!isClipboardEnabled) showDownloadFeedback(btnJpg, 'jpeg');
      chrome.runtime.sendMessage({ action: 'download', srcUrl: currentImgSrc, fallbackUrl: currentImgFallback, format: 'jpeg' });
      if (isClipboardEnabled) copyToClipboard(currentImgSrc, currentImgFallback, btnJpg, 'jpeg');
    }
  }
});

btnPng.addEventListener('click', (e) => {
  e.preventDefault(); e.stopPropagation();
  if (currentImgSrc && checkExtensionContext()) {
    if (isCopyOnlyEnabled) {
      copyToClipboard(currentImgSrc, currentImgFallback, btnPng, 'png');
    } else {
      if (!isClipboardEnabled) showDownloadFeedback(btnPng, 'png');
      chrome.runtime.sendMessage({ action: 'download', srcUrl: currentImgSrc, fallbackUrl: currentImgFallback, format: 'png' });
      if (isClipboardEnabled) copyToClipboard(currentImgSrc, currentImgFallback, btnPng, 'png');
    }
  }
});