const lang = navigator.language.startsWith('ru') ? 'ru' : 'en';
const i18n = {
  ru: {
    title: "Настройки расширения",
    show: "Показывать кнопки на картинках",
    copy: "Копировать в буфер при сохранении",
    only: "Только копировать (без сохранения)",
    hotkeys: "Быстрые действия мышью",
    hotkeysHint: "Alt + Клик — Сохранить оригинал\nShift + Клик — Только копировать",
    blacklistTitle: "Черный список доменов (по одному на строку):",
    blacklistPlaceholder: "example.com\ntest.ru"
  },
  en: {
    title: "Extension Settings",
    show: "Show buttons on images",
    copy: "Copy to clipboard on save",
    only: "Copy only (no saving)",
    hotkeys: "Quick mouse actions",
    hotkeysHint: "Alt + Click — Save original\nShift + Click — Copy only",
    blacklistTitle: "Domain blacklist (one per line):",
    blacklistPlaceholder: "example.com\ntest.com"
  }
};

document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('loc-title').innerText = i18n[lang].title;
  document.getElementById('loc-show').innerText = i18n[lang].show;
  document.getElementById('loc-copy').innerText = i18n[lang].copy;
  document.getElementById('loc-only').innerText = i18n[lang].only;
  
  document.getElementById('loc-hotkeys').innerText = i18n[lang].hotkeys;
  document.getElementById('loc-hotkeys-hint').innerText = i18n[lang].hotkeysHint;

  document.getElementById('loc-blacklist-title').innerText = i18n[lang].blacklistTitle;
  const blacklistArea = document.getElementById('blacklist');
  blacklistArea.placeholder = i18n[lang].blacklistPlaceholder;

  const checkboxButtons = document.getElementById('toggleButtons');
  const checkboxClipboard = document.getElementById('copyToClipboard');
  const checkboxCopyOnly = document.getElementById('copyOnly');
  const checkboxHotkeys = document.getElementById('hotkeysEnabled');

  chrome.storage.local.get(['showButtons', 'copyToClipboard', 'copyOnly', 'hotkeysEnabled', 'blacklist'], (result) => {
    checkboxButtons.checked = result.showButtons !== false; 
    checkboxClipboard.checked = result.copyToClipboard === true;
    checkboxCopyOnly.checked = result.copyOnly === true;
    checkboxHotkeys.checked = result.hotkeysEnabled !== false; 
    blacklistArea.value = result.blacklist || '';
  });

  checkboxButtons.addEventListener('change', () => {
    chrome.storage.local.set({ showButtons: checkboxButtons.checked });
  });

  checkboxClipboard.addEventListener('change', () => {
    chrome.storage.local.set({ copyToClipboard: checkboxClipboard.checked });
    
    if (checkboxClipboard.checked) {
      checkboxCopyOnly.checked = false;
      chrome.storage.local.set({ copyOnly: false });
    }
  });

  checkboxCopyOnly.addEventListener('change', () => {
    chrome.storage.local.set({ copyOnly: checkboxCopyOnly.checked });
    
    if (checkboxCopyOnly.checked) {
      checkboxClipboard.checked = false;
      chrome.storage.local.set({ copyToClipboard: false });
    }
  });

  checkboxHotkeys.addEventListener('change', () => {
    chrome.storage.local.set({ hotkeysEnabled: checkboxHotkeys.checked });
  });

  // ИЗМЕНЕНИЕ: Добавлен Debounce, чтобы не спамить в API хранилища браузера 
  // при вводе каждого символа
  let blacklistTimeout = null;
  blacklistArea.addEventListener('input', () => {
    clearTimeout(blacklistTimeout);
    blacklistTimeout = setTimeout(() => {
      chrome.storage.local.set({ blacklist: blacklistArea.value });
    }, 500); 
  });
});