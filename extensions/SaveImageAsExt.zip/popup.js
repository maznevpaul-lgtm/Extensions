// Словари для меню
const lang = navigator.language.startsWith('ru') ? 'ru' : 'en';
const i18n = {
  ru: {
    title: "Настройки расширения",
    show: "Показывать кнопки на картинках",
    copy: "Копировать в буфер при сохранении",
    only: "Только копировать (без сохранения)",
    hotkeys: "Быстрые действия мышью",
    hotkeysHint: "Alt + Клик — Сохранить оригинал\nShift + Клик — Только копировать",
    blacklistTitle: "Черный список доменов (по одному на строку):",
    blacklistPlaceholder: "example.com\ntest.ru"
  },
  en: {
    title: "Extension Settings",
    show: "Show buttons on images",
    copy: "Copy to clipboard on save",
    only: "Copy only (no saving)",
    hotkeys: "Quick mouse actions",
    hotkeysHint: "Alt + Click — Save original\nShift + Click — Copy only",
    blacklistTitle: "Domain blacklist (one per line):",
    blacklistPlaceholder: "example.com\ntest.com"
  }
};

document.addEventListener('DOMContentLoaded', () => {
  // Применяем автоматический перевод текста меню в зависимости от языка браузера
  document.getElementById('loc-title').innerText = i18n[lang].title;
  document.getElementById('loc-show').innerText = i18n[lang].show;
  document.getElementById('loc-copy').innerText = i18n[lang].copy;
  document.getElementById('loc-only').innerText = i18n[lang].only;
  
  document.getElementById('loc-hotkeys').innerText = i18n[lang].hotkeys;
  document.getElementById('loc-hotkeys-hint').innerText = i18n[lang].hotkeysHint;

  document.getElementById('loc-blacklist-title').innerText = i18n[lang].blacklistTitle;
  const blacklistArea = document.getElementById('blacklist');
  blacklistArea.placeholder = i18n[lang].blacklistPlaceholder;

  const checkboxButtons = document.getElementById('toggleButtons');
  const checkboxClipboard = document.getElementById('copyToClipboard');
  const checkboxCopyOnly = document.getElementById('copyOnly');
  const checkboxHotkeys = document.getElementById('hotkeysEnabled');

  // Читаем настройки из памяти браузера
  chrome.storage.local.get(['showButtons', 'copyToClipboard', 'copyOnly', 'hotkeysEnabled', 'blacklist'], (result) => {
    // По умолчанию кнопки включены, остальное выключено
    checkboxButtons.checked = result.showButtons !== false; 
    checkboxClipboard.checked = result.copyToClipboard === true;
    checkboxCopyOnly.checked = result.copyOnly === true;
    checkboxHotkeys.checked = result.hotkeysEnabled !== false; // Включено по умолчанию
    blacklistArea.value = result.blacklist || '';
  });

  // Сохраняем "Показывать кнопки"
  checkboxButtons.addEventListener('change', () => {
    chrome.storage.local.set({ showButtons: checkboxButtons.checked });
  });

  // Сохраняем "Копировать при сохранении"
  checkboxClipboard.addEventListener('change', () => {
    chrome.storage.local.set({ copyToClipboard: checkboxClipboard.checked });
    
    // Взаимоисключение: если включили "Копировать при сохранении", выключаем "Только копировать"
    if (checkboxClipboard.checked) {
      checkboxCopyOnly.checked = false;
      chrome.storage.local.set({ copyOnly: false });
    }
  });

  // Сохраняем "Только копировать"
  checkboxCopyOnly.addEventListener('change', () => {
    chrome.storage.local.set({ copyOnly: checkboxCopyOnly.checked });
    
    // Взаимоисключение: если включили "Только копировать", выключаем "Копировать при сохранении"
    if (checkboxCopyOnly.checked) {
      checkboxClipboard.checked = false;
      chrome.storage.local.set({ copyToClipboard: false });
    }
  });

  // Сохраняем состояние для "Быстрых действий"
  checkboxHotkeys.addEventListener('change', () => {
    chrome.storage.local.set({ hotkeysEnabled: checkboxHotkeys.checked });
  });

  // Сохраняем черный список при каждом изменении
  blacklistArea.addEventListener('input', () => {
    chrome.storage.local.set({ blacklist: blacklistArea.value });
  });
});