// Словари для меню
const lang = navigator.language.startsWith('ru') ? 'ru' : 'en';
const i18n = {
  ru: {
    title: "Настройки расширения",
    show: "Показывать кнопки на картинках",
    copy: "Копировать в буфер при сохранении",
    only: "Только копировать (без сохранения)"
  },
  en: {
    title: "Extension Settings",
    show: "Show buttons on images",
    copy: "Copy to clipboard on save",
    only: "Copy only (no saving)"
  }
};

document.addEventListener('DOMContentLoaded', () => {
  // Применяем автоматический перевод текста меню в зависимости от языка браузера
  document.getElementById('loc-title').innerText = i18n[lang].title;
  document.getElementById('loc-show').innerText = i18n[lang].show;
  document.getElementById('loc-copy').innerText = i18n[lang].copy;
  document.getElementById('loc-only').innerText = i18n[lang].only;

  const checkboxButtons = document.getElementById('toggleButtons');
  const checkboxClipboard = document.getElementById('copyToClipboard');
  const checkboxCopyOnly = document.getElementById('copyOnly');

  // Читаем настройки из памяти браузера
  chrome.storage.local.get(['showButtons', 'copyToClipboard', 'copyOnly'], (result) => {
    // По умолчанию кнопки включены, остальное выключено
    checkboxButtons.checked = result.showButtons !== false; 
    checkboxClipboard.checked = result.copyToClipboard === true;
    checkboxCopyOnly.checked = result.copyOnly === true;
  });

  // Сохраняем "Показывать кнопки"
  checkboxButtons.addEventListener('change', () => {
    chrome.storage.local.set({ showButtons: checkboxButtons.checked });
  });

  // Сохраняем "Копировать при сохранении"
  checkboxClipboard.addEventListener('change', () => {
    chrome.storage.local.set({ copyToClipboard: checkboxClipboard.checked });
    
    // Взаимоисключение: если включили "Копировать при сохранении", выключаем "Только копировать"
    if (checkboxClipboard.checked) {
      checkboxCopyOnly.checked = false;
      chrome.storage.local.set({ copyOnly: false });
    }
  });

  // Сохраняем "Только копировать"
  checkboxCopyOnly.addEventListener('change', () => {
    chrome.storage.local.set({ copyOnly: checkboxCopyOnly.checked });
    
    // Взаимоисключение: если включили "Только копировать", выключаем "Копировать при сохранении"
    if (checkboxCopyOnly.checked) {
      checkboxClipboard.checked = false;
      chrome.storage.local.set({ copyToClipboard: false });
    }
  });
});