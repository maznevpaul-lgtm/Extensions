chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({ id: "save-image-parent", title: "Сохранить картинку как...", contexts: ["image"] });
  chrome.contextMenus.create({ id: "save-as-jpeg", parentId: "save-image-parent", title: "Формат JPEG (.jpg)", contexts: ["image"] });
  chrome.contextMenus.create({ id: "save-as-png", parentId: "save-image-parent", title: "Формат PNG (.png)", contexts: ["image"] });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "save-as-jpeg" || info.menuItemId === "save-as-png") {
    const targetFormat = info.menuItemId === "save-as-jpeg" ? "image/jpeg" : "image/png";
    const extension = info.menuItemId === "save-as-jpeg" ? "jpg" : "png";
    downloadAndConvert(info.srcUrl, info.srcUrl, targetFormat, extension);
  }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'download') {
    const targetFormat = request.format === 'jpeg' ? 'image/jpeg' : 'image/png';
    const extension = request.format === 'jpeg' ? 'jpg' : 'png';
    downloadAndConvert(request.srcUrl, request.fallbackUrl, targetFormat, extension);
  } else if (request.action === 'download_original') {
    smartDownloadOriginal(request.srcUrl, request.fallbackUrl);
  } else if (request.action === 'get_png_for_clipboard') {
    getImgDataUrl(request.srcUrl, request.fallbackUrl)
      .then(dataUrl => sendResponse({ dataUrl: dataUrl }))
      .catch(error => sendResponse({ error: error.toString() }));
    return true; 
  }
});

// Умный загрузчик
async function fetchWithFallback(srcUrl, fallbackUrl) {
  const headers = { 'Accept': 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8' };
  
  let response = await fetch(srcUrl, { headers });
  let contentType = response.headers.get('content-type');
  
  if (contentType && contentType.includes('text/html')) {
    try {
      const text = await response.text();
      const ogMatch = text.match(/<meta\s+(?:property|name)=["']og:image["']\s+content=["']([^"']+)["']/i);
      
      if (ogMatch && ogMatch[1]) {
        let ogUrl = ogMatch[1];
        if (ogUrl.startsWith('/')) {
            ogUrl = new URL(ogUrl, new URL(srcUrl).origin).href;
        }
        response = await fetch(ogUrl, { headers });
      } else if (fallbackUrl && fallbackUrl !== srcUrl) {
        response = await fetch(fallbackUrl, { headers });
      }
    } catch(e) {
      if (fallbackUrl && fallbackUrl !== srcUrl) {
        response = await fetch(fallbackUrl, { headers });
      }
    }
  }
  return response;
}

// Загрузка оригинала (с жестким форсированием формата и обходом .jfif бага)
async function smartDownloadOriginal(srcUrl, fallbackUrl) {
  if (!srcUrl) return;

  if (srcUrl.startsWith('data:image')) {
    let ext = "png";
    if (srcUrl.includes('image/jpeg')) ext = "jpg";
    else if (srcUrl.includes('image/webp')) ext = "webp";
    else if (srcUrl.includes('image/gif')) ext = "gif";
    
    chrome.downloads.download({ 
        url: srcUrl, 
        filename: `image_${Date.now()}.${ext}`,
        saveAs: true 
    });
    return;
  }

  try {
    const response = await fetchWithFallback(srcUrl, fallbackUrl);
    const blob = await response.blob();
    
    if (blob.type.includes('text/html')) {
      chrome.downloads.download({ url: srcUrl, saveAs: true });
      return;
    }

    const finalUrl = response.url || srcUrl;
    let filename = "";
    try {
      const urlPath = new URL(finalUrl).pathname;
      const extractedName = urlPath.substring(urlPath.lastIndexOf('/') + 1);
      if (extractedName) {
        filename = decodeURIComponent(extractedName);
      }
    } catch(e) {}

    const contentType = blob.type.toLowerCase();
    
    if (!filename.includes('.')) {
        let ext = "jpg"; 
        if (contentType.includes('png')) ext = "png";
        else if (contentType.includes('webp')) ext = "webp";
        else if (contentType.includes('gif')) ext = "gif";
        else if (contentType.includes('avif')) ext = "avif";
        else if (contentType.includes('svg')) ext = "svg";
        else if (contentType.includes('psd') || contentType.includes('photoshop')) ext = "psd";
        
        if (!filename) filename = `image_${Date.now()}`;
        filename = `${filename}.${ext}`;
    } else {
        if (contentType.includes('avif') && !filename.toLowerCase().endsWith('.avif')) {
            filename += '.avif';
        } else if (contentType.includes('webp') && !filename.toLowerCase().endsWith('.webp')) {
            filename += '.webp';
        }
    }

    filename = filename.replace(/[\\/:*?"<>|]/g, "_");
    
    if (filename.length > 80) {
        const parts = filename.split('.');
        const extension = parts.length > 1 ? '.' + parts.pop() : '';
        const name = parts.join('.');
        filename = name.substring(0, 80 - extension.length) + extension;
    }

    if (blob.size < 10 * 1024 * 1024) {
        const reader = new FileReader();
        reader.onloadend = () => {
            chrome.downloads.download({ 
                url: reader.result, 
                filename: filename, 
                saveAs: true 
            });
        };
        reader.readAsDataURL(blob);
    } else {
        chrome.downloads.download({ 
            url: finalUrl, 
            filename: filename, 
            saveAs: true 
        });
    }
    
  } catch(e) {
     // ИЗМЕНЕНИЕ: Fallback для скачивания оригинала при CORS/ошибке сети
     console.warn("Резервное скачивание оригинала (заблокировано CORS или ошибкой сети):", e);
     chrome.downloads.download({ url: srcUrl, saveAs: true });
  }
}

async function getImgDataUrl(srcUrl, fallbackUrl) {
  const response = await fetchWithFallback(srcUrl, fallbackUrl);
  const blob = await response.blob();
  if (blob.type.includes('text/html')) throw new Error("Target is HTML");

  const bitmap = await createImageBitmap(blob);
  const canvas = new OffscreenCanvas(bitmap.width, bitmap.height);
  const ctx = canvas.getContext('2d');
  ctx.drawImage(bitmap, 0, 0);
  bitmap.close(); 
  
  const convertedBlob = await canvas.convertToBlob({ type: 'image/png' });

  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve(reader.result);
    reader.readAsDataURL(convertedBlob);
  });
}

async function downloadAndConvert(srcUrl, fallbackUrl, targetFormat, extension) {
  try {
    const response = await fetchWithFallback(srcUrl, fallbackUrl);
    const blob = await response.blob();
    if (blob.type.includes('text/html')) throw new Error("Target is HTML");

    const bitmap = await createImageBitmap(blob);
    const canvas = new OffscreenCanvas(bitmap.width, bitmap.height);
    const ctx = canvas.getContext('2d');

    if (targetFormat === 'image/jpeg') {
      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    }
    ctx.drawImage(bitmap, 0, 0);
    bitmap.close(); 

    const options = { type: targetFormat };
    if (targetFormat === 'image/jpeg') options.quality = 1.0;
    
    const convertedBlob = await canvas.convertToBlob(options);

    const reader = new FileReader();
    reader.onloadend = () => {
      const dataUrl = reader.result;
      let filename = "image_" + Date.now();
      
      try {
        const finalUrl = response.url || srcUrl;
        const urlPath = new URL(finalUrl).pathname;
        const extractedName = urlPath.substring(urlPath.lastIndexOf('/') + 1);
        if (extractedName) filename = decodeURIComponent(extractedName).replace(/\.[^/.]+$/, "");
        if (filename.length > 50) filename = filename.substring(0, 50);
      } catch (e) {}

      chrome.downloads.download({
        url: dataUrl,
        filename: `${filename}.${extension}`,
        saveAs: true
      });
    };
    reader.readAsDataURL(convertedBlob);
  } catch (error) {
    // ИЗМЕНЕНИЕ: Fallback-скачивание при сбое конвертации (например, CORS)
    console.warn("Ошибка конвертации (CORS или сеть), пробуем прямое скачивание оригинала:", error);
    chrome.downloads.download({ url: srcUrl, saveAs: true });
  }
}