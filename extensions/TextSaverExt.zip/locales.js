// --- locales.js (Собственный модуль перевода) ---

const UTS_LOCALES = {
    ru: {
        appName: "Спасатель текста",
        appDesc: "Автосохранение текста, быстрые шаблоны, умный буфер обмена и Дзен-режим.",
        tabDrafts: "Черновики",
        tabSnippets: "Шаблоны",
        tabClipboard: "Буфер",
        clearBtn: "Очистить",
        restoreAllBtn: "Восстановить всё",
        restoreBtn: "Восстановить",
        deleteBtn: "Удалить",
        addSnippetBtn: "Добавить шаблон",
        snipTrigger: "Команда (напр. /email)",
        snipText: "Текст для подстановки",
        clipboardHistory: "История копирования",
        emptyDrafts: "Нет сохраненных данных для этого сайта.",
        emptyClipboard: "Скопируйте любой текст или картинку (Ctrl+C).",
        utmCleaned: "UTM очищены",
        zenReturn: "Вернуться (Esc)",
        hotkeysBtn: "⌨️ Клавиши",
        msgCopied: "Скопировано в буфер!",
        msgDeleted: "Удалено",
        msgRestored: "Успешно восстановлено!",
        msgCleared: "Очищено",
        msgSnippetAdded: "Текст перенесен. Задайте команду!",
        msgError: "Ошибка! Элемент не найден.",
        exportBtn: "Экспорт",
        importBtn: "Импорт",
        msgExported: "Сохранено в файл!",
        msgImported: "Шаблоны загружены!",
        msgImportError: "Ошибка чтения файла!"
    },
    en: {
        appName: "Universal Text Saver",
        appDesc: "Autosave text, quick snippets, smart clipboard, and Zen mode.",
        tabDrafts: "Drafts",
        tabSnippets: "Snippets",
        tabClipboard: "Clipboard",
        clearBtn: "Clear",
        restoreAllBtn: "Restore All",
        restoreBtn: "Restore",
        deleteBtn: "Delete",
        addSnippetBtn: "Add Snippet",
        snipTrigger: "Trigger (e.g. /email)",
        snipText: "Text to insert",
        clipboardHistory: "Clipboard History",
        emptyDrafts: "No saved data for this site.",
        emptyClipboard: "Copy any text or image (Ctrl+C).",
        utmCleaned: "UTM Cleaned",
        zenReturn: "Return (Esc)",
        hotkeysBtn: "⌨️ Hotkeys",
        msgCopied: "Copied to clipboard!",
        msgDeleted: "Deleted",
        msgRestored: "Successfully restored!",
        msgCleared: "Cleared",
        msgSnippetAdded: "Text moved. Set a trigger!",
        msgError: "Error! Element not found.",
        exportBtn: "Export",
        importBtn: "Import",
        msgExported: "Saved to file!",
        msgImported: "Snippets loaded!",
        msgImportError: "File error!"
    }
};

// Определяем язык браузера (если начинается на 'ru', используем русский, иначе английский)
const UTS_LANG = navigator.language.startsWith('ru') ? 'ru' : 'en';

// Глобальная функция-помощник для перевода
function t(key) {
    return UTS_LOCALES[UTS_LANG][key] || UTS_LOCALES['en'][key] || key;
}