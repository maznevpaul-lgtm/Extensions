// --- popup.js (Логика интерфейса расширения) ---

document.addEventListener('DOMContentLoaded', () => {
    // 0. ПРИМЕНЕНИЕ ЛОКАЛИЗАЦИИ ИЗ НАШЕГО JS
    document.querySelectorAll('[data-i18n]').forEach(el => {
        el.textContent = t(el.getAttribute('data-i18n'));
    });
    document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
        el.placeholder = t(el.getAttribute('data-i18n-placeholder'));
    });
    document.querySelectorAll('[data-i18n-title]').forEach(el => {
        el.title = t(el.getAttribute('data-i18n-title'));
    });

    // 1. Навигация по вкладкам
    const tabs = document.querySelectorAll('.tab');
    const views = {
        drafts: document.getElementById('view-drafts'),
        snippets: document.getElementById('view-snippets'),
        clipboard: document.getElementById('view-clipboard')
    };

    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            tabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            
            Object.values(views).forEach(v => v.classList.add('hidden'));
            views[tab.dataset.target].classList.remove('hidden');

            if (tab.dataset.target === 'clipboard') {
                syncSystemClipboard();
            }
        });
    });

    // 2. Инициализация вкладок
    loadDrafts();
    loadSnippets();
    loadClipboard();

    // 3. Обработчики кнопок
    document.getElementById('add-snip').addEventListener('click', addSnippet);
    document.getElementById('clear-drafts').addEventListener('click', clearDrafts);
    document.getElementById('clear-clipboard').addEventListener('click', clearClipboard);
    
    // НОВЫЕ ОБРАБОТЧИКИ: Экспорт и Импорт шаблонов
    document.getElementById('export-snip').addEventListener('click', exportSnippets);
    document.getElementById('import-snip').addEventListener('click', () => document.getElementById('import-file').click());
    document.getElementById('import-file').addEventListener('change', importSnippets);
    
    // Кнопка для открытия системных настроек горячих клавиш Chrome
    document.getElementById('open-shortcuts').addEventListener('click', () => {
        chrome.tabs.create({ url: 'chrome://extensions/shortcuts' });
    });
});

function showNotification(msg, type = 'error') {
    const notif = document.getElementById('notification');
    notif.textContent = msg;
    notif.className = type === 'error' ? 'notif-error' : 'notif-success';
    notif.classList.remove('notif-hidden');
    setTimeout(() => notif.classList.add('notif-hidden'), 3000);
}

// --- ЛОГИКА ЧЕРНОВИКОВ ---
function loadDrafts() {
    chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
        const currentUrl = new URL(tabs[0].url);
        const host = currentUrl.hostname;
        document.getElementById('current-host').textContent = host;

        chrome.storage.local.get(null, (items) => {
            const list = document.getElementById('drafts-list');
            list.innerHTML = '';
            
            const prefix = `uts_draft_${host}_`;
            const drafts = Object.keys(items)
                .filter(key => key.startsWith(prefix))
                .map(key => { return { ...items[key], _storageKey: key }; });

            if (drafts.length === 0) {
                list.innerHTML = `<div class="empty-state">${chrome.i18n.getMessage("emptyDrafts")}</div>`;
                return;
            }

            const draftsByPath = {};
            drafts.forEach(draft => {
                const path = draft.path || 'Unknown';
                if (!draftsByPath[path]) draftsByPath[path] = [];
                draftsByPath[path].push(draft);
            });

            Object.keys(draftsByPath).forEach(path => {
                const groupDrafts = draftsByPath[path];
                const groupContainer = document.createElement('div');
                groupContainer.className = 'group-container';

                const groupHeader = document.createElement('div');
                groupHeader.className = 'group-header';
                groupHeader.innerHTML = `
                    <div class="group-title">📄 ${path}</div>
                    <button class="restore-group-btn" style="background: #10b981; font-size: 11px; padding: 4px 8px;">${t("restoreAllBtn")}</button>
                `;

                groupHeader.querySelector('.restore-group-btn').addEventListener('click', () => {
                    let successCount = 0;
                    let failCount = 0;
                    let processed = 0;

                    groupDrafts.forEach(draft => {
                        if (!draft.history || draft.history.length === 0) {
                            processed++;
                            return;
                        }
                        
                        chrome.tabs.sendMessage(tabs[0].id, {
                            action: 'restoreDraft',
                            id: draft.id,
                            value: draft.history[0].value
                        }, (response) => {
                            processed++;
                            if (chrome.runtime.lastError || !response || !response.success) failCount++;
                            else successCount++;

                            if (processed === groupDrafts.length) {
                                if (failCount > 0) showNotification(`${successCount} ok. ${failCount} err.`, 'error');
                                else {
                                    showNotification(t("msgRestored"), 'success');
                                    setTimeout(() => window.close(), 1500);
                                }
                            }
                        });
                    });
                });

                groupContainer.appendChild(groupHeader);

                groupDrafts.forEach(draft => {
                    if (!draft.history || draft.history.length === 0) return;
                    const latest = draft.history[0];
                    const card = document.createElement('div');
                    card.className = 'card';
                    const displayId = draft.id.replace(host + '_', '').substring(0, 20);

                    const safeValue = typeof latest.value === 'boolean' 
                        ? (latest.value ? '☑' : '☐') 
                        : latest.value.replace(/</g, "&lt;").replace(/>/g, "&gt;");

                    card.innerHTML = `
                        <div class="card-title">#${displayId}...</div>
                        <div class="card-time">${new Date(latest.time).toLocaleTimeString()}</div>
                        <div class="card-text">${safeValue}</div>
                        <div class="card-actions">
                            <button class="restore-btn" data-id="${draft.id}">${t("restoreBtn")}</button>
                            <button class="danger delete-draft-btn" style="font-size: 11px;">${t("deleteBtn")}</button>
                        </div>
                    `;
                    
                    // ИСПРАВЛЕННЫЙ БЛОК: Убрано дублирование обработчика restore-btn
                    card.querySelector('.restore-btn').addEventListener('click', () => {
                        chrome.tabs.sendMessage(tabs[0].id, {
                            action: 'restoreDraft',
                            id: draft.id,
                            value: latest.value
                        }, (response) => {
                            if (chrome.runtime.lastError || !response || !response.success) {
                                showNotification(t("msgError"));
                            } else {
                                showNotification(t("msgRestored"), 'success');
                                setTimeout(() => window.close(), 1000);
                            }
                        });
                    });

                    card.querySelector('.delete-draft-btn').addEventListener('click', () => {
                        chrome.storage.local.remove(draft._storageKey, () => {
                            loadDrafts(); 
                            showNotification(t("msgDeleted"), 'success');
                        });
                    });
                    
                    groupContainer.appendChild(card);
                });

                list.appendChild(groupContainer);
            });
        });
    });
}

function clearDrafts() {
    chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
        const host = new URL(tabs[0].url).hostname;
        const prefix = `uts_draft_${host}_`;
        chrome.storage.local.get(null, (items) => {
            const keysToRemove = Object.keys(items).filter(k => k.startsWith(prefix));
            chrome.storage.local.remove(keysToRemove, () => loadDrafts());
        });
    });
}

let editingSnippetId = null; // Переменная для отслеживания редактируемого шаблона

// --- ЛОГИКА ШАБЛОНОВ ---
function loadSnippets() {
    chrome.storage.local.get(['uts_snippets'], (res) => {
        const snippets = res.uts_snippets || [];
        const list = document.getElementById('snippets-list');
        list.innerHTML = '';
        
        snippets.forEach(snip => {
            const card = document.createElement('div');
            card.className = 'card';
            card.innerHTML = `
                <div style="display:flex; justify-content: space-between; align-items: flex-start;">
                    <div class="card-title" style="color: #4ade80;">${snip.trigger}</div>
                    <div>
                        <button class="edit-icon-btn edit-snip" data-id="${snip.id}" title="Редактировать">✎</button>
                        <button class="danger delete-snip" data-id="${snip.id}">${t("deleteBtn")}</button>
                    </div>
                </div>
                <div class="card-text">${snip.text}</div>
            `;
            
            // Обработчик для кнопки редактирования (карандашик)
            card.querySelector('.edit-snip').addEventListener('click', () => {
                document.getElementById('snip-trigger').value = snip.trigger;
                document.getElementById('snip-text').value = snip.text;
                
                // Меняем текст главной кнопки и запоминаем ID шаблона
                document.getElementById('add-snip').textContent = '💾 ' + t("addSnippetBtn"); 
                editingSnippetId = snip.id; 
                document.getElementById('snip-text').focus();
            });

            card.querySelector('.delete-snip').addEventListener('click', () => {
                const newSnippets = snippets.filter(s => s.id !== snip.id);
                chrome.storage.local.set({ uts_snippets: newSnippets }, loadSnippets);
            });
            list.appendChild(card);
        });
    });
}

function addSnippet() {
    const triggerInput = document.getElementById('snip-trigger');
    const textInput = document.getElementById('snip-text');
    let trigger = triggerInput.value.trim();
    const text = textInput.value.trim();
    
    if (!trigger || !text) return;
    if (!trigger.startsWith('/')) trigger = '/' + trigger; 
    
    chrome.storage.local.get(['uts_snippets'], (res) => {
        let snippets = res.uts_snippets || [];
        
        if (editingSnippetId) {
            // Если мы находимся в режиме редактирования
            snippets = snippets.map(s => s.id === editingSnippetId ? { ...s, trigger, text } : s);
            editingSnippetId = null; // Сбрасываем режим редактирования
            document.getElementById('add-snip').textContent = t("addSnippetBtn"); // Возвращаем стандартный текст кнопке
        } else {
            // Если это новый шаблон
            snippets.push({ id: Date.now(), trigger, text });
        }
        
        chrome.storage.local.set({ uts_snippets: snippets }, () => {
            triggerInput.value = '';
            textInput.value = '';
            loadSnippets();
        });
    });
}

// --- ФУНКЦИИ ЭКСПОРТА И ИМПОРТА ШАБЛОНОВ ---
function exportSnippets() {
    chrome.storage.local.get(['uts_snippets'], (res) => {
        const snippets = res.uts_snippets || [];
        // Превращаем массив шаблонов в красивый JSON-текст
        const blob = new Blob([JSON.stringify(snippets, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        
        // Создаем невидимую ссылку и "кликаем" по ней для скачивания
        const a = document.createElement('a');
        a.href = url;
        a.download = 'uts_snippets_backup.json';
        a.click();
        
        URL.revokeObjectURL(url);
        showNotification(t("msgExported"), 'success');
    });
}

function importSnippets(e) {
    const file = e.target.files[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = (event) => {
        try {
            const imported = JSON.parse(event.target.result);
            if (!Array.isArray(imported)) throw new Error("Format error");
            
            chrome.storage.local.get(['uts_snippets'], (res) => {
                let current = res.uts_snippets || [];
                
                // Умное слияние: обновляем существующие или добавляем новые
                imported.forEach(imp => {
                    if (imp.trigger && imp.text) {
                        const existingIndex = current.findIndex(c => c.trigger === imp.trigger);
                        if (existingIndex >= 0) {
                            current[existingIndex].text = imp.text; 
                        } else {
                            current.push({ id: Date.now() + Math.random(), trigger: imp.trigger, text: imp.text });
                        }
                    }
                });
                
                chrome.storage.local.set({ uts_snippets: current }, () => {
                    loadSnippets();
                    showNotification(t("msgImported"), 'success');
                });
            });
        } catch (err) {
            showNotification(t("msgImportError"), 'error');
        }
    };
    reader.readAsText(file);
    e.target.value = ''; // Сбрасываем input, чтобы можно было загрузить тот же файл повторно
}

// --- Чтение системного буфера ---
async function syncSystemClipboard() {
    try {
        const clipboardItems = await navigator.clipboard.read();
        for (const clipboardItem of clipboardItems) {
            let newItem = null;
            const imageTypes = clipboardItem.types.filter(type => type.startsWith('image/'));
            if (imageTypes.length > 0) {
                const blob = await clipboardItem.getType(imageTypes[0]);
                const base64 = await blobToBase64(blob);
                newItem = { type: 'image', text: base64, cleaned: false, time: Date.now() };
            } 
            else if (clipboardItem.types.includes('text/plain')) {
                const blob = await clipboardItem.getType('text/plain');
                const text = await blob.text();
                let cleanedText = text;
                let cleaned = false;
                if (text.includes('utm_')) {
                    try {
                        let url = new URL(text);
                        Array.from(url.searchParams.keys()).forEach(key => {
                            if (key.startsWith('utm_')) url.searchParams.delete(key);
                        });
                        cleanedText = url.toString();
                    } catch (e) {
                        cleanedText = text.replace(/([?&]utm_[^&#]+)/g, '').replace(/(\?$)/, '');
                    }
                    cleaned = text !== cleanedText;
                }
                newItem = { type: 'text', text: cleanedText, cleaned: cleaned, time: Date.now() };
            }

            if (newItem) {
                chrome.storage.local.get(['uts_clipboard'], (res) => {
                    let clipboard = res.uts_clipboard || [];
                    if (clipboard.length === 0 || clipboard[0].text !== newItem.text) {
                        newItem.pinned = false;
                        clipboard.unshift(newItem);
                        let unpinnedCount = clipboard.filter(c => !c.pinned).length;
                        if (unpinnedCount > 20) {
                            for (let i = clipboard.length - 1; i >= 0; i--) {
                                if (!clipboard[i].pinned) {
                                    clipboard.splice(i, 1);
                                    break;
                                }
                            }
                        }
                        chrome.storage.local.set({ uts_clipboard: clipboard }, loadClipboard);
                    }
                });
            }
            break; 
        }
    } catch (err) {}
}

function blobToBase64(blob) {
    return new Promise((resolve, _) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result);
        reader.readAsDataURL(blob);
    });
}

// --- ЛОГИКА БУФЕРА ОБМЕНА ---
function loadClipboard() {
    chrome.storage.local.get(['uts_clipboard'], (res) => {
        const clipboard = res.uts_clipboard || [];
        const list = document.getElementById('clipboard-list');
        list.innerHTML = '';
        
        if (clipboard.length === 0) {
            list.innerHTML = `<div class="empty-state">${t("emptyClipboard")}</div>`;
            return;
        }

        clipboard.sort((a, b) => {
            if (a.pinned && !b.pinned) return -1;
            if (!a.pinned && b.pinned) return 1;
            return b.time - a.time;
        });

        clipboard.forEach(item => {
            const card = document.createElement('div');
            card.className = 'card';
            card.style.cursor = 'pointer';
            
            if (item.pinned) card.style.borderColor = '#eab308';
            
            let badge = item.cleaned ? `<span style="background: #064e3b; color: #34d399; padding: 2px 4px; border-radius: 4px; font-size: 10px; margin-left: 8px;">${t("utmCleaned")}</span>` : '';
            let contentHtml = '';
            const itemType = item.type || 'text';
            
            if (itemType === 'image') {
                contentHtml = `<div style="margin-top: 8px; background: #0f172a; border: 1px solid #334155; border-radius: 4px; padding: 4px; display: flex; justify-content: center;"><img src="${item.text}" style="height: 50px; max-width: 100%; object-fit: contain; border-radius: 2px;" /></div>`;
            } else {
                const safeText = item.text.replace(/</g, "&lt;").replace(/>/g, "&gt;");
                contentHtml = `<div class="card-text">${safeText}</div>`;
            }

            const actionsHtml = `
                <div style="display: flex; align-items: center;">
                    ${itemType === 'text' ? `<button class="snippet-btn">+ ${t("tabSnippets")}</button>` : ''}
                    <button class="pin-btn ${item.pinned ? 'active' : ''}">★</button>
                    <button class="delete-icon-btn">✕</button>
                </div>
            `;

            card.innerHTML = `
                <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                    <div class="card-time">${new Date(item.time).toLocaleTimeString()} ${badge}</div>
                    ${actionsHtml}
                </div>
                ${contentHtml}
            `;
            
            card.addEventListener('click', async () => {
                try {
                    if (itemType === 'image') {
                        const response = await fetch(item.text);
                        const blob = await response.blob();
                        await navigator.clipboard.write([new ClipboardItem({ [blob.type]: blob })]);
                    } else {
                        await navigator.clipboard.writeText(item.text);
                    }
                    card.style.borderColor = '#4ade80';
                    showNotification(t("msgCopied"), 'success');
                    setTimeout(() => card.style.borderColor = '#334155', 500);
                } catch (e) {
                    showNotification('Copy failed.', 'error');
                }
            });

            if (itemType === 'text') {
                card.querySelector('.snippet-btn').addEventListener('click', (e) => {
                    e.stopPropagation(); 
                    document.querySelector('.tab[data-target="snippets"]').click();
                    document.getElementById('snip-text').value = item.text;
                    document.getElementById('snip-trigger').focus();
                    showNotification(t("msgSnippetAdded"), 'success');
                });
            }

            card.querySelector('.pin-btn').addEventListener('click', (e) => {
                e.stopPropagation();
                chrome.storage.local.get(['uts_clipboard'], (res) => {
                    let currentClipboard = res.uts_clipboard || [];
                    let target = currentClipboard.find(c => c.time === item.time);
                    if (target) {
                        target.pinned = !target.pinned;
                        chrome.storage.local.set({ uts_clipboard: currentClipboard }, loadClipboard);
                    }
                });
            });

            card.querySelector('.delete-icon-btn').addEventListener('click', (e) => {
                e.stopPropagation(); 
                chrome.storage.local.get(['uts_clipboard'], (res) => {
                    let currentClipboard = res.uts_clipboard || [];
                    currentClipboard = currentClipboard.filter(c => c.time !== item.time);
                    chrome.storage.local.set({ uts_clipboard: currentClipboard }, loadClipboard);
                });
            });
            
            list.appendChild(card);
        });
    });
}

function clearClipboard() {
    chrome.storage.local.get(['uts_clipboard'], (res) => {
        let clipboard = res.uts_clipboard || [];
        const pinnedItems = clipboard.filter(item => item.pinned);
        chrome.storage.local.set({ uts_clipboard: pinnedItems }, () => {
            loadClipboard(); 
            showNotification(t("msgCleared"), 'success');
        });
    });
}