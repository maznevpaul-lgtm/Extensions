// --- background.js (Слушает системные горячие клавиши) ---

chrome.commands.onCommand.addListener((command) => {
    // Ловим нажатие горячей клавиши для Дзен-режима
    if (command === 'toggle-zen') {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (tabs.length > 0) {
                // Отправляем сигнал на активную вкладку, с обработкой ошибок для запрещенных страниц
                chrome.tabs.sendMessage(tabs[0].id, { action: 'toggleZenMode' })
                    .catch((err) => console.log('Дзен-режим недоступен на этой странице (например, в настройках или магазине Chrome).', err));
            }
        });
    }
});