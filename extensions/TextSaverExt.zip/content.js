// --- content.js (Работает внутри веб-страниц) ---

let snippets = [];
let saveTimeout = null;

// 1. Загружаем шаблоны
chrome.storage.local.get(['uts_snippets'], (res) => {
    snippets = res.uts_snippets || [];
});

chrome.storage.onChanged.addListener((changes) => {
    if (changes.uts_snippets) snippets = changes.uts_snippets.newValue;
});

// Улучшенная функция определения элемента (меньше ложных срабатываний индексов)
function getElementIdentifier(el) {
    if (el.id) return el.id;
    if (el.getAttribute('data-testid')) return el.getAttribute('data-testid');
    if (el.name) return el.name;
    if (el.getAttribute('aria-label')) return el.getAttribute('aria-label').substring(0, 30);
    if (el.placeholder) return el.placeholder.substring(0, 30);
    
    let path = el.tagName.toLowerCase();
    if (el.className && typeof el.className === 'string') {
        // ИСПРАВЛЕНИЕ: Экранируем спецсимволы в классах (например, ":" или "/" в Tailwind)
        const classes = el.className.trim().split(/\s+/);
        for (let c of classes) {
            if (c) path += '.' + CSS.escape(c);
        }
    }
    
    try {
        const elementsLikeThis = Array.from(document.querySelectorAll(path));
        const index = elementsLikeThis.indexOf(el);
        return `${path}_${index}`;
    } catch (e) {
        // Запасной вариант: если селектор всё-таки сломался, возвращаем случайный или базовый ID
        return `${el.tagName.toLowerCase()}_${Math.random().toString(36).substring(2, 9)}`;
    }
}

// 2. Слушатель ввода текста (Автосохранение + Шаблоны)
document.addEventListener('input', (e) => {
    const el = e.target;
    const isStandardInput = (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA');
    const isContentEditable = el.isContentEditable;
    
    if (!isStandardInput && !isContentEditable) return;
    if (el.type === 'password' || el.type === 'hidden') return;

    let triggered = false;

    snippets.forEach(snippet => {
        if (isStandardInput) {
            const cursorPos = el.selectionStart;
            const textBefore = el.value.substring(0, cursorPos);
            
            if (textBefore.endsWith(snippet.trigger)) {
                // ИСПРАВЛЕНИЕ: Используем execCommand для сохранения истории Ctrl+Z
                el.setSelectionRange(cursorPos - snippet.trigger.length, cursorPos);
                document.execCommand('insertText', false, snippet.text);
                triggered = true;
            }
        } 
        else if (isContentEditable) {
            const selection = window.getSelection();
            if (selection.rangeCount > 0) {
                const range = selection.getRangeAt(0);
                const node = range.startContainer;

                if (node.nodeType === Node.TEXT_NODE) {
                    const cursorPos = range.startOffset;
                    const textBefore = node.textContent.substring(0, cursorPos);

                    if (textBefore.endsWith(snippet.trigger)) {
                        // Выделяем триггер
                        const newRange = document.createRange();
                        newRange.setStart(node, cursorPos - snippet.trigger.length);
                        newRange.setEnd(node, cursorPos);
                        selection.removeAllRanges();
                        selection.addRange(newRange);
                        
                        // Вставляем текст, сохраняя Undo-стек
                        document.execCommand('insertText', false, snippet.text);
                        triggered = true;
                    }
                } 
                else if (el.innerText.includes(snippet.trigger)) {
                    el.innerText = el.innerText.replace(snippet.trigger, snippet.text);
                    const newRange = document.createRange();
                    newRange.selectNodeContents(el);
                    newRange.collapse(false);
                    selection.removeAllRanges();
                    selection.addRange(newRange);
                    triggered = true;
                }
            }
        }
    });

    if (triggered) {
        el.dispatchEvent(new Event('input', { bubbles: true }));
    }

    clearTimeout(saveTimeout);
    saveTimeout = setTimeout(() => saveDraft(el), 1000);
});

document.addEventListener('change', (e) => {
    const el = e.target;
    if (el.tagName === 'INPUT' && (el.type === 'checkbox' || el.type === 'radio') || el.tagName === 'SELECT') {
        saveDraft(el);
    }
});

function saveDraft(el) {
    const identifier = getElementIdentifier(el);
    if (!identifier) return;

    const host = window.location.hostname;
    const pathname = window.location.pathname; 
    const cssSelector = el.id ? `#${el.id}` : (el.name ? `[name="${el.name}"]` : null);
    const key = `uts_draft_${host}_${identifier}`;
    
    let value;
    if (el.type === 'checkbox') value = el.checked;
    else if (el.isContentEditable) value = el.innerText;
    else value = el.value;

    if (value === '' || value === false) return; 

    try {
        chrome.storage.local.get([key], (res) => {
            let data = res[key] || { 
                id: identifier, 
                host: host, 
                path: pathname, 
                selector: cssSelector, 
                history: [] 
            };
            
            if (data.history.length === 0 || data.history[0].value !== value) {
                data.history.unshift({ time: Date.now(), value: value });
                if (data.history.length > 10) data.history.pop();
                chrome.storage.local.set({ [key]: data });
            }
        });
    } catch (e) {
        if (e.message.includes('Extension context invalidated')) {
            console.log('Спасатель текста: Расширение обновлено. Обновите вкладку (F5).');
        }
    }
}

// 3. Умный буфер обмена (СИНХРОННЫЙ ПЕРЕХВАТ)
document.addEventListener('copy', (e) => {
    let text = window.getSelection().toString();
    if (!text) return;

    const originalText = text;
    let cleaned = false;

    if (text.includes('utm_')) {
        try {
            let url = new URL(text);
            Array.from(url.searchParams.keys()).forEach(key => {
                if (key.startsWith('utm_')) url.searchParams.delete(key);
            });
            text = url.toString();
            cleaned = text !== originalText;
        } catch (err) {
            text = text.replace(/([?&]utm_[^&#]+)/g, '').replace(/(\?$)/, '');
            cleaned = text !== originalText;
        }
    }

    // Если мы почистили ссылку, подменяем буфер ПРЯМО В СОБЫТИИ
    if (cleaned && e.clipboardData) {
        e.clipboardData.setData('text/plain', text);
        e.preventDefault();
    }

    // А сохранение в Storage делаем асинхронно
    setTimeout(() => {
        try {
            chrome.storage.local.get(['uts_clipboard'], (res) => {
                let clipboard = res.uts_clipboard || [];
                clipboard.unshift({ 
                    type: 'text', 
                    text: text, 
                    cleaned: cleaned, 
                    time: Date.now(),
                    pinned: false
                });
                
                let unpinnedCount = clipboard.filter(c => !c.pinned).length;
                if (unpinnedCount > 20) {
                    for (let i = clipboard.length - 1; i >= 0; i--) {
                        if (!clipboard[i].pinned) {
                            clipboard.splice(i, 1);
                            break;
                        }
                    }
                }
                chrome.storage.local.set({ uts_clipboard: clipboard });
            });
        } catch (err) {
            // Контекст инвалидирован
        }
    }, 0);
});

// 4. Дзен-режим (двойной клик)
document.addEventListener('dblclick', (e) => {
    if (e.target.tagName === 'TEXTAREA') openZenMode(e.target);
});

function openZenMode(sourceEl) {
    if (document.getElementById('uts-zen-overlay')) return;

    const overlay = document.createElement('div');
    overlay.id = 'uts-zen-overlay';
    overlay.style.cssText = 'position:fixed;top:0;left:0;width:100vw;height:100vh;background:#fdfdfc;z-index:2147483647;display:flex;flex-direction:column;align-items:center;padding:10vh 10vw;box-sizing:border-box;font-family:serif;';
    
    const header = document.createElement('div');
    header.style.cssText = 'width:100%;max-width:800px;text-align:right;margin-bottom:20px;';
    
    // Получаем перевод для кнопки из Chrome i18n
    const btnText = chrome.i18n.getMessage("zenReturn") || "Return (Esc)";
    header.innerHTML = `<button id="uts-zen-close" style="padding:8px 16px;background:none;border:1px solid #ccc;border-radius:20px;cursor:pointer;color:#555;">${btnText}</button>`;

    const textarea = document.createElement('textarea');
    textarea.style.cssText = 'width:100%;max-width:800px;flex:1;border:none;outline:none;background:transparent;font-size:24px;line-height:1.6;color:#333;resize:none;';
    textarea.value = sourceEl.value;

    overlay.appendChild(header);
    overlay.appendChild(textarea);
    document.body.appendChild(overlay);

    textarea.focus();

    textarea.addEventListener('input', () => {
        sourceEl.value = textarea.value;
        sourceEl.dispatchEvent(new Event('input', { bubbles: true }));
    });

    const closeZen = () => {
        document.body.removeChild(overlay);
        // ИСПРАВЛЕНИЕ: Возвращаем фокус на исходный элемент!
        sourceEl.focus(); 
    };
    
    document.getElementById('uts-zen-close').addEventListener('click', closeZen);
    
    const escapeListener = (e) => {
        if (e.key === 'Escape' && document.getElementById('uts-zen-overlay')) {
            closeZen();
            document.removeEventListener('keydown', escapeListener);
        }
    };
    document.addEventListener('keydown', escapeListener);
}

// 5. Прием сообщений 
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'toggleZenMode') {
        const activeEl = document.activeElement;
        if (activeEl && activeEl.tagName === 'TEXTAREA') {
            const existingOverlay = document.getElementById('uts-zen-overlay');
            if (existingOverlay) document.getElementById('uts-zen-close').click();
            else openZenMode(activeEl);
        }
        // Не возвращаем true для синхронных действий
        return;
    }

    if (request.action === 'restoreDraft') {
        let el = document.getElementById(request.id) || document.getElementsByName(request.id)[0];
                 
        if (!el && request.id.includes('_')) {
            const pathParts = request.id.split('_');
            const index = pathParts.pop(); 
            const path = pathParts.join('_'); 
            
            try {
                const elements = document.querySelectorAll(path);
                if (elements[index]) el = elements[index];
            } catch(e) {}
        }

        if (el) {
            if (el.type === 'checkbox') el.checked = request.value;
            else if (el.isContentEditable) el.innerText = request.value;
            else el.value = request.value;
            
            el.dispatchEvent(new Event('input', { bubbles: true }));
            el.dispatchEvent(new Event('change', { bubbles: true }));
            
            const originalBg = el.style.backgroundColor;
            el.style.transition = 'background-color 0.5s';
            el.style.backgroundColor = '#dcfce7';
            setTimeout(() => el.style.backgroundColor = originalBg, 1000);
            
            sendResponse({success: true});
        } else {
            sendResponse({success: false});
        }
        // Возвращаем true ТОЛЬКО здесь, так как используем асинхронный sendResponse
        return true; 
    }
});