// ================== SMART TYPOGRAPHER content.js ==================

const sysLang = (navigator.language || (chrome.i18n ? chrome.i18n.getUILanguage() : 'en')).toLowerCase().startsWith('ru') ? 'ru' : 'en';
const loc = {
    en: { clickFormat: "Click to format", chars: "Chars: ", limitExceeded: "Limits exceeded (insertion blocked)", openWindow: "Open extension window" },
    ru: { clickFormat: "Кликните для форматирования", chars: "Символов: ", limitExceeded: "Превышены лимиты (вставка заблокирована)", openWindow: "Открыть окно расширения" }
}[sysLang];

let activeElement = null; 
let lastKnownEditable = null;
let pickerMode = false; let floatingWrap = null;
let isBtnDragged = false; let isSiteDisabled = false; let customFontsReady = Promise.resolve(); let inlineWindow = null;
const currentHostname = window.location.hostname;

function isExtValid() { try { return typeof chrome !== 'undefined' && chrome.runtime && !!chrome.runtime.id; } catch (e) { return false; } }
function escapeHTML(str) { return String(str || '').replace(/[&<>"']/g, s => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[s])); }

function sanitizeInlineRichHTML(html) {
    const temp = document.createElement('div'); temp.innerHTML = html || '';
    function walk(node) {
        if (node.nodeType === Node.TEXT_NODE) return escapeHTML(node.nodeValue || ''); 
        if (node.nodeType !== Node.ELEMENT_NODE) return '';
        const tag = node.tagName.toLowerCase(); 
        if (tag === 'br') return '<br>';
        let inner = ''; node.childNodes.forEach(child => { inner += walk(child); });
        
        const fw = node.style ? node.style.fontWeight : '';
        let isBold = tag === 'b' || tag === 'strong' || fw === 'bold' || fw === '700' || fw === 'bolder' || parseInt(fw, 10) >= 600;
        let isItalic = tag === 'i' || tag === 'em' || (node.style && node.style.fontStyle === 'italic');
        
        // ЖЕСТКОЕ ПРАВИЛО: Игнорируем цвета сайта при первичном чтении.
        let isRed = false;

        if (isBold) inner = `<strong>${inner}</strong>`;
        if (isItalic) inner = `<em>${inner}</em>`;
        if (isRed) inner = `<span style="color:#ef4444;" class="red-text">${inner}</span>`;
        
        if (['p', 'div', 'li', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6'].includes(tag)) return inner + '<br>';
        
        return inner;
    }
    let out = ''; temp.childNodes.forEach(child => { out += walk(child); });
    return out.replace(/[\r\n]+/g, ' ').replace(/(<br>\s*){2,}/gi, '<br>').replace(/^(<br>)+/i, '').replace(/(<br>)+$/i, '');
}

async function injectCustomFonts() {
    try {
        let response, fontBasePath = 'fonts/';
        try { response = await fetch(chrome.runtime.getURL('fonts/fonts.json')); if (!response.ok) throw new Error('not found'); } catch (e) { response = await fetch(chrome.runtime.getURL('fonts.json')); fontBasePath = ''; }
        const fonts = await response.json(); const style = document.createElement('style'); let cssRules = '';
        fonts.forEach(f => { const fontId = 'ST_' + f.name.replace(/\s+/g, '_'); const fontUrl = chrome.runtime.getURL(fontBasePath + f.file); cssRules += `@font-face { font-family: '${fontId}'; src: url('${fontUrl}'); font-display: block; }\n`; });
        style.textContent = cssRules; document.head.appendChild(style);
    } catch (e) {}
}
customFontsReady = injectCustomFonts();
chrome.storage.local.get(['disabledSites'], (res) => { isSiteDisabled = (res.disabledSites || []).includes(currentHostname); });

function getEditableRoot(node) {
    if (!node) return null; let current = node.nodeType === 3 ? node.parentElement : node; if (!current) return null;
    if (current.closest && current.closest('.st-inline-window, .st-floating-wrap')) return null; 
    if (current.tagName === 'TEXTAREA') return current; 
    if (current.tagName === 'INPUT' && ['text', 'search', 'email', 'url', 'password', 'tel'].includes(current.type)) return current;
    if (current.tagName === 'IFRAME') {
        try { if (current.src && current.src.includes(chrome.runtime.id)) return null; } catch(e){}
        return current; 
    }
    let editableRoot = null;
    while (current && current !== document.body && current !== document.documentElement) { 
        if (current.isContentEditable) editableRoot = current; 
        current = current.parentElement; 
    }
    return editableRoot;
}

function updateActiveElement(el) {
    const root = getEditableRoot(el);
    if (root) {
        activeElement = root;
        lastKnownEditable = root;
        return true;
    }
    return false;
}

function getTargetElement() {
    if (activeElement && document.body.contains(activeElement)) return activeElement;
    if (lastKnownEditable && document.body.contains(lastKnownEditable)) return lastKnownEditable;
    return getEditableRoot(document.activeElement);
}

function getIframeDocument(iframe) { try { return iframe.contentDocument || iframe.contentWindow.document; } catch (e) { return null; } }
function getActiveText() {
    const el = getTargetElement(); if (!el) return '';
    if (el.tagName === 'IFRAME') { const doc = getIframeDocument(el); return doc && doc.body ? SmartTypography.cleanLineBreaksForInsert(doc.body.innerText || doc.body.textContent || '') : ''; }
    return SmartTypography.cleanLineBreaksForInsert(el.isContentEditable ? el.innerText : el.value);
}
function getActiveHTML() {
    const el = getTargetElement(); if (!el) return '';
    if (el.tagName === 'IFRAME') { const doc = getIframeDocument(el); return doc && doc.body ? sanitizeInlineRichHTML(doc.body.innerHTML || '') : ''; }
    return el.isContentEditable ? sanitizeInlineRichHTML(el.innerHTML || '') : escapeHTML(el.value || '').replace(/\n/g, '<br>');
}

function dispatchEditorEvents(el) {
    if (!el) return;
    try { el.dispatchEvent(new InputEvent('input', { bubbles: true, cancelable: true, inputType: 'insertText' })); } catch (e) { el.dispatchEvent(new Event('input', { bubbles: true })); }
    el.dispatchEvent(new Event('change', { bubbles: true }));
}

function replacePlainInput(el, text) {
    const safeText = SmartTypography.cleanLineBreaksForInsert(text); el.focus();
    const isTextarea = el.tagName === 'TEXTAREA'; const nativeSetter = Object.getOwnPropertyDescriptor(isTextarea ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype, 'value');
    if (nativeSetter && nativeSetter.set) nativeSetter.set.call(el, safeText); else el.value = safeText;
    dispatchEditorEvents(el);
}

function executeSmartReplace(root, doc, html, plain) {
    root.focus(); const isMac = navigator.platform.toUpperCase().indexOf('MAC') >= 0;
    root.dispatchEvent(new KeyboardEvent('keydown', { key: 'a', code: 'KeyA', keyCode: 65, ctrlKey: !isMac, metaKey: isMac, bubbles: true, cancelable: true }));
    setTimeout(() => {
        try { doc.execCommand('selectAll', false, null); } catch(e) {}
        let safeHTML = html.replace(/\n/g, '<br>'); const dt = new DataTransfer(); dt.setData('text/plain', plain); dt.setData('text/html', safeHTML);
        const pasteEvent = new ClipboardEvent('paste', { bubbles: true, cancelable: true, clipboardData: dt }); root.dispatchEvent(pasteEvent);
        if (!pasteEvent.defaultPrevented) {
            const sel = doc.getSelection(); if (sel) { const range = doc.createRange(); range.selectNodeContents(root); sel.removeAllRanges(); sel.addRange(range); }
            try { doc.execCommand('delete', false, null); } catch(e) {}
            if (!doc.execCommand('insertHTML', false, safeHTML)) root.innerHTML = safeHTML;
        }
        dispatchEditorEvents(root);
    }, 50);
}

function setActiveText(text, options = {}) {
    const el = getTargetElement(); if (!el) return;
    const plainText = SmartTypography.cleanLineBreaksForInsert(options.plainText !== undefined ? options.plainText : text);
    const richHTML = options.richHTML ? sanitizeInlineRichHTML(options.richHTML) : ''; const useRich = Boolean(options.isRichText && richHTML);
    const safeHTML = useRich ? richHTML : escapeHTML(plainText);

    if (el.tagName === 'IFRAME') { const doc = getIframeDocument(el); if (doc && doc.body) executeSmartReplace(doc.body, doc, safeHTML, plainText); } 
    else if (el.isContentEditable) { executeSmartReplace(el, document, safeHTML, plainText); } 
    else { replacePlainInput(el, plainText); }
}

function checkLimitsValid(simulatedTxt, opts) {
    if (opts.checkLimits) { const limitTotal = parseInt(opts.totalChars) || 0, limitLines = parseInt(opts.lines) || 0; if (limitTotal > 0 && SmartTypography.stripMarkdownStyles(SmartTypography.stripHTMLTags(simulatedTxt)).length > limitTotal) return false; if (limitLines > 0 && simulatedTxt.split('\n').length > limitLines) return false; }
    if (opts.checkBox) {
        const limitBoxH = parseInt(opts.boxH) || 0, fontSz = parseInt(opts.fontSz) || 0, lineH = parseFloat((opts.lineH || '').toString().replace(',', '.')) || 0;
        if (limitBoxH > 0 && fontSz > 0) {
            let computedLineH = lineH === 0 ? fontSz * 1.2 : (lineH > 0 && lineH <= 3 ? fontSz * lineH : lineH);
            let lineHeightInPx = opts.unit === 'pt' ? computedLineH * ((parseInt(opts.dpi)||72) / 72) : computedLineH;
            if (simulatedTxt.split('\n').length > Math.floor(limitBoxH / lineHeightInPx)) return false;
        }
    }
    return true;
}

function formatLocally() {
    const el = getTargetElement();
    if (!el || isSiteDisabled || !isExtValid()) { hideFloatingBtn(); return; }

    chrome.storage.local.get(['st_options'], async (res) => {
        const opts = res.st_options || { num: true, cur: true, quo: true, pho: true, deg: true, hang: true, wrap: 50 };
        const isRedBoldEnabled = opts.redBold !== undefined ? opts.redBold : true;
        
        opts.stripBreaks = false; 

        await customFontsReady; 
        
        let resultPlain, resultRichHTML = '';
        const isRich = el.isContentEditable || el.tagName === 'IFRAME';
        
        if (isRich) {
            const rawHTML = getActiveHTML();
            const temp = document.createElement('div'); temp.innerHTML = rawHTML;
            
            const charStyles = [];
            let rawText = '';
            
            function extract(node) {
                if (node.nodeType === Node.TEXT_NODE) {
                    const text = node.nodeValue || '';
                    let bold = false, italic = false, red = false;
                    let cur = node.parentElement;
                    while(cur && cur !== temp) {
                        const tag = cur.tagName.toLowerCase();
                        const fw = cur.style ? cur.style.fontWeight : '';
                        if (tag === 'b' || tag === 'strong' || fw === 'bold' || fw === '700' || fw === 'bolder' || parseInt(fw, 10) >= 600) bold = true;
                        if (tag === 'em' || tag === 'i' || (cur.style && cur.style.fontStyle === 'italic')) italic = true;
                        cur = cur.parentElement;
                    }
                    
                    if (bold && isRedBoldEnabled) red = true; 

                    for(let i=0; i<text.length; i++) {
                        rawText += text[i];
                        if (/[a-zA-Zа-яА-ЯёЁ0-9]/.test(text[i])) charStyles.push({ bold, italic, red });
                    }
                } else if (node.nodeType === Node.ELEMENT_NODE) {
                    const tag = node.tagName.toLowerCase();
                    if (tag === 'br') rawText += '\n'; 
                    node.childNodes.forEach(extract);
                    if (['p', 'div', 'li', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6'].includes(tag)) {
                        rawText += '\n'; 
                    }
                }
            }
            temp.childNodes.forEach(extract);
            
            rawText = SmartTypography.cleanLineBreaksForInsert(rawText);
            resultPlain = SmartTypography.applyAll(rawText, opts);
            
            let activeStyle = { bold: false, italic: false, red: false };
            let state = { bold: false, italic: false, red: false };
            
            const applyState = (newState) => {
                if (state.italic !== newState.italic || state.bold !== newState.bold || state.red !== newState.red) {
                    if (state.red) resultRichHTML += '</span>';
                    if (state.italic) resultRichHTML += '</em>'; 
                    if (state.bold) resultRichHTML += '</strong>';
                    if (newState.bold) resultRichHTML += '<strong>'; 
                    if (newState.italic) resultRichHTML += '<em>'; 
                    if (newState.red) resultRichHTML += '<span style="color:#ef4444;" class="red-text">';
                }
                state = { ...newState };
            };
            
            for(let i=0; i<resultPlain.length; i++) {
                const char = resultPlain[i];
                if (char === '\n') { applyState({ bold: false, italic: false, red: false }); resultRichHTML += '<br>'; continue; }
                if (/[a-zA-Zа-яА-ЯёЁ0-9]/.test(char) && charStyles.length > 0) activeStyle = charStyles.shift();
                applyState(activeStyle);
                resultRichHTML += escapeHTML(char);
            }
            applyState({ bold: false, italic: false, red: false });
            
        } else {
            let rawText = getActiveText();
            resultPlain = SmartTypography.applyAll(rawText, opts);
        }

        const mainBtn = floatingWrap ? floatingWrap.querySelector('.st-main-btn') : null;
        
        if (!checkLimitsValid(resultPlain, opts)) {
            if (mainBtn) { const origBg = mainBtn.style.background; mainBtn.style.background = '#ef4444'; setTimeout(() => { if (mainBtn) mainBtn.style.background = origBg; }, 1000); }
            return;
        }

        resultPlain = resultPlain.replace(/[\u00A0\u2000-\u200A\u202F\u205F\u3000]/g, ' ');
        if (resultRichHTML) resultRichHTML = resultRichHTML.replace(/[\u00A0\u2000-\u200A\u202F\u205F\u3000]/g, ' ');
        
        setActiveText(resultPlain, { plainText: resultPlain, richHTML: resultRichHTML, isRichText: isRich });
        
        if (mainBtn) {
            const origHTML = mainBtn.innerHTML, origClass = mainBtn.className;
            mainBtn.className = 'st-floating-btn st-main-btn'; mainBtn.innerHTML = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"></polyline></svg>`; mainBtn.style.background = '#10b981';
            setTimeout(() => { if (mainBtn) { mainBtn.innerHTML = origHTML; mainBtn.style.background = ''; mainBtn.className = origClass; updateFloatingBtn(); } }, 1000);
        }
    });
}

function openInlineWindow() {
    if (inlineWindow) { inlineWindow.style.display = 'flex'; return; }
    inlineWindow = document.createElement('div'); inlineWindow.className = 'st-inline-window';
    inlineWindow.innerHTML = `<div class="st-window-header"><span>Smart Typographer</span><button class="st-window-close">&times;</button></div><iframe src="${chrome.runtime.getURL('popup.html')}?inline=1"></iframe>`;
    document.body.appendChild(inlineWindow);
    inlineWindow.style.left = (window.innerWidth / 2 - 210) + 'px'; inlineWindow.style.top = (window.innerHeight / 2 - 300) + 'px';
    const header = inlineWindow.querySelector('.st-window-header'), iframe = inlineWindow.querySelector('iframe'), closeBtn = inlineWindow.querySelector('.st-window-close');
    closeBtn.addEventListener('click', () => { inlineWindow.style.display = 'none'; });
    let isDragging = false, startX, startY, startLeft, startTop;
    header.addEventListener('mousedown', (e) => { if (e.target === closeBtn) return; isDragging = true; startX = e.clientX; startY = e.clientY; startLeft = parseInt(inlineWindow.style.left) || 0; startTop = parseInt(inlineWindow.style.top) || 0; iframe.style.pointerEvents = 'none'; });
    document.addEventListener('mousemove', (e) => { if (!isDragging) return; inlineWindow.style.left = (startLeft + e.clientX - startX) + 'px'; inlineWindow.style.top = (startTop + e.clientY - startY) + 'px'; });
    document.addEventListener('mouseup', () => { if (isDragging) { isDragging = false; iframe.style.pointerEvents = 'auto'; } });
}

function updateFloatingBtn() {
    const currentRoot = getTargetElement();
    if (isSiteDisabled || !currentRoot || !isExtValid()) { hideFloatingBtn(); return; }

    if (!floatingWrap) {
        floatingWrap = document.createElement('div'); floatingWrap.className = 'st-floating-wrap';
        floatingWrap.innerHTML = `
            <div class="st-floating-btn st-main-btn">
                <svg width="16" height="16" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" class="st-icon-default" style="fill:none!important; flex-shrink:0;"><path d="M12 20h9" style="fill:none!important;"></path><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z" style="fill:none!important;"></path></svg>
                <svg width="16" height="16" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" class="st-icon-error" style="display:none; fill:none!important; flex-shrink:0;"><circle cx="12" cy="12" r="10" style="fill:none!important;"></circle><line x1="12" y1="8" x2="12" y2="12" style="fill:none!important;"></line><line x1="12" y1="16" x2="12.01" y2="16" style="fill:none!important;"></line></svg>
                <svg width="10" height="10" viewBox="0 0 24 24" stroke="currentColor" stroke-width="3" class="st-icon-auto" style="display:none; position:absolute; top:-4px; right:-4px; color:#fbbf24; fill:none!important; flex-shrink:0;"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" style="fill:none!important;"></polygon></svg>
            </div>
            <div class="st-floating-btn st-sub-btn" title="${loc.openWindow}">
                <svg width="14" height="14" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="fill:none!important; flex-shrink:0; min-width:14px; min-height:14px;"><circle cx="12" cy="12" r="3" style="fill:none!important;"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1Z" style="fill:none!important;"></path></svg>
            </div>
            <div class="st-tooltip">
                <span class="st-tooltip-title" id="st-tooltip-title">${loc.clickFormat}</span>
                <span>${loc.chars}<b id="st-char-count">0</b></span>
            </div>
        `;
        document.body.appendChild(floatingWrap);

        const mainBtn = floatingWrap.querySelector('.st-main-btn'); const subBtn = floatingWrap.querySelector('.st-sub-btn');
        subBtn.addEventListener('click', (e) => { e.stopPropagation(); e.preventDefault(); openInlineWindow(); });

        mainBtn.addEventListener('mousedown', (e) => {
            e.preventDefault(); e.stopPropagation(); isBtnDragged = true; let isClick = true;
            const startX = e.clientX, startY = e.clientY; const offsetX = e.clientX - floatingWrap.getBoundingClientRect().left; const offsetY = e.clientY - floatingWrap.getBoundingClientRect().top;
            function onMouseMove(eMove) {
                if (Math.abs(eMove.clientX - startX) > 3 || Math.abs(eMove.clientY - startY) > 3) isClick = false;
                floatingWrap.style.left = (eMove.clientX - offsetX + window.scrollX) + 'px'; floatingWrap.style.top = (eMove.clientY - offsetY + window.scrollY) + 'px';
            }
            function onMouseUp(eUp) { eUp.preventDefault(); document.removeEventListener('mousemove', onMouseMove); document.removeEventListener('mouseup', onMouseUp); if (isClick) formatLocally(); }
            document.addEventListener('mousemove', onMouseMove); document.addEventListener('mouseup', onMouseUp);
        });
    }

    if (!isBtnDragged) {
        const el = getTargetElement();
        if (el) { 
            const rect = el.getBoundingClientRect(); 
            let btnLeft = window.scrollX + rect.right - 20; 
            let btnTop = window.scrollY + rect.top - 36;
            if (btnLeft + 36 > window.scrollX + window.innerWidth) btnLeft = window.scrollX + window.innerWidth - 40;
            if (btnLeft < window.scrollX) btnLeft = window.scrollX + 5;
            if (btnTop < window.scrollY) btnTop = window.scrollY + rect.top + 5;
            
            floatingWrap.style.left = btnLeft + 'px'; 
            floatingWrap.style.top = btnTop + 'px'; 
        }
    }

    const txt = getActiveText();
    const countSpan = document.getElementById('st-char-count'); if (countSpan) countSpan.textContent = txt.length;

    chrome.storage.local.get(['st_options'], (res) => {
        if (!floatingWrap) return; const opts = res.st_options || {};
        const iconAuto = floatingWrap.querySelector('.st-icon-auto'); if (iconAuto) iconAuto.style.display = opts.auto ? 'block' : 'none';
        const simulatedTxt = SmartTypography.applyAll(txt, opts); const isValid = checkLimitsValid(simulatedTxt, opts);
        const title = document.getElementById('st-tooltip-title'); const iconDefault = floatingWrap.querySelector('.st-icon-default'); const iconError = floatingWrap.querySelector('.st-icon-error');

        if (!isValid) {
            floatingWrap.querySelector('.st-main-btn').classList.add('st-error-btn');
            if (title) title.textContent = loc.limitExceeded;
            if (iconDefault) iconDefault.style.display = 'none'; if (iconError) iconError.style.display = 'block';
        } else {
            floatingWrap.querySelector('.st-main-btn').classList.remove('st-error-btn');
            if (title) title.textContent = loc.clickFormat;
            if (iconDefault) iconDefault.style.display = 'block'; if (iconError) iconError.style.display = 'none';
        }
    });
}

function hideFloatingBtn() { if (floatingWrap) { floatingWrap.remove(); floatingWrap = null; } }

window.addEventListener('resize', () => { if (getTargetElement()) updateFloatingBtn(); });
window.addEventListener('scroll', () => { if (!isBtnDragged && getTargetElement()) updateFloatingBtn(); }, true);

function handleUserAction(e) {
    updateActiveElement(e.target);
    const el = getTargetElement();
    if (el && e.isTrusted) {
        const isRich = el.isContentEditable || el.tagName === 'IFRAME';
        const currentText = getActiveText(); const currentHTML = isRich ? getActiveHTML() : '';
        try { chrome.runtime.sendMessage({ action: 'UPDATE_TEXT_FROM_SITE', text: currentText, html: currentHTML, isRich: isRich }).catch(() => {}); } catch (err) {}
    }
}

document.addEventListener('input', (e) => { handleUserAction(e); updateFloatingBtn(); }, true);
document.addEventListener('keyup', (e) => { handleUserAction(e); }, true);

// ИСПРАВЛЕНИЕ ЗАДЕРЖКИ ПРИ ВСТАВКЕ ТЕКСТА
document.addEventListener('paste', (e) => { 
    if (updateActiveElement(e.target)) {
        setTimeout(() => { handleUserAction(e); updateFloatingBtn(); }, 50); 
    }
}, true);

document.addEventListener('focusin', (e) => {
    if (isSiteDisabled || pickerMode) return; 
    if (updateActiveElement(e.target)) { isBtnDragged = false; updateFloatingBtn(); }
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.action === 'TOGGLE_SITE') {
        isSiteDisabled = !msg.isEnabled;
        if (isSiteDisabled) { hideFloatingBtn(); pickerMode = false; document.body.classList.remove('st-picker-mode'); if (activeElement) activeElement.classList.remove('st-active-field'); activeElement = null; }
        sendResponse({ status: 'ok' }); return;
    }
    if (msg.action === 'START_PICKER') {
        if (isSiteDisabled) { sendResponse({ status: 'disabled' }); return; }
        pickerMode = true; document.body.classList.add('st-picker-mode'); sendResponse({ status: 'started' }); return;
    }
    if (msg.action === 'GET_STATE') {
        const el = getTargetElement();
        const currentText = getActiveText(); const isRich = el && (el.isContentEditable || el.tagName === 'IFRAME');
        sendResponse({ hasActive: !!el, text: currentText, html: isRich ? getActiveHTML() : '', isRich: isRich, sourceText: SmartTypography.normalizeImportedText(currentText) }); return;
    }
    if (msg.action === 'SET_TEXT') {
        const el = getTargetElement();
        if (el) {
            let incomingText = msg.text || ''; 
            let incomingPlainText = SmartTypography.cleanLineBreaksForInsert(msg.plainText !== undefined ? msg.plainText : incomingText);
            
            incomingText = incomingText.replace(/[\u00A0\u2000-\u200A\u202F\u205F\u3000]/g, ' ');
            incomingPlainText = incomingPlainText.replace(/[\u00A0\u2000-\u200A\u202F\u205F\u3000]/g, ' ');
            let rHTML = (msg.richHTML || '').replace(/[\u00A0\u2000-\u200A\u202F\u205F\u3000]/g, ' ');

            setActiveText(incomingText, { plainText: incomingPlainText, richHTML: rHTML, isRichText: Boolean(msg.isRichText) }); updateFloatingBtn();
        }
        sendResponse({ status: 'updated' }); return;
    }
    if (msg.action === 'FORMAT_ACTIVE') {
        const el = getTargetElement();
        if (el && !isSiteDisabled) { formatLocally(); }
        sendResponse({ status: 'ok' }); return;
    }
    if (msg.action === 'CLEAR_CACHE') {
        sendResponse({ status: 'ok' }); return;
    }
    sendResponse({});
});

document.addEventListener('click', (e) => {
    let temp = e.target, isExtensionUI = false;
    while (temp && temp !== document.body) {
        if (temp.classList && (temp.classList.contains('st-floating-wrap') || temp.classList.contains('st-inline-window'))) { isExtensionUI = true; break; }
        temp = temp.parentElement;
    }
    const root = getEditableRoot(e.target);
    if (pickerMode) {
        if (root) {
            e.preventDefault(); e.stopPropagation(); pickerMode = false; document.body.classList.remove('st-picker-mode');
            if (activeElement) activeElement.classList.remove('st-active-field');
            updateActiveElement(root); activeElement.classList.add('st-active-field'); isBtnDragged = false; updateFloatingBtn();
        }
    } else {
        if (!root && !isExtensionUI) hideFloatingBtn(); else if (root) { updateActiveElement(root); updateFloatingBtn(); }
    }
}, true);