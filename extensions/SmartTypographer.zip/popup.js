// ================== SMART TYPOGRAPHER popup.js ==================

const sysLang = (navigator.language || (chrome.i18n ? chrome.i18n.getUILanguage() : 'en')).toLowerCase().startsWith('ru') ? 'ru' : 'en';
const dict = {
    en: {
        appTitle: "Smart Typographer", enableSiteTitle: "Enable/Disable extension on site",
        on: "ON", off: "OFF", picker: "Picker", sourceText: "Source text", localMode: "Local mode",
        placeholder: "Paste text... Select text and press B or I for styles.",
        chars: "Chars: ", noSpaces: "No spaces: ", formatBtn: "Format",
        optNumbers: "Numbers (1 000)", optCurrency: "Currencies (₽, $)", optQuotes: "Quotes («»)",
        optPhones: "Dashes", optDegrees: "Degrees (m²)", optHanging: "Hanging preps.",
        optLigatures: "Ligatures (fi, fl)", optArrows: "Arrows (->)", optEllipsis: "Ellipses (...)",
        limitHeader: "Limits and wrapping (Chars)", totalCharsTip: "Total characters",
        totalChars: "Total chars:", maxLinesTip: "Maximum lines", maxLines: "Max lines:",
        wrapLinesTip: "Wrap lines at length", wrapLines: "Wrap lines at length:",
        blockHeader: "Auto-wrap and block limit", widthTip: "Width", width: "Width:",
        heightTip: "Height", height: "Height:", size: "Size:", units: "Units:", lineHeight: "Line height:",
        dpiTip: "Layout DPI", dpi: "Layout DPI:", font: "Font:", previewHeader: "Preview & Validation",
        tracking: "VA:", scaleX: "T %:",
        alignLeft: "Align left", alignCenter: "Align center", alignRight: "Align right",
        makeBold: "Make bold (Select text)", makeItalic: "Make italic (Select text)",
        btnApply: "Apply to site", btnCopyPS: "For Photoshop", btnCopyPSTip: "Copy text in Markdown format for Photoshop",
        linkedField: "Linked to field", applySuccess: "Done!", copySuccess: "Copied!",
        errChars: "Chars limit exceeded", errLines: "Lines limit exceeded", errBlock: "Does not fit in block",
        enableSiteWarn: "Enable site", reloadWarn: "Reload (F5)", siteDisabled: "Site disabled in settings!",
        copyResult: "Copy result", b: "B", i: "I",
        techTools: "Technical Tools", formatActive: "Format active field", clearCache: "Clear text cache", openFullscreen: "Open fullscreen editor",
        stripBreaks: "Strip line breaks"
    },
    ru: {
        appTitle: "Smart Typographer", enableSiteTitle: "Включить/Отключить расширение на сайте",
        on: "ВКЛ", off: "ВЫКЛ", picker: "Пипетка", sourceText: "Исходный текст", localMode: "Локальный режим",
        placeholder: "Вставьте текст... Выделите текст и нажмите Ж или К для стилей.",
        chars: "Символов: ", noSpaces: "Без пробелов: ", formatBtn: "Форматировать",
        optNumbers: "Числа (1 000)", optCurrency: "Валюты (₽, $)", optQuotes: "Кавычки («»)",
        optPhones: "Тире", optDegrees: "Степени (м²)", optHanging: "Висячие предлоги",
        optLigatures: "Лигатуры (fi, fl)", optArrows: "Стрелки (->)", optEllipsis: "Многоточия (...)",
        limitHeader: "Лимиты и переносы (Символы)", totalCharsTip: "Всего символов",
        totalChars: "Всего симв:", maxLinesTip: "Максимум строк", maxLines: "Макс. строк:",
        wrapLinesTip: "Символов в строке для переноса", wrapLines: "Перенос (Wrap):",
        blockHeader: "Авто-перенос и лимит по блоку", widthTip: "Ширина", width: "Ширина (X):",
        heightTip: "Высота", height: "Высота (Y):", size: "Размер:", units: "Единицы:", lineHeight: "Интервал:",
        dpiTip: "Разрешение макета (DPI)", dpi: "DPI макета:", font: "Шрифт:", previewHeader: "Превью и Валидация",
        tracking: "VA:", scaleX: "T %:",
        alignLeft: "По левому краю", alignCenter: "По центру", alignRight: "По правому краю",
        makeBold: "Сделать жирным (Выделите текст)", makeItalic: "Сделать курсивом (Выделите текст)",
        btnApply: "Применить к сайту", btnCopyPS: "Для Photoshop", btnCopyPSTip: "Скопировать текст в формате Markdown для Photoshop",
        linkedField: "Связано с полем", applySuccess: "Готово!", copySuccess: "Скопировано!",
        errChars: "Превышение знаков", errLines: "Превышение строк", errBlock: "Не влезает в блок",
        enableSiteWarn: "Включите сайт", reloadWarn: "Обновите (F5)", siteDisabled: "Сайт отключен в настройках!",
        copyResult: "Копировать результат", b: "Ж", i: "К",
        techTools: "Быстрые действия", formatActive: "Отформатировать активное поле", clearCache: "Очистить кэш (Сброс исходников)", openFullscreen: "Открыть полноэкранный редактор",
        stripBreaks: "Убрать переносы"
    }
};
const loc = dict[sysLang];

document.querySelectorAll('[data-i18n]').forEach(el => { el.innerHTML = loc[el.getAttribute('data-i18n')] || el.innerHTML; });
document.querySelectorAll('[data-i18n-placeholder]').forEach(el => { el.setAttribute('data-i18n-placeholder', loc[el.getAttribute('data-i18n-placeholder')] || el.getAttribute('data-i18n-placeholder')); });
document.querySelectorAll('[data-i18n-title]').forEach(el => { el.title = loc[el.getAttribute('data-i18n-title')] || el.title; });

let currentDomain = ""; let isAppReady = false; 
let isLinked = false; let processedData = "";
let isSyncingSource = false; let isSyncingPreview = false; let isAutoFormatEnabled = false;

let isProMode = false;
let profilesMap = {};
let activeProfileName = "Blogger 860x630 (Base)";

const defaultProfiles = {
    "Blogger 860x630 (Base)": {
        num: true, cur: true, quo: true, pho: true, deg: true, hang: true,
        lig: true, arr: true, ell: true,
        stripBreaks: false, checkLimits: false, wrap: 33, lines: 9, totalChars: 0,
        checkBox: true, boxW: 860, boxH: 630, fontSz: 70, lineH: 63,
        unit: 'px', dpi: 72, fontFam: 'ST_Blogger', tracking: -15, scaleX: 100
    }
};

const urlParams = new URLSearchParams(window.location.search);
const isInlineMode = urlParams.get('inline') === '1';
const isFullscreen = urlParams.get('full') === '1';
const targetTabId = urlParams.get('tabId') ? parseInt(urlParams.get('tabId'), 10) : null;

function getTargetTab(callback) {
    if (targetTabId) {
        chrome.tabs.get(targetTabId, (tab) => {
            if (chrome.runtime.lastError || !tab) { chrome.tabs.query({ active: true, currentWindow: true }, tabs => callback(tabs[0])); } 
            else { callback(tab); }
        });
    } else { chrome.tabs.query({ active: true, currentWindow: true }, tabs => callback(tabs[0])); }
}

if (isInlineMode || isFullscreen) {
    document.getElementById('editorMode').classList.remove('hidden');
    if (isInlineMode) {
        document.body.style.minWidth = '100%'; document.body.style.minHeight = '100%';
        const header = document.querySelector('.header'); if (header) header.style.display = 'none';
    } else {
        document.body.style.width = '100vw'; document.body.style.height = '100vh';
    }
} else {
    document.getElementById('controlPanelMode').classList.remove('hidden');
    document.body.style.width = '320px'; document.body.style.height = 'auto'; document.body.style.minHeight = '300px';
}

const els = {
    source: document.getElementById('sourceText'), preview: document.getElementById('previewArea'),
    previewBox: document.getElementById('previewBoundingBox'), previewWrapper: document.getElementById('previewCanvasWrapper'),
    charCount: document.getElementById('charCount'), charCountNo: document.getElementById('charCountNoSpaces'),
    btnFormat: document.getElementById('btnFormat'), btnAutoFormat: document.getElementById('btnToggleAutoFormat'),
    btnApply: document.getElementById('btnApply'), btnApplyText: document.getElementById('btnApplyText'),
    btnCopyPS: document.getElementById('btnCopyPS'), btnCopyPSText: document.getElementById('btnCopyPSText'),
    lblStatus: document.getElementById('lblStatus'), btnTogglePro: document.getElementById('btnTogglePro'),
    panelSettings: document.getElementById('settingsPanel'), 
    proAdvancedBlock: document.getElementById('proAdvancedBlock'), proLimitsGroup: document.getElementById('proLimitsGroup'),
    siteToggle: document.getElementById('siteToggle'), siteToggleLabel: document.getElementById('siteToggleLabel'),
    cpSiteToggle: document.getElementById('cpSiteToggle'), 
    cpBtnFormatActive: document.getElementById('cpBtnFormatActive'), cpBtnClearCache: document.getElementById('cpBtnClearCache'), cpBtnOpenEditor: document.getElementById('cpBtnOpenEditor'),
    stripBreaks: document.getElementById('optStripBreaks'), optRedBold: document.getElementById('optRedBold'),
    
    profileSelect: document.getElementById('profileSelect'), btnSaveProfile: document.getElementById('btnSaveProfile'),
    btnDeleteProfile: document.getElementById('btnDeleteProfile'), btnExportProfiles: document.getElementById('btnExportProfiles'),
    btnImportProfiles: document.getElementById('btnImportProfiles'), fileImportProfiles: document.getElementById('fileImportProfiles'),
    
    num: document.getElementById('optNumbers'), cur: document.getElementById('optCurrency'), quo: document.getElementById('optQuotes'),
    pho: document.getElementById('optPhones'), deg: document.getElementById('optDegrees'), hang: document.getElementById('optHanging'),
    lig: document.getElementById('optLigatures'), arr: document.getElementById('optArrows'), ell: document.getElementById('optEllipsis'),
    checkLimits: document.getElementById('optCheckLimits'), wrap: document.getElementById('optWrap'), lines: document.getElementById('optLines'),
    totalChars: document.getElementById('optTotalChars'), checkBox: document.getElementById('optCheckBox'), boxW: document.getElementById('optBoxW'),
    boxH: document.getElementById('optBoxH'), fontSz: document.getElementById('optFontSz'), lineH: document.getElementById('optLineH'),
    unit: document.getElementById('optUnit'), dpi: document.getElementById('optDpi'), fontFam: document.getElementById('optFontFam'),
    tracking: document.getElementById('optTracking'), scaleX: document.getElementById('optScaleX'),
    groupBlock: document.getElementById('groupBlock'), alignBtns: document.querySelectorAll('.btn-align'), groupLimits: document.getElementById('groupLimits')
};

document.querySelector('[data-tag="b"] b').textContent = loc.b;
document.querySelector('[data-tag="i"] i').textContent = loc.i;

if (els.preview) { els.preview.setAttribute('contenteditable', 'true'); els.preview.setAttribute('spellcheck', 'false'); els.preview.style.outline = 'none'; }

function escapeHTML(str) { return String(str || '').replace(/[&<>"']/g, s => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[s])); }

// НАДЕЖНОЕ УДАЛЕНИЕ ПЕРЕНОСОВ (включая \r\n скрытые символы)
function applyStripBreaksToSource() {
    if (!els.stripBreaks.checked) return;
    const temp = document.createElement('div');
    temp.innerHTML = els.source.innerHTML;
    
    const brs = temp.querySelectorAll('br');
    brs.forEach(br => br.replaceWith(document.createTextNode(' ')));
    
    const blocks = temp.querySelectorAll('p, div, h1, h2, h3, h4, h5, h6, li');
    blocks.forEach(block => {
        const space = document.createTextNode(' ');
        block.after(space);
        while(block.firstChild) block.parentNode.insertBefore(block.firstChild, block);
        block.remove();
    });
    
    temp.innerHTML = temp.innerHTML.replace(/&nbsp;/g, ' ').replace(/[\r\n]+/g, ' ').replace(/\s{2,}/g, ' ').trim();
    if (els.source.innerHTML !== temp.innerHTML) els.source.innerHTML = temp.innerHTML;
}

function getSourceText() {
    const temp = document.createElement('div'); temp.innerHTML = els.source.innerHTML || '';
    function walk(node) {
        if (node.nodeType === Node.TEXT_NODE) return node.nodeValue || ''; 
        if (node.nodeType !== Node.ELEMENT_NODE) return '';
        const tag = node.tagName.toLowerCase(); 
        if (tag === 'br') return els.stripBreaks.checked ? ' ' : '\n';
        let inner = ''; node.childNodes.forEach(child => { inner += walk(child); }); 
        let isBlock = ['div', 'p', 'li', 'h1', 'h2', 'h3'].includes(tag);
        return isBlock ? inner + (els.stripBreaks.checked ? ' ' : '\n') : inner;
    }
    let out = ''; temp.childNodes.forEach(child => { out += walk(child); }); 
    let cleaned = SmartTypography.cleanLineBreaksForInsert(out);
    if (els.stripBreaks.checked) cleaned = cleaned.replace(/[\r\n]+/g, ' ').replace(/\s{2,}/g, ' ');
    return cleaned;
}

function updateStats() { els.charCount.textContent = getSourceText().length; els.charCountNo.textContent = getSourceText().replace(/\s/g, '').length; }
function updateStatsFromPreview() { const txt = getPlainProcessedText(); els.charCount.textContent = txt.length; els.charCountNo.textContent = txt.replace(/\s/g, '').length; }

async function loadCustomFonts() {
    try {
        let response, fontBasePath = 'fonts/';
        try { response = await fetch(chrome.runtime.getURL('fonts/fonts.json')); if (!response.ok) throw new Error('not found'); } catch (e) { response = await fetch(chrome.runtime.getURL('fonts.json')); fontBasePath = ''; }
        const fonts = await response.json(); const style = document.createElement('style'); let cssRules = ''; const fontPromises = [];
        fonts.forEach(f => {
            const fontId = 'ST_' + f.name.replace(/\s+/g, '_'); const fontUrl = chrome.runtime.getURL(fontBasePath + f.file);
            cssRules += `@font-face { font-family: '${fontId}'; src: url('${fontUrl}'); font-display: block; }\n`;
            if (!Array.from(els.fontFam.options).some(opt => opt.value === fontId || opt.textContent === f.name)) { 
                const option = document.createElement('option'); option.value = fontId; option.textContent = f.name; els.fontFam.appendChild(option); 
            }
        });
        style.textContent = cssRules; document.head.appendChild(style);
        if (els.fontFam.value && document.fonts) fontPromises.push(document.fonts.load(`14px "${els.fontFam.value}"`));
        if (fontPromises.length) await Promise.allSettled(fontPromises);
    } catch (e) {}
}

function applyPreviewFont() { const fontFam = els.fontFam.value || 'Arial'; els.preview.style.fontFamily = `"${fontFam}", sans-serif`; if (document.fonts) document.fonts.load(`14px "${fontFam}"`).catch(() => {}); }
function updateAutoFormatBtn() { if(els.btnAutoFormat) els.btnAutoFormat.classList.toggle('active', isAutoFormatEnabled); }

function updateToggleLabel() {
    let isChecked = true;
    if (els.cpSiteToggle && !els.cpSiteToggle.classList.contains('hidden')) isChecked = els.cpSiteToggle.checked;
    else if (els.siteToggle) isChecked = els.siteToggle.checked;
    if (els.siteToggleLabel) { els.siteToggleLabel.textContent = isChecked ? loc.on : loc.off; els.siteToggleLabel.style.color = isChecked ? '#60a5fa' : '#fca5a5'; }
    if (els.siteToggle) els.siteToggle.checked = isChecked;
    if (els.cpSiteToggle) els.cpSiteToggle.checked = isChecked;
}

function updateGroupsState() {
    if(els.groupLimits) els.groupLimits.classList.toggle('disabled', !els.checkLimits.checked);
    if(els.groupBlock) els.groupBlock.classList.toggle('disabled', !els.checkBox.checked);
}

function toggleProMode() {
    isProMode = !isProMode;
    els.btnTogglePro.classList.toggle('active', isProMode);
    if (isProMode) { els.proAdvancedBlock.classList.remove('hidden'); els.proLimitsGroup.classList.remove('hidden'); } 
    else { els.proAdvancedBlock.classList.add('hidden'); els.proLimitsGroup.classList.add('hidden'); }
    saveSettings(); updateCanvasSize();
}

function updateCanvasSize() {
    if(!isInlineMode && !isFullscreen) return; 
    const box = els.previewBox; const wrapper = els.previewWrapper;

    if (!els.checkBox.checked || !els.boxW.value || !els.boxH.value) {
        box.style.width = '100%'; box.style.minHeight = '90px'; box.style.border = '2px dashed transparent'; box.style.zoom = 1;
        els.preview.style.fontSize = '14px'; els.preview.style.lineHeight = '1.4'; els.preview.style.letterSpacing = 'normal'; els.preview.style.transform = 'none'; els.preview.style.width = '100%';
        return;
    }

    const targetW = parseFloat(els.boxW.value); const targetH = parseFloat(els.boxH.value); const targetFontSz = parseFloat(els.fontSz.value) || 14;
    const unit = els.unit.value || 'px'; const dpi = parseInt(els.dpi.value) || 72;
    const tracking = parseFloat(els.tracking.value) || 0; const scaleX = parseFloat(els.scaleX.value) || 100;

    let targetFontPx = targetFontSz; if (unit === 'pt') targetFontPx = targetFontSz * (dpi / 72);
    box.style.width = `${targetW}px`; box.style.minHeight = `${targetH}px`; box.style.border = '2px dashed #9ca3af';

    els.preview.style.fontSize = `${targetFontPx}px`; els.preview.style.letterSpacing = `${tracking / 1000}em`;
    const scaleFactor = Math.max(0.1, scaleX / 100);
    els.preview.style.transform = `scaleX(${scaleFactor})`; els.preview.style.transformOrigin = 'left top'; els.preview.style.width = `${(1 / scaleFactor) * 100}%`;

    const lineHStr = (els.lineH.value || '').toString().replace(',', '.'); const lineH = parseFloat(lineHStr) || 0;
    if (lineH > 0 && lineH <= 3) els.preview.style.lineHeight = lineH; 
    else if (lineH > 3) { let targetLineHPx = lineH; if (unit === 'pt') targetLineHPx = lineH * (dpi / 72); els.preview.style.lineHeight = `${targetLineHPx}px`; } 
    else els.preview.style.lineHeight = '1.2';

    const availW = wrapper.clientWidth - 20; const maxWidth = availW > 0 ? availW : 360;
    let scale = maxWidth / targetW; if (scale > 1) scale = 1; box.style.zoom = scale;
}

try { new ResizeObserver(() => { window.requestAnimationFrame(() => updateCanvasSize()); }).observe(els.previewWrapper); } catch (e) {}

function refreshProfileSelect() {
    els.profileSelect.innerHTML = '';
    for (const name in profilesMap) {
        const opt = document.createElement('option');
        opt.value = name; opt.textContent = name;
        if (name === activeProfileName) opt.selected = true;
        els.profileSelect.appendChild(opt);
    }
}

function applyProfileToUI(name) {
    const p = profilesMap[name]; if (!p) return;
    activeProfileName = name;
    ['num', 'cur', 'quo', 'pho', 'deg', 'hang', 'lig', 'arr', 'ell', 'checkLimits', 'checkBox', 'stripBreaks'].forEach(k => { if(els[k] && p[k] !== undefined) els[k].checked = p[k]; });
    ['wrap', 'lines', 'totalChars', 'boxW', 'boxH', 'fontSz', 'lineH', 'unit', 'dpi', 'fontFam', 'tracking', 'scaleX'].forEach(k => { if(els[k] && p[k] !== undefined) els[k].value = p[k]; });
    updateGroupsState(); applyPreviewFont(); updateCanvasSize(); formatText(); saveSettings();
}

els.profileSelect.addEventListener('change', (e) => { applyProfileToUI(e.target.value); });
els.btnSaveProfile.addEventListener('click', () => {
    const name = prompt("Введите имя профиля (Profile name):");
    if (name) {
        profilesMap[name] = {
            num: els.num.checked, cur: els.cur.checked, quo: els.quo.checked, pho: els.pho.checked, deg: els.deg.checked, hang: els.hang.checked,
            lig: els.lig.checked, arr: els.arr.checked, ell: els.ell.checked,
            stripBreaks: els.stripBreaks.checked, checkLimits: els.checkLimits.checked, wrap: els.wrap.value, lines: els.lines.value, totalChars: els.totalChars.value,
            checkBox: els.checkBox.checked, boxW: els.boxW.value, boxH: els.boxH.value, fontSz: els.fontSz.value, lineH: els.lineH.value, unit: els.unit.value, dpi: els.dpi.value,
            tracking: els.tracking.value, scaleX: els.scaleX.value, fontFam: els.fontFam.value
        };
        activeProfileName = name; refreshProfileSelect(); saveSettings();
    }
});
els.btnDeleteProfile.addEventListener('click', () => {
    if (Object.keys(profilesMap).length <= 1) return alert("Нельзя удалить последний профиль.");
    if (confirm(`Удалить профиль "${activeProfileName}"?`)) { delete profilesMap[activeProfileName]; activeProfileName = Object.keys(profilesMap)[0]; refreshProfileSelect(); applyProfileToUI(activeProfileName); }
});

els.btnExportProfiles.addEventListener('click', () => {
    const blob = new Blob([JSON.stringify(profilesMap, null, 2)], {type: 'application/json'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'st_profiles.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
});

els.btnImportProfiles.addEventListener('click', () => els.fileImportProfiles.click());
els.fileImportProfiles.addEventListener('change', (e) => {
    const file = e.target.files[0]; if (!file) return;
    const reader = new FileReader();
    reader.onload = (evt) => {
        try { const imported = JSON.parse(evt.target.result); if (typeof imported === 'object') { profilesMap = { ...profilesMap, ...imported }; refreshProfileSelect(); applyProfileToUI(activeProfileName); alert("Импорт завершен."); }
        } catch (err) { alert("Ошибка при чтении файла."); }
        e.target.value = '';
    };
    reader.readAsText(file);
});

function saveSettings() {
    if (!isAppReady || typeof chrome === 'undefined' || !chrome.storage) return;
    chrome.storage.local.set({
        st_options: { auto: isAutoFormatEnabled, stripBreaks: els.stripBreaks.checked, redBold: els.optRedBold.checked, textAlign: els.textAlign, taHeight: els.source.style.height },
        st_profiles: profilesMap, st_active_profile: activeProfileName, st_pro_mode: isProMode
    });
}

async function initApp() {
    await loadCustomFonts();
    chrome.storage.local.get(['st_options', 'st_profiles', 'st_active_profile', 'st_pro_mode'], (res) => {
        profilesMap = res.st_profiles && Object.keys(res.st_profiles).length > 0 ? res.st_profiles : JSON.parse(JSON.stringify(defaultProfiles));
        activeProfileName = res.st_active_profile && profilesMap[res.st_active_profile] ? res.st_active_profile : Object.keys(profilesMap)[0];
        
        const o = res.st_options || {};
        isAutoFormatEnabled = o.auto !== undefined ? o.auto : true;
        els.optRedBold.checked = o.redBold !== undefined ? o.redBold : true;
        els.textAlign = o.textAlign || 'left'; if (o.taHeight && isInlineMode) els.source.style.height = o.taHeight;
        
        isProMode = res.st_pro_mode !== undefined ? res.st_pro_mode : false;
        els.btnTogglePro.classList.toggle('active', isProMode);
        if (isProMode) { els.proAdvancedBlock.classList.remove('hidden'); els.proLimitsGroup.classList.remove('hidden'); } 
        else { els.proAdvancedBlock.classList.add('hidden'); els.proLimitsGroup.classList.add('hidden'); }

        refreshProfileSelect(); applyProfileToUI(activeProfileName);

        els.alignBtns.forEach(b => b.classList.toggle('active', b.dataset.align === els.textAlign));
        updateAutoFormatBtn(); updateToggleLabel();
        isAppReady = true; connectToTab();
    });
}

if(els.btnTogglePro) els.btnTogglePro.addEventListener('click', toggleProMode);

function connectToTab() {
    getTargetTab((tab) => {
        if (!tab) return;
        try {
            const url = new URL(tab.url); currentDomain = url.hostname;
            const disabledState = (res) => { const ds = res.disabledSites || []; const isEnabled = !ds.includes(currentDomain); if (els.siteToggle) els.siteToggle.checked = isEnabled; if (els.cpSiteToggle) els.cpSiteToggle.checked = isEnabled; updateToggleLabel(); };
            if (!currentDomain || url.protocol.startsWith('chrome') || url.protocol.startsWith('edge')) { if(els.cpSiteToggle) els.cpSiteToggle.disabled = true; if(els.siteToggle) els.siteToggle.disabled = true; if(els.siteToggle) els.siteToggle.checked = false; if(els.cpSiteToggle) els.cpSiteToggle.checked = false; updateToggleLabel(); } 
            else chrome.storage.local.get(['disabledSites'], disabledState);
        } catch (e) {}

        if (isInlineMode || isFullscreen) {
            chrome.tabs.sendMessage(tab.id, { action: 'GET_STATE' }, (res) => {
                if (chrome.runtime.lastError) return;
                if (!res || !res.hasActive) return;
                isLinked = true; els.lblStatus.textContent = loc.linkedField; els.lblStatus.classList.add('active'); els.btnApplyText.textContent = loc.btnApply;
                isSyncingSource = true;
                
                try {
                    if (res.isRich && res.html) { els.preview.innerHTML = res.html; els.source.innerHTML = res.html; } 
                    else els.source.innerHTML = escapeHTML(res.text).replace(/\n/g, '<br>');
                    if (els.stripBreaks.checked) applyStripBreaksToSource();
                } finally {
                    isSyncingSource = false; updateStats(); formatText();
                }
            });
        }
    });
}

chrome.runtime.onMessage.addListener((msg) => {
    if (msg.action === 'UPDATE_TEXT_FROM_SITE' && !isSyncingSource && (isInlineMode || isFullscreen)) {
        try {
            isSyncingSource = true;
            if (msg.isRich && msg.html) { els.preview.innerHTML = msg.html; els.source.innerHTML = msg.html; } 
            else els.source.innerHTML = escapeHTML(msg.text).replace(/\n/g, '<br>');
            if (els.stripBreaks.checked) applyStripBreaksToSource();
        } finally {
            isSyncingSource = false; updateStats(); formatText();
        }
    }
});

function getNodeStyle(node, root) {
    let bold = false, italic = false, red = false, cur = node.parentElement;
    while (cur && cur !== root) {
        const tag = cur.tagName ? cur.tagName.toLowerCase() : '';
        const style = window.getComputedStyle(cur);
        const fw = style.fontWeight || '';
        
        if (tag === 'b' || tag === 'strong' || fw === 'bold' || fw === '700' || fw === 'bolder' || parseInt(fw, 10) >= 600) bold = true;
        if (tag === 'i' || tag === 'em' || style.fontStyle === 'italic') italic = true;
        cur = cur.parentElement;
    }
    
    if (!bold) red = false;
    if (els.optRedBold && els.optRedBold.checked && bold) red = true; 

    return { bold, italic, red };
}

function extractAlphanumericStyles(rootNode) {
    const styles = [];
    function walk(node) {
        if (node.nodeType === Node.TEXT_NODE) {
            const text = node.nodeValue || '';
            const style = getNodeStyle(node, rootNode); 
            for (let i = 0; i < text.length; i++) {
                if (/[a-zA-Zа-яА-ЯёЁ0-9]/.test(text[i])) { styles.push({ ...style }); }
            }
        } else if (node.nodeType === Node.ELEMENT_NODE) {
            if (node.classList.contains('badge-error') || node.classList.contains('text-error')) return;
            node.childNodes.forEach(walk);
        }
    }
    rootNode.childNodes.forEach(walk); 
    return styles;
}

function previewHTMLToPlainText() {
    const temp = document.createElement('div'); temp.innerHTML = els.preview.innerHTML || '';
    function walk(node) {
        if (node.nodeType === Node.TEXT_NODE) return node.nodeValue || ''; if (node.nodeType !== Node.ELEMENT_NODE) return '';
        const tag = node.tagName.toLowerCase(); if (tag === 'br') return '\n';
        if (node.classList && (node.classList.contains('badge-error') || node.classList.contains('text-error'))) return '';
        let inner = ''; node.childNodes.forEach(child => { inner += walk(child); }); return (tag === 'div' || tag === 'p') ? inner + '\n' : inner;
    }
    let out = ''; temp.childNodes.forEach(child => { out += walk(child); }); return SmartTypography.cleanLineBreaksForInsert(out);
}

function previewHTMLToInnerRichHTML() {
    const temp = document.createElement('div'); temp.innerHTML = els.preview.innerHTML || '';
    function walk(node) {
        if (node.nodeType === Node.TEXT_NODE) return escapeHTML(node.nodeValue || ''); if (node.nodeType !== Node.ELEMENT_NODE) return '';
        const tag = node.tagName.toLowerCase(); if (tag === 'br') return '<br>';
        if (node.classList && (node.classList.contains('badge-error') || node.classList.contains('text-error'))) return '';
        let inner = ''; node.childNodes.forEach(child => { inner += walk(child); });
        
        const fw = node.style ? node.style.fontWeight : '';
        let isBold = tag === 'b' || tag === 'strong' || fw === 'bold' || fw === '700' || fw === 'bolder' || parseInt(fw, 10) >= 600;
        let isItalic = tag === 'i' || tag === 'em' || (node.style && node.style.fontStyle === 'italic');
        let isRed = false;
        
        if (!isBold) isRed = false; 
        if (els.optRedBold && els.optRedBold.checked && isBold) isRed = true;

        if (isBold) inner = `<strong>${inner}</strong>`; 
        if (isItalic) inner = `<em>${inner}</em>`; 
        if (isRed) inner = `<span style="color:#ef4444;" class="red-text">${inner}</span>`;
        return (tag === 'div' || tag === 'p') ? inner + '<br>' : inner;
    }
    let html = ''; temp.childNodes.forEach(child => { html += walk(child); }); return html.replace(/(<br>\s*){2,}/gi, '<br>').replace(/^(<br>)+/i, '').replace(/(<br>)+$/i, '');
}

function getRichProcessedHTML() { return `<p>${previewHTMLToInnerRichHTML()}</p>`; }

function previewHTMLToMarkdown() {
    const temp = document.createElement('div'); temp.innerHTML = els.preview.innerHTML || '';
    function walk(node) {
        if (node.nodeType === Node.TEXT_NODE) return node.nodeValue || ''; if (node.nodeType !== Node.ELEMENT_NODE) return '';
        const tag = node.tagName.toLowerCase(); if (tag === 'br') return '\n';
        if (node.classList && (node.classList.contains('badge-error') || node.classList.contains('text-error'))) return '';
        let inner = ''; node.childNodes.forEach(child => { inner += walk(child); });
        if (tag === 'b' || tag === 'strong') return `**${inner}**`; if (tag === 'i' || tag === 'em') return `*${inner}*`; return (tag === 'div' || tag === 'p') ? inner + '\n' : inner;
    }
    let out = ''; temp.childNodes.forEach(child => { out += walk(child); }); 
    out = SmartTypography.cleanLineBreaksForInsert(out);
    return out.replace(/[\u00A0\u2000-\u200A\u202F\u205F\u3000]/g, ' ');
}

function getPlainProcessedText() { return previewHTMLToPlainText() || SmartTypography.cleanLineBreaksForInsert(processedData); }

function renderWithAlphanumStyles(plainText, stylesArr, validation = null) {
    let html = '', currentLine = 0;
    let state = { bold: false, italic: false, red: false, err: false };
    let activeStyle = { bold: false, italic: false, red: false };
    
    const isErrorIdx = (idx, line) => {
        if (!validation || !validation.isError) return false;
        if (validation.errorMsg === loc.errChars && idx >= validation.limitTotal) return true;
        if (validation.maxAllowedLines !== Infinity && line >= validation.maxAllowedLines) return true;
        return false;
    };

    const applyState = (newState) => {
        if (state.err !== newState.err || state.italic !== newState.italic || state.bold !== newState.bold || state.red !== newState.red) {
            if (state.err) html += '</span>'; 
            if (state.red) html += '</span>';
            if (state.italic) html += '</em>'; 
            if (state.bold) html += '</strong>';
            
            if (newState.bold) html += '<strong>'; 
            if (newState.italic) html += '<em>'; 
            if (newState.red) html += '<span style="color:#ef4444;" class="red-text">';
            if (newState.err) html += '<span class="text-error">';
        }
        state = { ...newState };
    };

    for (let i = 0; i < plainText.length; i++) {
        const char = plainText[i];
        if (char === '\n') { applyState({ bold: false, italic: false, red: false, err: false }); if (validation && validation.maxAllowedLines !== Infinity && currentLine === validation.maxAllowedLines) { html += `<span class="badge-error">${validation.errorMsg}</span>`; } html += '<br>'; currentLine++; continue; }
        const isAlphanum = /[a-zA-Zа-яА-ЯёЁ0-9]/.test(char);
        if (isAlphanum && stylesArr.length > 0) { activeStyle = stylesArr.shift(); }
        const err = isErrorIdx(i, currentLine);
        applyState({ bold: activeStyle.bold, italic: activeStyle.italic, red: activeStyle.red, err: err });
        html += escapeHTML(char);
    }
    
    applyState({ bold: false, italic: false, red: false, err: false });
    if (validation && validation.isError) {
        if (validation.errorMsg === loc.errChars && plainText.length > validation.limitTotal) { html += `<span class="badge-error">${validation.errorMsg}</span>`; } 
        else if (validation.maxAllowedLines !== Infinity && currentLine === validation.maxAllowedLines) { html += `<span class="badge-error">${validation.errorMsg}</span>`; }
    }
    return html;
}

function rebuildSourceWithStyles(stylesArr) {
    const rawText = getSourceText(); 
    let html = '';
    let activeStyle = { bold: false, italic: false, red: false };
    let state = { bold: false, italic: false, red: false };
    
    const applyState = (newState) => {
        if (state.italic !== newState.italic || state.bold !== newState.bold || state.red !== newState.red) {
            if (state.red) html += '</span>';
            if (state.italic) html += '</em>'; 
            if (state.bold) html += '</strong>';
            if (newState.bold) html += '<strong>'; 
            if (newState.italic) html += '<em>'; 
            if (newState.red) html += '<span style="color:#ef4444;" class="red-text">';
        }
        state = { ...newState };
    };

    for(let i=0; i<rawText.length; i++) {
        const char = rawText[i];
        if (char === '\n') { applyState({ bold: false, italic: false, red: false }); html += '<br>'; continue; }
        if (/[a-zA-Zа-яА-ЯёЁ0-9]/.test(char) && stylesArr.length > 0) activeStyle = stylesArr.shift();
        applyState(activeStyle);
        html += escapeHTML(char);
    }
    applyState({ bold: false, italic: false, red: false });
    els.source.innerHTML = html;
}

function syncProcessedFromPreview() { if (isSyncingPreview) return; processedData = getPlainProcessedText(); updateStatsFromPreview(); }

function saveSelection(containerEl) {
    const sel = window.getSelection();
    if (!sel.rangeCount) return null;
    const range = sel.getRangeAt(0);
    if (!containerEl.contains(range.commonAncestorContainer)) return null;
    const preSelectionRange = range.cloneRange();
    preSelectionRange.selectNodeContents(containerEl);
    preSelectionRange.setEnd(range.startContainer, range.startOffset);
    const start = preSelectionRange.toString().length;
    return { start: start, end: start + range.toString().length };
}

function restoreSelection(containerEl, savedSel) {
    if (!savedSel) return;
    let charIndex = 0, range = document.createRange();
    range.setStart(containerEl, 0); range.collapse(true);
    let nodeStack = [containerEl], node, foundStart = false, stop = false;
    while (!stop && (node = nodeStack.pop())) {
        if (node.nodeType === 3) {
            const nextCharIndex = charIndex + node.length;
            if (!foundStart && savedSel.start >= charIndex && savedSel.start <= nextCharIndex) { range.setStart(node, savedSel.start - charIndex); foundStart = true; }
            if (foundStart && savedSel.end >= charIndex && savedSel.end <= nextCharIndex) { range.setEnd(node, savedSel.end - charIndex); stop = true; }
            charIndex = nextCharIndex;
        } else { let i = node.childNodes.length; while (i--) nodeStack.push(node.childNodes[i]); }
    }
    const sel = window.getSelection(); sel.removeAllRanges(); sel.addRange(range);
}

function applyStyleToSourceSelectionOrPreview(command) {
    const sel = window.getSelection();
    if (sel && sel.rangeCount && String(sel).length > 0) {
        const container = els.preview.contains(sel.anchorNode) ? els.preview : (els.source.contains(sel.anchorNode) ? els.source : null);
        if (!container) return;
        
        const savedSel = saveSelection(container);
        
        container.focus();
        document.execCommand(command, false, null); 
        
        if (container === els.preview) {
            const previewStyles = extractAlphanumericStyles(els.preview);
            rebuildSourceWithStyles(previewStyles);
        } else {
            const sourceStyles = extractAlphanumericStyles(els.source);
            rebuildSourceWithStyles(sourceStyles);
        }
        formatText(); 
        restoreSelection(container, savedSel);
    }
}

// -------------------- TYPOGRAPHY --------------------
function validateText(txt) {
    const limitBoxH = parseInt(els.boxH.value) || 0, fontSz = parseInt(els.fontSz.value) || 0, lineH = parseFloat((els.lineH.value || '').toString().replace(',', '.')) || 0;
    const limitTotal = parseInt(els.totalChars.value) || 0, limitLines = parseInt(els.lines.value) || 0;
    let isError = false, errorMsg = '', maxAllowedLines = Infinity;

    if (els.checkLimits.checked) {
        if (limitTotal > 0 && txt.length > limitTotal) { isError = true; errorMsg = loc.errChars; } 
        else if (limitLines > 0 && txt.split('\n').length > limitLines) { isError = true; errorMsg = loc.errLines; maxAllowedLines = limitLines; }
    }
    if (els.checkBox.checked && limitBoxH > 0 && fontSz > 0 && !isError) {
        let computedLineH = lineH === 0 ? fontSz * 1.2 : (lineH > 0 && lineH <= 3 ? fontSz * lineH : lineH);
        let lineHeightInPx = els.unit.value === 'pt' ? computedLineH * ((parseInt(els.dpi.value)||72) / 72) : computedLineH;
        maxAllowedLines = Math.floor(limitBoxH / lineHeightInPx);
        if (txt.split('\n').length > maxAllowedLines) { isError = true; errorMsg = `${loc.errBlock} ${els.boxW.value}x${limitBoxH}`; }
    }
    return { isError, errorMsg, maxAllowedLines, limitTotal };
}

function formatText() {
    let txt = getSourceText(); 
    if (!txt) { els.preview.innerHTML = ''; processedData = ''; updateStats(); updateCanvasSize(); return; }
    
    const sourceStyles = extractAlphanumericStyles(els.source);
    
    applyPreviewFont(); els.preview.style.textAlign = els.textAlign || 'left'; els.preview.style.fontSize = '14px';
    updateCanvasSize();
    
    const opts = {
        num: els.num.checked, cur: els.cur.checked, quo: els.quo.checked, pho: els.pho.checked, deg: els.deg.checked, hang: els.hang.checked,
        lig: els.lig.checked, arr: els.arr.checked, ell: els.ell.checked,
        checkLimits: els.checkLimits.checked, wrap: els.wrap.value,
        checkBox: els.checkBox.checked, boxW: els.boxW.value, fontSz: els.fontSz.value, unit: els.unit.value, dpi: els.dpi.value,
        tracking: els.tracking.value, scaleX: els.scaleX.value, fontFam: els.fontFam.value
    };
    txt = SmartTypography.applyAll(txt, opts); processedData = txt;
    
    const validation = validateText(txt);
    isSyncingPreview = true; 
    els.preview.innerHTML = renderWithAlphanumStyles(txt, sourceStyles, validation); 
    isSyncingPreview = false;
    updateStatsFromPreview();

    if (validation.isError) { els.btnApply.disabled = true; els.btnApply.style.opacity = '0.5'; els.btnApply.style.cursor = 'not-allowed'; } 
    else { els.btnApply.disabled = false; els.btnApply.style.opacity = '1'; els.btnApply.style.cursor = 'pointer'; }
}

// -------------------- СОБЫТИЯ --------------------
const handleToggle = (e) => {
    const isEnabled = e.target.checked;
    if (els.siteToggle) els.siteToggle.checked = isEnabled;
    if (els.cpSiteToggle) els.cpSiteToggle.checked = isEnabled;
    updateToggleLabel();
    if (!currentDomain || !chrome.storage) return;
    chrome.storage.local.get(['disabledSites'], (res) => {
        let disabledSites = res.disabledSites || [];
        if (isEnabled) disabledSites = disabledSites.filter(d => d !== currentDomain); 
        else if (!disabledSites.includes(currentDomain)) disabledSites.push(currentDomain);
        chrome.storage.local.set({ disabledSites }, () => { 
            getTargetTab(tab => { if (tab) chrome.tabs.sendMessage(tab.id, { action: 'TOGGLE_SITE', isEnabled }, () => { void chrome.runtime.lastError; }); }); 
        });
    });
};

if(els.siteToggle) els.siteToggle.addEventListener('change', handleToggle);
if(els.cpSiteToggle) els.cpSiteToggle.addEventListener('change', handleToggle);
if(els.cpBtnFormatActive) els.cpBtnFormatActive.addEventListener('click', () => { getTargetTab(tab => { if (tab) chrome.tabs.sendMessage(tab.id, { action: 'FORMAT_ACTIVE' }, () => { if (chrome.runtime.lastError) return; const orig = els.cpBtnFormatActive.innerHTML; els.cpBtnFormatActive.innerHTML = `<span style="color:#10b981; font-weight:bold;">${loc.applySuccess}</span>`; setTimeout(() => els.cpBtnFormatActive.innerHTML = orig, 1500); }); }); });
if(els.cpBtnClearCache) els.cpBtnClearCache.addEventListener('click', () => { getTargetTab(tab => { if (tab) chrome.tabs.sendMessage(tab.id, { action: 'CLEAR_CACHE' }, () => { if (chrome.runtime.lastError) return; }); }); if (els.source) els.source.innerHTML = ''; if (els.preview) els.preview.innerHTML = ''; updateStats(); const orig = els.cpBtnClearCache.innerHTML; els.cpBtnClearCache.innerHTML = `<span>Очищено!</span>`; setTimeout(() => els.cpBtnClearCache.innerHTML = orig, 1500); });
if(els.cpBtnOpenEditor) els.cpBtnOpenEditor.addEventListener('click', () => { chrome.tabs.query({ active: true, currentWindow: true }, tabs => { const tid = tabs[0] ? tabs[0].id : ''; window.open(chrome.runtime.getURL('popup.html') + '?full=1&tabId=' + tid); }); });

if (els.source) { try { new ResizeObserver(() => { saveSettings(); }).observe(els.source); } catch (e) {} }

els.alignBtns.forEach(btn => { btn.addEventListener('click', (e) => { els.alignBtns.forEach(b => b.classList.remove('active')); e.currentTarget.classList.add('active'); els.textAlign = e.currentTarget.dataset.align; els.preview.style.textAlign = els.textAlign || 'left'; saveSettings(); }); });
document.querySelectorAll('.btn-tool[data-tag]').forEach(btn => { btn.addEventListener('mousedown', e => e.preventDefault()); btn.addEventListener('click', e => { e.preventDefault(); const t = e.currentTarget.dataset.tag; applyStyleToSourceSelectionOrPreview(t === 'b' ? 'bold' : 'italic'); }); });
if(els.btnAutoFormat) els.btnAutoFormat.addEventListener('click', () => { isAutoFormatEnabled = !isAutoFormatEnabled; updateAutoFormatBtn(); saveSettings(); });

function handleShortcuts(e) {
    if ((e.ctrlKey || e.metaKey) && (e.key.toLowerCase() === 'b')) { e.preventDefault(); applyStyleToSourceSelectionOrPreview('bold'); }
    if ((e.ctrlKey || e.metaKey) && (e.key.toLowerCase() === 'i')) { e.preventDefault(); applyStyleToSourceSelectionOrPreview('italic'); }
}
if(els.source) els.source.addEventListener('keydown', handleShortcuts);
if(els.preview) els.preview.addEventListener('keydown', handleShortcuts);

function cleanPastedHTML(html, stripBreaks) {
    const temp = document.createElement('div');
    temp.innerHTML = html;
    function walk(node) {
        if (node.nodeType === Node.TEXT_NODE) {
            let val = node.nodeValue || '';
            if (stripBreaks) val = val.replace(/[\r\n]+/g, ' ');
            return escapeHTML(val); 
        }
        if (node.nodeType !== Node.ELEMENT_NODE) return '';
        const tag = node.tagName.toLowerCase();
        
        let isBlock = ['p', 'div', 'li', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'tr', 'td'].includes(tag);
        let inner = ''; node.childNodes.forEach(child => { inner += walk(child); });
        
        const fw = node.style ? node.style.fontWeight : '';
        let isBold = tag === 'b' || tag === 'strong' || fw === 'bold' || fw === '700' || fw === 'bolder' || parseInt(fw, 10) >= 600;
        let isItalic = tag === 'i' || tag === 'em' || (node.style && node.style.fontStyle === 'italic');
        
        let isRed = false;
        if (isBold && els.optRedBold && els.optRedBold.checked) isRed = true;

        if (isBold) inner = `<strong>${inner}</strong>`;
        if (isItalic) inner = `<em>${inner}</em>`;
        if (isRed) inner = `<span style="color:#ef4444;" class="red-text">${inner}</span>`;
        
        if (tag === 'br') return stripBreaks ? ' ' : '<br>';
        if (isBlock) return stripBreaks ? inner + ' ' : inner + '<br>';
        
        return inner;
    }
    let res = '';
    temp.childNodes.forEach(child => { res += walk(child); });
    
    if (!stripBreaks) { res = res.replace(/(<br>\s*){3,}/gi, '<br><br>').replace(/^(<br>)+/i, '').replace(/(<br>)+$/i, ''); } 
    else { res = res.replace(/<br>/gi, ' ').replace(/[\r\n]+/g, ' ').replace(/\s{2,}/g, ' '); }
    return res;
}

if(els.preview) {
    els.preview.addEventListener('input', () => syncProcessedFromPreview());
    els.preview.addEventListener('paste', e => { e.preventDefault(); document.execCommand('insertText', false, SmartTypography.normalizeImportedText((e.clipboardData || window.clipboardData).getData('text'))); syncProcessedFromPreview(); });
}

if(els.source) {
    els.source.addEventListener('input', () => { if (isSyncingSource) return; updateStats(); if (isAutoFormatEnabled) formatText(); });
    els.source.addEventListener('keydown', e => { if (e.key === 'Enter' && els.stripBreaks.checked) { e.preventDefault(); document.execCommand('insertText', false, ' '); } });
    els.source.addEventListener('paste', e => { 
        e.preventDefault();
        let html = (e.clipboardData || window.clipboardData).getData('text/html');
        let text = (e.clipboardData || window.clipboardData).getData('text/plain');
        
        if (html) { document.execCommand('insertHTML', false, cleanPastedHTML(html, els.stripBreaks.checked)); } 
        else {
            let cleanText = SmartTypography.normalizeImportedText(text);
            if (els.stripBreaks.checked) cleanText = cleanText.replace(/[\r\n]+/g, ' ');
            document.execCommand('insertText', false, cleanText);
        }
        
        setTimeout(() => { if (els.stripBreaks.checked) applyStripBreaksToSource(); updateStats(); formatText(); }, 10); 
    });
}

['stripBreaks', 'optRedBold', 'num', 'cur', 'quo', 'pho', 'deg', 'hang', 'lig', 'arr', 'ell', 'wrap', 'lines', 'totalChars', 'boxW', 'boxH', 'fontSz', 'lineH', 'unit', 'dpi', 'fontFam', 'tracking', 'scaleX'].forEach(k => {
    if (!els[k]) return;
    const handler = () => {
        if (k === 'fontFam') applyPreviewFont(); 
        if (k === 'stripBreaks' && els.stripBreaks.checked) applyStripBreaksToSource();
        if (k !== 'stripBreaks' && k !== 'optRedBold' && profilesMap[activeProfileName]) { profilesMap[activeProfileName][k] = (els[k].type === 'checkbox' ? els[k].checked : els[k].value); }
        
        if (k === 'optRedBold') {
            const styles = extractAlphanumericStyles(els.source);
            rebuildSourceWithStyles(styles);
        }
        
        if (isAutoFormatEnabled) formatText(); 
        saveSettings(); 
    };
    els[k].addEventListener('change', handler); els[k].addEventListener('input', handler);
});

['checkLimits', 'checkBox'].forEach(k => { if(els[k]) els[k].addEventListener('change', () => { updateGroupsState(); if (isAutoFormatEnabled) formatText(); saveSettings(); }); });

if(els.btnFormat) els.btnFormat.addEventListener('click', formatText);

if(els.btnCopyPS) els.btnCopyPS.addEventListener('click', () => { 
    const markdownText = previewHTMLToMarkdown(); 
    if (!markdownText) return; 
    
    const fallbackCopy = (text) => {
        const ta = document.createElement("textarea"); 
        ta.value = text; 
        ta.style.position = 'fixed';
        ta.style.top = '-9999px';
        ta.style.opacity = '0';
        document.body.appendChild(ta); 
        ta.select(); 
        document.execCommand("copy"); 
        ta.remove(); 
        
        els.btnCopyPS.disabled = true; 
        els.btnCopyPSText.textContent = loc.copySuccess; 
        setTimeout(() => { els.btnCopyPS.disabled = false; els.btnCopyPSText.textContent = loc.btnCopyPS; }, 2000);
    };

    if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(markdownText).then(() => { 
            els.btnCopyPS.disabled = true; 
            els.btnCopyPSText.textContent = loc.copySuccess; 
            setTimeout(() => { els.btnCopyPS.disabled = false; els.btnCopyPSText.textContent = loc.btnCopyPS; }, 2000); 
        }).catch(() => fallbackCopy(markdownText));
    } else {
        fallbackCopy(markdownText);
    }
});

if(els.btnApply) els.btnApply.addEventListener('click', () => {
    const plainText = getPlainProcessedText(), richHTML = getRichProcessedHTML(); if (!plainText) return;
    
    const sanitizedPlainText = plainText.replace(/[\u00A0\u2000-\u200A\u202F\u205F\u3000]/g, ' ');
    const sanitizedRichHTML = richHTML.replace(/[\u00A0\u2000-\u200A\u202F\u205F\u3000]/g, ' ');

    processedData = sanitizedPlainText; els.btnApply.disabled = true;
    chrome.storage.local.set({ st_last_session: { domain: currentDomain, source: els.source.innerHTML, formatted: sanitizedPlainText } });
    if (isLinked) {
        getTargetTab(tab => {
            if (!tab) { els.btnApply.disabled = false; return; }
            chrome.tabs.sendMessage(tab.id, { action: 'SET_TEXT', text: sanitizedPlainText, plainText: sanitizedPlainText, richHTML: sanitizedRichHTML, isRichText: true, sourceText: getSourceText() }, () => {
                if (chrome.runtime.lastError) {} 
                els.btnApply.disabled = false; els.btnApplyText.textContent = loc.applySuccess; setTimeout(() => els.btnApplyText.textContent = loc.btnApply, 2000);
            });
        });
    } else { navigator.clipboard.writeText(sanitizedPlainText).then(() => { els.btnApply.disabled = false; els.btnApplyText.textContent = loc.copySuccess; setTimeout(() => els.btnApplyText.textContent = loc.copyResult, 2000); }).catch(() => els.btnApply.disabled = false); }
});

initApp();