// ================== SMART TYPOGRAPHER typography.js ==================

const SmartTypography = (() => {
    const nbsp = '\u00A0'; 
    const spaces = "\\s\\u00A0\\u2000-\\u200A\\u202F\\u205F\\u3000";
    const wordChars = "a-zA-Zа-яА-ЯёЁąęćłńśźżĄĘĆŁŃŚŹŻãõÃÕñÑœæçàâèêëîïôùûÿŒÆÇÀÂÈÊËÎÏÔÙÛŸäöüÄÖÜß0-9";

    // ЖЕСТКАЯ ОЧИСТКА: любые множественные переносы (\n\n) схлопываются в один (\n)
    function cleanLineBreaksForInsert(txt) { 
        return String(txt||'').replace(/\r\n/g, '\n').replace(/\r/g, '\n').replace(/[ \t]+\n/g, '\n').replace(/\n[ \t]+/g, '\n').replace(/\n{2,}/g, '\n').trim(); 
    }
    
    function normalizeImportedText(txt) {
        if (!txt) return ''; 
        txt = String(txt).replace(/\r\n/g, '\n').replace(/\r/g, '\n').replace(/[ \t]+/g, ' ').replace(/[ \t]*\n[ \t]*/g, '\n').replace(/\n{2,}/g, '\n');
        const lines = txt.split('\n').map(line => line.trim()); 
        return lines.length ? lines.join('\n').trim() : '';
    }

    function stripHTMLTags(str) { return String(str || '').replace(/<[^>]*>/g, ''); }
    function stripMarkdownStyles(str) { return String(str || '').replace(/\*\*(.*?)\*\*/g, '$1').replace(/__(.*?)__/g, '$1').replace(/\*(.*?)\*/g, '$1').replace(/_(.*?)_/g, '$1').replace(/<\/?(b|i|strong|em)>/gi, ''); }

    // ==================================================================
    // БАЛЛЬНАЯ СИСТЕМА РАСПОЗНАВАНИЯ ЯЗЫКОВ
    // ==================================================================
    function detectLanguage(text) {
        if (!text) return 'ru';
        // Безупречные маркеры алфавита
        if (/[а-яА-ЯёЁ]/.test(text)) return 'ru';
        if (/[ąęłńśźżĄĘŁŃŚŹŻ]/.test(text)) return 'pl';
        if (/[ñ¿¡Ñ]/.test(text)) return 'es';
        if (/[ãõÃÕ]/.test(text)) return 'pt';
        if (/[ß]/.test(text)) return 'de';

        // Для остальных языков используем систему скоринга по словам-маркерам
        const scores = { en: 0, it: 0, fr: 0, es: 0, de: 0, pt: 0 };
        const dicts = {
            it: /\b(di|da|con|su|per|tra|fra|il|lo|la|i|gli|le|un|uno|una|ed|non|che|si|mi|ti)\b/gi,
            fr: /\b(le|la|les|un|une|des|est|pour|dans|qui|que|avec|sur|ne|pas|ce)\b/gi,
            es: /\b(el|la|los|las|un|una|en|por|para|con|que|del|al|se|como)\b/gi,
            de: /\b(und|der|die|das|den|dem|des|ein|eine|ist|nicht|zu|mit|auf|für)\b/gi,
            pt: /\b(o|a|os|as|um|uma|e|em|por|para|com|que|não|se|do|da)\b/gi,
            en: /\b(the|a|an|and|is|in|on|of|to|with|that|this|it|for|as)\b/gi
        };

        for (let l in dicts) {
            const matches = text.match(dicts[l]);
            if (matches) scores[l] = matches.length;
        }

        let maxLang = 'en';
        let maxScore = 0;
        for (let l in scores) {
            if (scores[l] > maxScore) {
                maxScore = scores[l];
                maxLang = l;
            }
        }

        // Если слова не определились, возвращаемся к символам как крайняя мера
        if (maxScore === 0) {
            if (/[œæçâêëîïôûÿŒÆÇÂÊËÎÏÔÛŸ]/.test(text)) return 'fr';
            if (/[àèéìíòóùú]/.test(text)) return 'it';
            if (/[äöüÄÖÜ]/.test(text)) return 'de';
        }

        return maxScore > 0 ? maxLang : 'en';
    }

    // ==================================================================
    // ЯЗЫКОВЫЕ ПРАВИЛА
    // ==================================================================
    function applyRussian(text, opts) {
        if (opts.quo) {
            text = text.replace(/\x01([^\x01\x02]+)\x01([^\x01\x02]+)\x02([^\x01\x02]*)\x02/g, '«$1„$2“$3»');
            text = text.replace(/\x01/g, '«').replace(/\x02/g, '»');
            const bStart = "(^|[^" + wordChars + "])";
            const bEnd = "(?=[^" + wordChars + "]|$)";
            text = text.replace(new RegExp(bStart + "['‘’]([^'‘’]+)['‘’]" + bEnd, "g"), '$1„$2“');
        }
        if (opts.hang) {
            const preps = "а|без|бы|в|вне|во|вот|все|вы|да|для|до|же|за|и|из|или|им|их|к|ко|ли|мы|на|над|не|ни|но|о|об|обо|он|от|по|под|при|про|с|со|те|то|ту|ты|у|я";
            const prepsRegex = new RegExp("(^|[" + spaces + "\\r\\n])(" + preps + ")([" + spaces + "]+)", "gi");
            let tempText; do { tempText = text; text = text.replace(prepsRegex, "$1$2" + nbsp); } while (tempText !== text);
        }
        text = text.replace(new RegExp("[" + spaces + "]+(—)", "g"), nbsp + '$1');
        return text;
    }

    function applyEnglish(text, opts) {
        if (opts.quo) {
            text = text.replace(/\x01([^\x01\x02]+)\x01([^\x01\x02]+)\x02([^\x01\x02]*)\x02/g, '“$1‘$2’$3”');
            text = text.replace(/\x01/g, '“').replace(/\x02/g, '”');
            const bStart = "(^|[^" + wordChars + "])";
            const bEnd = "(?=[^" + wordChars + "]|$)";
            text = text.replace(new RegExp(bStart + "['‘’]([^'‘’]+)['‘’]" + bEnd, "g"), '$1‘$2’');
        }
        if (opts.hang) {
            const preps = "a|an|and|are|as|at|be|but|by|do|for|if|in|into|is|it|no|not|of|on|or|out|so|the|to|up|was|with";
            const prepsRegex = new RegExp("(^|[" + spaces + "\\r\\n])(" + preps + ")([" + spaces + "]+)", "gi");
            let tempText; do { tempText = text; text = text.replace(prepsRegex, "$1$2" + nbsp); } while (tempText !== text);
        }
        return text;
    }

    function applySpanish(text, opts) {
        if (opts.quo) {
            text = text.replace(/\x01([^\x01\x02]+)\x01([^\x01\x02]+)\x02([^\x01\x02]*)\x02/g, '«$1“$2”$3»');
            text = text.replace(/\x01/g, '«').replace(/\x02/g, '»');
            const bStart = "(^|[^" + wordChars + "])";
            const bEnd = "(?=[^" + wordChars + "]|$)";
            text = text.replace(new RegExp(bStart + "['‘’]([^'‘’]+)['‘’]" + bEnd, "g"), '$1“$2”');
        }
        if (opts.hang) {
            const preps = "a|al|ante|bajo|cabe|con|contra|de|del|desde|e|el|en|entre|hacia|hasta|la|las|le|les|lo|los|me|mi|mis|ni|no|o|para|por|que|se|según|si|sin|so|sobre|su|sus|te|tras|tu|tus|u|un|una|y|ya";
            const prepsRegex = new RegExp("(^|[" + spaces + "\\r\\n])(" + preps + ")([" + spaces + "]+)", "gi");
            let tempText; do { tempText = text; text = text.replace(prepsRegex, "$1$2" + nbsp); } while (tempText !== text);
        }
        return text;
    }

    function applyFrench(text, opts) {
        if (opts.quo) {
            text = text.replace(/\x01([^\x01\x02]+)\x01([^\x01\x02]+)\x02([^\x01\x02]*)\x02/g, '«' + nbsp + '$1“$2”$3' + nbsp + '»');
            text = text.replace(new RegExp("\\x01[" + spaces + "]*", "g"), '«' + nbsp);
            text = text.replace(new RegExp("[" + spaces + "]*\\x02", "g"), nbsp + '»');
        }
        text = text.replace(new RegExp("([a-zA-ZÀ-ÿ»])([!?:;])", "gi"), '$1' + nbsp + '$2');
        if (opts.hang) {
            const preps = "à|au|aux|avec|ce|ces|dans|de|des|du|elle|en|et|il|ils|la|le|les|ma|me|mes|mon|ne|on|ou|où|par|pas|pour|que|qui|sa|se|ses|son|sur|ta|te|tes|ton|un|une|y";
            const prepsRegex = new RegExp("(^|[" + spaces + "\\r\\n])(" + preps + ")([" + spaces + "]+)", "gi");
            let tempText; do { tempText = text; text = text.replace(prepsRegex, "$1$2" + nbsp); } while (tempText !== text);
        }
        return text;
    }

    function applyGerman(text, opts) {
        if (opts.quo) {
            text = text.replace(/\x01([^\x01\x02]+)\x01([^\x01\x02]+)\x02([^\x01\x02]*)\x02/g, '„$1‚$2‘$3“');
            text = text.replace(/\x01/g, '„').replace(/\x02/g, '“');
        }
        if (opts.hang) {
            const preps = "aber|als|am|an|auf|aus|bei|bis|da|das|dem|den|der|des|dich|die|dir|durch|ein|eine|einem|einen|einer|eines|er|es|für|ihr|im|in|mich|mir|mit|nach|ob|oder|seit|sich|sie|so|und|vom|von|was|wer|wie|wir|wo|zu|zum|zur";
            const prepsRegex = new RegExp("(^|[" + spaces + "\\r\\n])(" + preps + ")([" + spaces + "]+)", "gi");
            let tempText; do { tempText = text; text = text.replace(prepsRegex, "$1$2" + nbsp); } while (tempText !== text);
        }
        return text;
    }

    function applyPortuguese(text, opts) {
        if (opts.quo) {
            text = text.replace(/\x01([^\x01\x02]+)\x01([^\x01\x02]+)\x02([^\x01\x02]*)\x02/g, '“$1‘$2’$3”');
            text = text.replace(/\x01/g, '“').replace(/\x02/g, '”');
        }
        if (opts.hang) {
            const preps = "a|ao|aos|as|à|às|com|da|das|de|do|dos|dum|duma|e|ela|ele|em|eu|lhe|lhes|mas|me|na|nas|no|nos|num|numa|nós|o|os|ou|para|por|que|se|sem|sob|sobre|te|tu|um|uma|umas|uns|vos|vós";
            const prepsRegex = new RegExp("(^|[" + spaces + "\\r\\n])(" + preps + ")[" + spaces + "]+", "gi");
            let tempText; do { tempText = text; text = text.replace(prepsRegex, "$1$2" + nbsp); } while (tempText !== text);
        }
        return text;
    }

    function applyPolish(text, opts) {
        if (opts.quo) {
            text = text.replace(/\x01([^\x01\x02]+)\x01([^\x01\x02]+)\x02([^\x01\x02]*)\x02/g, '„$1«$2»$3”');
            text = text.replace(/\x01/g, '„').replace(/\x02/g, '”');
        }
        if (opts.hang) {
            const preps = "a|ale|bez|bo|by|ci|co|czy|dla|do|go|i|ja|jak|ku|ma|mi|mu|na|nad|nie|o|od|on|po|pod|przed|przez|przy|się|są|tak|to|ty|u|w|we|z|za|ze|że";
            const prepsRegex = new RegExp("(^|[" + spaces + "\\r\\n])(" + preps + ")[" + spaces + "]+", "gi");
            let tempText; do { tempText = text; text = text.replace(prepsRegex, "$1$2" + nbsp); } while (tempText !== text);
        }
        return text;
    }

    function applyItalian(text, opts) {
        if (opts.quo) {
            text = text.replace(/\x01([^\x01\x02]+)\x01([^\x01\x02]+)\x02([^\x01\x02]*)\x02/g, '«$1“$2”$3»');
            text = text.replace(/\x01/g, '«').replace(/\x02/g, '»');
            const bStart = "(^|[^" + wordChars + "])";
            const bEnd = "(?=[^" + wordChars + "]|$)";
            text = text.replace(new RegExp(bStart + "['‘’]([^'‘’]+)['‘’]" + bEnd, "g"), '$1“$2”');
        }
        if (opts.hang) {
            const preps = "a|ad|al|allo|alla|ai|agli|alle|con|col|coi|da|dal|dallo|dalla|dai|dagli|dalle|di|del|dello|della|dei|degli|delle|e|ed|fra|gli|i|il|in|nel|nello|nella|nei|negli|nelle|la|le|lo|ma|ne|non|o|per|se|su|sul|sullo|sulla|sui|sugli|sulle|tra|un|una|uno|vi|ci|mi|ti|si";
            const prepsRegex = new RegExp("(^|[" + spaces + "\\r\\n])(" + preps + ")([" + spaces + "]+)", "gi");
            let tempText; do { tempText = text; text = text.replace(prepsRegex, "$1$2" + nbsp); } while (tempText !== text);
        }
        return text;
    }

    // ==================================================================
    // ОСНОВНОЙ ДВИЖОК
    // ==================================================================
    function applyRules(txt, opts) {
        if (!txt) return ''; 
        txt = normalizeImportedText(txt).replace(/ {2,}/g, ' ');
        
        const lang = detectLanguage(txt);

        // ИЗМЕНЕНИЕ: Распаковка лигатур теперь работает от галочки
        if (opts.lig) {
            txt = txt.replace(/\uFB00/g, 'ff').replace(/\uFB01/g, 'fi')
                     .replace(/\uFB02/g, 'fl').replace(/\uFB03/g, 'ffi').replace(/\uFB04/g, 'ffl');
        }

        txt = txt.replace(new RegExp('[' + spaces + ']+([.,!?:;])(?=[^' + spaces + '\"\'»”’\\)\\]])', 'g'), '$1 '); 
        txt = txt.replace(new RegExp('[' + spaces + ']+([.,!?:;])', 'g'), '$1');
        txt = txt.replace(new RegExp('([,;:])([^' + spaces + '\\r\\n\\d\"\'»”’\\x02\\)\\]])', 'g'), '$1 $2'); 
        
        const upperChars = "A-ZА-ЯЁĄĘĆŁŃŚŹŻÃÕÑŒÆÇÀÂÈÊËÎÏÔÙÛŸÄÖÜ";
        txt = txt.replace(new RegExp('([.!?])([' + upperChars + '])', 'g'), '$1 $2');

        txt = txt.replace(new RegExp('(^|[' + spaces + '\\r\\n])-([\"' + spaces + ']|$)', 'g'), '$1—$2'); 
        
        if (opts.pho) txt = txt.replace(new RegExp('(\\d)[' + spaces + ']*[-—–][' + spaces + ']*(?=\\d)', 'g'), '$1–');
        
        // ИЗМЕНЕНИЕ: Многоточия и стрелки теперь работают от галочек
        if (opts.ell) txt = txt.replace(/\.{3}/g, '…'); 
        if (opts.arr) txt = txt.replace(/->/g, '→').replace(/<-/g, '←');
        
        if (opts.deg) txt = txt.replace(new RegExp('(мм|см|м|км|mm|cm|m|km)(2|3)(?=[.,!\\r\\n' + spaces + ']|$)', 'gi'), (m, p1, p2) => p1 + (p2 === '2' ? '²' : '³'));
        
        if (opts.quo) {
            const dq = "«»“”„\"″‟";
            const bStart = "(^|[^" + wordChars + "])"; 
            const bEnd = "(?=[^" + wordChars + "]|$)";
            const dqRegex = new RegExp(bStart + "([" + dq + "])([^" + dq + "]+)([" + dq + "])" + bEnd, "g");
            
            let tempText; do { tempText = txt; txt = txt.replace(dqRegex, '$1\x01$3\x02'); } while (txt !== tempText);
            txt = txt.replace(new RegExp('\\x01[' + spaces + ']+', 'g'), '\x01').replace(new RegExp('[' + spaces + ']+\\x02', 'g'), '\x02');
        }
        
        if (lang === 'ru') txt = applyRussian(txt, opts);
        else if (lang === 'es') txt = applySpanish(txt, opts);
        else if (lang === 'fr') txt = applyFrench(txt, opts);
        else if (lang === 'de') txt = applyGerman(txt, opts);
        else if (lang === 'pt') txt = applyPortuguese(txt, opts);
        else if (lang === 'pl') txt = applyPolish(txt, opts);
        else if (lang === 'it') txt = applyItalian(txt, opts);
        else txt = applyEnglish(txt, opts);
        
        if (opts.num) {
            const thousandSep = (lang === 'en') ? ',' : nbsp;
            txt = txt.replace(new RegExp('(^|[^' + wordChars + '])(\\d{4,})(?=[^' + wordChars + ']|$)', 'g'), (m, prefix, num) => (num.length === 4 && (num.startsWith('19') || num.startsWith('20'))) ? m : prefix + num.replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1' + thousandSep));
        }

        const units = "мм|см|м|км|г|кг|т|мл|л|px|pt|mm|cm|m|km|g|kg|ml|l";
        txt = txt.replace(new RegExp("(\\d)[" + spaces + "]+(" + units + ")(²|³)?(?=[.,!?\\r\\n" + spaces + "]|$)", "gi"), "$1" + nbsp + "$2$3");
        txt = txt.replace(new RegExp("(\\d)[" + spaces + "]*°", "g"), '$1°');
        
        if (opts.cur) {
            txt = txt.replace(new RegExp("(\\d+)[" + spaces + "]*(руб|р|евр|евро|eur|долл|дол|usd)\\.?(?=[.,!?\\r\\n" + spaces + "]|$)", "gi"), (match, num, curr, offset, str) => {
                let sym = '₽';
                const c = curr.toLowerCase();
                if (c.startsWith('евр') || c.startsWith('eur')) sym = '€';
                else if (c.startsWith('дол') || c.startsWith('usd')) sym = '$';
                
                const hasDot = match.includes('.');
                let addDot = false;
                if (hasDot) {
                    const remainder = str.substring(offset + match.length);
                    if (remainder.length === 0 || /^[\r\n]/.test(remainder) || new RegExp("^[" + spaces + "]+[А-ЯЁA-Z]").test(remainder)) addDot = true;
                }
                return num + nbsp + sym + (addDot ? '.' : '');
            });
        }

        if (lang === 'en') {
            txt = txt.replace(new RegExp("(\\d)[" + spaces + "]*%", "g"), '$1%');
            if (opts.cur) {
                txt = txt.replace(new RegExp("(\\d+)[" + spaces + "]*([$€£¥₽])", "g"), '$2$1');
                txt = txt.replace(new RegExp("([$€£¥₽])[" + spaces + "]+(\\d+)", "g"), '$1$2');
            }
        } else {
            const percentSep = (lang === 'ru' || lang === 'fr' || lang === 'de' || lang === 'es' || lang === 'it') ? nbsp : '';
            txt = txt.replace(new RegExp("(\\d)[" + spaces + "]*%", "g"), '$1' + percentSep + '%');
            if (opts.cur) {
                txt = txt.replace(new RegExp("([$€£¥₽])[" + spaces + "]*(\\d+)", "g"), '$2' + nbsp + '$1');
                txt = txt.replace(new RegExp("(\\d+)[" + spaces + "]*([$€£¥₽])", "g"), '$1' + nbsp + '$2');
                txt = txt.replace(new RegExp(nbsp + '{2,}', 'g'), nbsp);
            }
        }

        if (lang === 'es') {
            txt = txt.replace(new RegExp("¿[" + spaces + "]+", "g"), '¿');
            txt = txt.replace(new RegExp("¡[" + spaces + "]+", "g"), '¡');
        }
        
        return cleanLineBreaksForInsert(txt);
    }

    function applyWrap(txt, opts) {
        const wrapL = parseInt(opts.wrap) || 0;
        if (opts.checkLimits && wrapL > 0) {
            txt = txt.split('\n').map(p => { 
                if (p.length <= wrapL) return p; 
                let currentLine = '', lines = []; 
                p.split(' ').forEach(word => { 
                    if ((currentLine + word).length > wrapL && currentLine !== '') { lines.push(currentLine.trim()); currentLine = word + ' '; } 
                    else { currentLine += word + ' '; } 
                }); 
                if (currentLine) lines.push(currentLine.trim()); 
                return lines.join('\n'); 
            }).join('\n');
        }

        const limitBoxW = parseInt(opts.boxW) || 0, fontSz = parseInt(opts.fontSz) || 0;
        if (opts.checkBox && limitBoxW > 0 && fontSz > 0) {
            const canvas = document.createElement('canvas'), ctx = canvas.getContext('2d');
            const tracking = parseFloat(opts.tracking) || 0; const scaleX = parseFloat(opts.scaleX) || 100;
            const targetPx = opts.unit === 'pt' ? fontSz * ((parseInt(opts.dpi)||72) / 72) : fontSz;
            ctx.font = `${targetPx}px "${opts.fontFam || 'Arial'}", sans-serif`;
            const scaleFactor = Math.max(0.1, scaleX / 100); const trackingPx = (tracking / 1000) * targetPx;
            const measureWidthWithPS = (text) => { if (!text) return 0; let width = ctx.measureText(text).width; if (text.length > 1 && trackingPx !== 0) width += (text.length - 1) * trackingPx; return width * scaleFactor; };
            
            txt = txt.split('\n').map(p => {
                let currentLine = '', lines = [];
                p.split(' ').forEach(word => {
                    const testLine = currentLine === '' ? word : currentLine + ' ' + word;
                    if (measureWidthWithPS(stripMarkdownStyles(stripHTMLTags(testLine))) > limitBoxW && currentLine !== '') { lines.push(currentLine); currentLine = word; } 
                    else currentLine = testLine;
                });
                if (currentLine) lines.push(currentLine); return lines.join('\n');
            }).join('\n');
        }
        return cleanLineBreaksForInsert(txt);
    }

    function applyAll(txt, opts) {
        let formatted = applyRules(txt, opts);
        return applyWrap(formatted, opts);
    }

    return { applyAll, applyRules, applyWrap, cleanLineBreaksForInsert, normalizeImportedText, stripHTMLTags, stripMarkdownStyles };
})();