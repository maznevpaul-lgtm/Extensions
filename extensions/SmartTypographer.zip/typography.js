// ================== SMART TYPOGRAPHER typography.js ==================

const SmartTypography = (() => {
    const nbsp = '\u00A0'; 
    const spaces = "\\s\\u00A0\\u2000-\\u200A\\u202F\\u205F\\u3000";
    const wordChars = "a-zA-Zа-яА-ЯёЁąęćłńśźżĄĘĆŁŃŚŹŻãõÃÕñÑœæçàâèêëîïôùûÿŒÆÇÀÂÈÊËÎÏÔÙÛŸäöüÄÖÜß0-9";

    // ЖЕСТКАЯ ОЧИСТКА: любые множественные переносы (\n\n) схлопываются в один (\n)
    function cleanLineBreaksForInsert(txt) { 
        return String(txt||'').replace(/\r\n/g, '\n').replace(/\r/g, '\n').replace(/[ \t]+\n/g, '\n').replace(/\n[ \t]+/g, '\n').replace(/\n{2,}/g, '\n').trim(); 
    }
    
    function normalizeImportedText(txt) {
        if (!txt) return ''; 
        txt = String(txt).replace(/\r\n/g, '\n').replace(/\r/g, '\n').replace(/[ \t]+/g, ' ').replace(/[ \t]*\n[ \t]*/g, '\n').replace(/\n{2,}/g, '\n');
        const lines = txt.split('\n').map(line => line.trim()); 
        return lines.length ? lines.join('\n').trim() : '';
    }

    function stripHTMLTags(str) { return String(str || '').replace(/<[^>]*>/g, ''); }
    function stripMarkdownStyles(str) { return String(str || '').replace(/\*\*(.*?)\*\*/g, '$1').replace(/__(.*?)__/g, '$1').replace(/\*(.*?)\*/g, '$1').replace(/_(.*?)_/g, '$1').replace(/<\/?(b|i|strong|em)>/gi, ''); }

    function applyRules(txt, opts) {
        if (!txt) return ''; 
        txt = normalizeImportedText(txt).replace(/ {2,}/g, ' ');
        
        txt = txt.replace(new RegExp('[' + spaces + ']+([.,!?:;])(?=[^' + spaces + '\"\'»”’\\)\\]])', 'g'), '$1 '); 
        txt = txt.replace(new RegExp('[' + spaces + ']+([.,!?:;])', 'g'), '$1');
        txt = txt.replace(new RegExp('([,;:])([^' + spaces + '\\r\\n\\d\"\'»”’\\x02\\)\\]])', 'g'), '$1 $2'); 
        txt = txt.replace(new RegExp('([.!?])([' + 'A-ZА-ЯЁĄĘĆŁŃŚŹŻÃÕÑŒÆÇÀÂÈÊËÎÏÔÙÛŸÄÖÜ' + '])', 'g'), '$1 $2');
        txt = txt.replace(new RegExp('(^|[' + spaces + '\\r\\n])-([\"' + spaces + ']|$)', 'g'), '$1—$2'); 
        
        if (opts.pho) txt = txt.replace(new RegExp('(\\d)[' + spaces + ']*[-—–][' + spaces + ']*(?=\\d)', 'g'), '$1–');
        
        txt = txt.replace(/\.{3}/g, '…'); 
        
        if (opts.deg) txt = txt.replace(new RegExp('(мм|см|м|км|mm|cm|m|km)(2|3)(?=[.,!\\r\\n' + spaces + ']|$)', 'gi'), (m, p1, p2) => p1 + (p2 === '2' ? '²' : '³'));
        
        if (opts.quo) {
            let tempText; do { tempText = txt; txt = txt.replace(new RegExp('(^|[^' + wordChars + '])([«»“”„\"″‟])([^«»“”„\"″‟]+)([«»“”„\"″‟])(?=[^' + wordChars + ']|$)', 'g'), '$1\x01$3\x02'); } while (txt !== tempText);
            txt = txt.replace(new RegExp('\\x01[' + spaces + ']+', 'g'), '\x01').replace(new RegExp('[' + spaces + ']+\\x02', 'g'), '\x02').replace(/\x01([^\x01\x02]+)\x01([^\x01\x02]+)\x02([^\x01\x02]*)\x02/g, '«$1„$2“$3»').replace(/\x01/g, '«').replace(/\x02/g, '»');
        }
        
        if (opts.hang) { 
            const shortWords = 'а|без|бы|в|вне|во|вот|все|вы|да|для|до|же|за|и|из|или|им|их|к|ко|ли|мы|на|над|не|ни|но|о|об|обо|он|от|по|под|при|про|с|со|те|то|ту|ты|у|я'; 
            const prepRegex = new RegExp('(^|[' + spaces + '\\r\\n])(' + shortWords + ')([' + spaces + ']+)', 'gi'); 
            txt = txt.replace(prepRegex, '$1$2' + nbsp); 
        }
        
        const prepsRegex = new RegExp('(^|[' + spaces + '\\r\\n])(а|без|бы|в|вне|во|вот|все|вы|да|для|до|же|за|и|из|или|им|их|к|ко|ли|мы|на|над|не|ни|но|о|об|обо|он|от|по|под|при|про|с|со|те|то|ту|ты|у|я)([' + ' \\t\\u2000-\\u200A\\u202F\\u205F\\u3000' + ']+)', 'gi');
        let tempText2; do { tempText2 = txt; txt = txt.replace(prepsRegex, '$1$2' + nbsp); } while (tempText2 !== txt);
        
        if (opts.num) txt = txt.replace(new RegExp('(^|[^' + wordChars + '])(\\d{4,})(?=[^' + wordChars + ']|$)', 'g'), (m, prefix, num) => (num.length === 4 && (num.startsWith('19') || num.startsWith('20'))) ? m : prefix + num.replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1' + nbsp));
        
        if (opts.cur) txt = txt.replace(new RegExp('(\\d+)[' + spaces + ']*(руб|р|евр|евро|eur|долл|дол|usd)\\.?(?=[.,!?\\r\\n' + spaces + ']|$)', 'gi'), (m, num, curr) => { let sym = '₽'; const c = curr.toLowerCase(); if (c.startsWith('евр') || c.startsWith('eur')) sym = '€'; else if (c.startsWith('дол') || c.startsWith('usd')) sym = '$'; return num + nbsp + sym; });
        
        return cleanLineBreaksForInsert(txt);
    }

    function applyWrap(txt, opts) {
        const wrapL = parseInt(opts.wrap) || 0;
        if (opts.checkLimits && wrapL > 0) {
            txt = txt.split('\n').map(p => { 
                if (p.length <= wrapL) return p; 
                let currentLine = '', lines = []; 
                p.split(' ').forEach(word => { 
                    if ((currentLine + word).length > wrapL && currentLine !== '') { lines.push(currentLine.trim()); currentLine = word + ' '; } 
                    else { currentLine += word + ' '; } 
                }); 
                if (currentLine) lines.push(currentLine.trim()); 
                return lines.join('\n'); 
            }).join('\n');
        }

        const limitBoxW = parseInt(opts.boxW) || 0, fontSz = parseInt(opts.fontSz) || 0;
        if (opts.checkBox && limitBoxW > 0 && fontSz > 0) {
            const canvas = document.createElement('canvas'), ctx = canvas.getContext('2d');
            const tracking = parseFloat(opts.tracking) || 0; const scaleX = parseFloat(opts.scaleX) || 100;
            const targetPx = opts.unit === 'pt' ? fontSz * ((parseInt(opts.dpi)||72) / 72) : fontSz;
            ctx.font = `${targetPx}px "${opts.fontFam || 'Arial'}", sans-serif`;
            const scaleFactor = Math.max(0.1, scaleX / 100); const trackingPx = (tracking / 1000) * targetPx;
            const measureWidthWithPS = (text) => { if (!text) return 0; let width = ctx.measureText(text).width; if (text.length > 1 && trackingPx !== 0) width += (text.length - 1) * trackingPx; return width * scaleFactor; };
            
            txt = txt.split('\n').map(p => {
                let currentLine = '', lines = [];
                p.split(' ').forEach(word => {
                    const testLine = currentLine === '' ? word : currentLine + ' ' + word;
                    if (measureWidthWithPS(stripMarkdownStyles(stripHTMLTags(testLine))) > limitBoxW && currentLine !== '') { lines.push(currentLine); currentLine = word; } 
                    else currentLine = testLine;
                });
                if (currentLine) lines.push(currentLine); return lines.join('\n');
            }).join('\n');
        }
        return cleanLineBreaksForInsert(txt);
    }

    function applyAll(txt, opts) {
        let formatted = applyRules(txt, opts);
        return applyWrap(formatted, opts);
    }

    return { applyAll, applyRules, applyWrap, cleanLineBreaksForInsert, normalizeImportedText, stripHTMLTags, stripMarkdownStyles };
})();