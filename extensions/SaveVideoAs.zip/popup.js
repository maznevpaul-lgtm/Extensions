const lang = navigator.language.startsWith('ru') ? 'ru' : 'en';
const i18n = {
  ru: {
    title: "Настройки видео-загрузчика",
    show: "Показывать кнопки на видео",
    copy: "Копировать ссылку при скачивании"
  },
  en: {
    title: "Video Downloader Settings",
    show: "Show buttons on videos",
    copy: "Copy URL on download"
  }
};

document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('loc-title').innerText = i18n[lang].title;
  document.getElementById('loc-show').innerText = i18n[lang].show;
  document.getElementById('loc-copy').innerText = i18n[lang].copy;

  const checkboxButtons = document.getElementById('toggleButtons');
  const checkboxCopyUrl = document.getElementById('copyUrlOnSave');

  chrome.storage.local.get(['showButtons', 'copyUrlOnSave'], (result) => {
    checkboxButtons.checked = result.showButtons !== false; 
    checkboxCopyUrl.checked = result.copyUrlOnSave === true;
  });

  checkboxButtons.addEventListener('change', () => {
    chrome.storage.local.set({ showButtons: checkboxButtons.checked });
  });

  checkboxCopyUrl.addEventListener('change', () => {
    chrome.storage.local.set({ copyUrlOnSave: checkboxCopyUrl.checked });
  });
});