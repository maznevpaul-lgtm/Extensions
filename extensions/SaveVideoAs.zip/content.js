// Определение языка браузера
const lang = navigator.language.startsWith('ru') ? 'ru' : 'en';

const i18n = {
  ru: {
    drag: 'Потяните, чтобы переместить',
    save: 'Скачать видео',
    copy: 'Скопировать ссылку',
    blobStop: 'Остановить запись и сохранить',
    blobFailed: 'Захват видео заблокирован сайтом (DRM).'
  },
  en: {
    drag: 'Drag to move',
    save: 'Download video',
    copy: 'Copy video URL',
    blobStop: 'Stop recording & save',
    blobFailed: 'Video capture blocked (DRM).'
  }
};

// Стили (Плавающий HUD + Адаптация под мобильные экраны)
const styles = `
  .save-vid-overlay {
    position: fixed !important; /* Теперь панель парит поверх всего экрана */
    z-index: 2147483647 !important;
    display: flex;
    opacity: 0;
    visibility: hidden;
    transition: opacity 0.4s ease, visibility 0.4s ease !important; /* Очень плавное затухание */
    flex-direction: column;
    gap: 8px; 
    padding: 8px; 
    background-color: rgba(20, 20, 20, 0.7) !important;
    border-radius: 12px !important;
    backdrop-filter: blur(4px);
    -webkit-backdrop-filter: blur(4px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.3) !important;
    border: 1px solid rgba(255, 255, 255, 0.1) !important;
    touch-action: none; 
  }
  .save-vid-overlay.save-vid-horizontal {
    flex-direction: row !important;
  }
  .save-vid-overlay.save-vid-visible {
    opacity: 1;
    visibility: visible;
  }

  .save-vid-secondary-container {
    display: flex;
    flex-direction: inherit;
    gap: 0;
    overflow: hidden;
    max-height: 0;
    max-width: 0;
    opacity: 0;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1) !important;
  }
  .save-vid-overlay:not(.save-vid-horizontal).save-vid-expanded .save-vid-secondary-container {
    max-height: 120px;
    max-width: 100px;
    opacity: 1;
    gap: 8px;
  }
  .save-vid-overlay.save-vid-horizontal.save-vid-expanded .save-vid-secondary-container {
    max-height: 100px;
    max-width: 140px;
    opacity: 1;
    gap: 8px;
  }
  .save-vid-text-btn {
    font-family: Arial, sans-serif !important;
    font-weight: bold !important;
    font-size: 13px !important;
  }

  .save-vid-drag-handle {
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: grab;
    color: rgba(255, 255, 255, 0.6) !important;
    padding: 6px !important; 
    border-radius: 6px !important;
    transition: background-color 0.2s;
  }
  .save-vid-drag-handle:active {
    background-color: rgba(255, 255, 255, 0.2) !important;
    color: white !important;
    cursor: grabbing !important;
  }
  .save-vid-btn {
    -webkit-appearance: none !important;
    appearance: none !important;
    background-color: rgba(255, 255, 255, 0.9) !important;
    border: none !important;
    border-radius: 8px !important;
    width: 44px !important; 
    height: 44px !important; 
    color: #111 !important;
    cursor: pointer !important;
    box-shadow: 0 2px 4px rgba(0,0,0,0.2) !important;
    transition: all 0.2s ease !important;
    display: flex !important;
    justify-content: center !important;
    align-items: center !important;
    padding: 0 !important;
    margin: 0 !important;
  }
  .save-vid-btn:active {
    transform: scale(0.9) !important;
    background-color: #e50914 !important;
    color: white !important;
  }
  .save-vid-btn.disabled {
    opacity: 0.5 !important;
    cursor: not-allowed !important;
    background-color: #ccc !important;
  }
  .save-vid-btn svg {
    stroke: currentColor !important;
    width: 22px !important;
    height: 22px !important;
  }
`;

const styleSheet = document.createElement("style");
styleSheet.innerText = styles;
document.head.appendChild(styleSheet);

// Элементы интерфейса
const overlay = document.createElement('div');
overlay.className = 'save-vid-overlay';

const dragHandle = document.createElement('div');
dragHandle.className = 'save-vid-drag-handle';
dragHandle.title = i18n[lang].drag;
dragHandle.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><circle cx="9" cy="5" r="1.5"/><circle cx="15" cy="5" r="1.5"/><circle cx="9" cy="12" r="1.5"/><circle cx="15" cy="12" r="1.5"/><circle cx="9" cy="19" r="1.5"/><circle cx="15" cy="19" r="1.5"/></svg>`;

const secondaryContainer = document.createElement('div');
secondaryContainer.className = 'save-vid-secondary-container';

const btn720 = document.createElement('button');
btn720.className = 'save-vid-btn save-vid-text-btn';
btn720.innerText = '720p';
btn720.title = 'Высокое сжатие (экономия памяти)';

const btn1080 = document.createElement('button');
btn1080.className = 'save-vid-btn save-vid-text-btn';
btn1080.innerText = '1080p';
btn1080.title = 'Оригинальное качество (максимальный битрейт)';

secondaryContainer.appendChild(btn720);
secondaryContainer.appendChild(btn1080);

const btnSave = document.createElement('button');
btnSave.className = 'save-vid-btn';
btnSave.title = i18n[lang].save;
const saveIconSVG = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>`;
btnSave.innerHTML = saveIconSVG;

const btnCopyLink = document.createElement('button');
btnCopyLink.className = 'save-vid-btn';
btnCopyLink.title = i18n[lang].copy;
btnCopyLink.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path></svg>`;

overlay.appendChild(dragHandle);
overlay.appendChild(secondaryContainer);
overlay.appendChild(btnSave);
overlay.appendChild(btnCopyLink);
document.body.appendChild(overlay);

// Настройки и состояния
let isOverlayEnabled = true;
let isCopyUrlOnSave = false;
let anchorX = 0.95; 
let anchorY = 0.05; 

chrome.storage.local.get({ showButtons: true, copyUrlOnSave: false, vidAnchorX: 0.95, vidAnchorY: 0.05 }, (result) => {
  isOverlayEnabled = result.showButtons;
  isCopyUrlOnSave = result.copyUrlOnSave;
  anchorX = result.vidAnchorX;
  anchorY = result.vidAnchorY;
});

chrome.storage.onChanged.addListener((changes, namespace) => {
  if (namespace === 'local') {
    if (changes.showButtons !== undefined) {
      isOverlayEnabled = changes.showButtons.newValue;
      if (!isOverlayEnabled) {
          overlay.classList.remove('save-vid-visible');
          overlay.classList.remove('save-vid-expanded');
          isExpanded = false;
      }
    }
    if (changes.copyUrlOnSave !== undefined) isCopyUrlOnSave = changes.copyUrlOnSave.newValue;
  }
});

let currentVideoElement = null;
let currentVideoSrc = null;
let isBlob = false;
let isDragging = false; 
let isExpanded = false;
let isPinned = false; // Откреплена ли панель от видео
let idleTimeout = null;
let mouseCheckTimeout = null;

// ПЕРЕМЕННЫЕ ДЛЯ ЗАПИСИ
let isRecording = false;
let mediaRecorder = null;
let recordedChunks = [];

// --- ТАЙМЕР ПОКОЯ (Плавное затухание) ---
function resetIdleTimer() {
  clearTimeout(idleTimeout);
  overlay.classList.add('save-vid-visible');
  
  // Панель пропадет через 2.5 секунды, если не двигать мышку
  idleTimeout = setTimeout(() => {
    // Не скрывать, если идет запись, перетаскивание или открыто меню
    if (isDragging || isRecording || isExpanded) return; 
    overlay.classList.remove('save-vid-visible');
    overlay.classList.remove('save-vid-expanded');
    isExpanded = false;
  }, 2500); 
}

// --- УСТАНОВКА ПОЗИЦИИ ---
function positionOverlay(rect) {
  if (anchorY < 0.25 || anchorY > 0.75) {
    overlay.classList.add('save-vid-horizontal');
  } else {
    overlay.classList.remove('save-vid-horizontal');
  }

  // Position: fixed означает, что координаты считаются от краев окна браузера (viewport)
  let top = rect.top + (rect.height * anchorY) - (overlay.offsetHeight / 2);
  let left = rect.left + (rect.width * anchorX) - (overlay.offsetWidth / 2);

  const pad = 16;
  const maxLeft = window.innerWidth - overlay.offsetWidth - pad;
  const maxTop = window.innerHeight - overlay.offsetHeight - pad;

  // Сначала пытаемся удержать внутри видео
  top = Math.max(rect.top + pad, Math.min(top, rect.bottom - overlay.offsetHeight - pad));
  left = Math.max(rect.left + pad, Math.min(left, rect.right - overlay.offsetWidth - pad));
  
  // Но жестко блокируем вылет за пределы экрана браузера
  top = Math.max(pad, Math.min(top, maxTop));
  left = Math.max(pad, Math.min(left, maxLeft));

  overlay.style.top = `${top}px`;
  overlay.style.left = `${left}px`;
}

// ПЕРЕТАСКИВАНИЕ
let dragStartX, dragStartY, initialTop, initialLeft;

function handleDragStart(e) {
  isDragging = true;
  isPinned = true; // С этого момента панель откреплена от видео!
  const event = e.touches ? e.touches[0] : e;
  dragStartX = event.clientX;
  dragStartY = event.clientY;
  initialTop = parseFloat(overlay.style.top) || 0;
  initialLeft = parseFloat(overlay.style.left) || 0;
  if (!e.touches) e.preventDefault();
}

function handleDragMove(e) {
  if (!isDragging) return;
  if (e.cancelable) e.preventDefault(); 
  
  const event = e.touches ? e.touches[0] : e;
  let newTop = initialTop + (event.clientY - dragStartY);
  let newLeft = initialLeft + (event.clientX - dragStartX);
  
  const maxLeft = window.innerWidth - overlay.offsetWidth;
  const maxTop = window.innerHeight - overlay.offsetHeight;
  
  // Свободное перемещение по всему экрану (с учетом границ)
  newTop = Math.max(0, Math.min(newTop, maxTop));
  newLeft = Math.max(0, Math.min(newLeft, maxLeft));

  overlay.style.top = `${newTop}px`;
  overlay.style.left = `${newLeft}px`;
}

function handleDragEnd(e) {
  if (isDragging) {
    isDragging = false;
    resetIdleTimer();
    
    // Запоминаем якорь для будущих новых видео
    if (currentVideoElement) {
      const rect = currentVideoElement.getBoundingClientRect();
      const overlayRect = overlay.getBoundingClientRect();
      anchorX = Math.max(0, Math.min(1, ((overlayRect.left + overlayRect.width / 2) - rect.left) / rect.width));
      anchorY = Math.max(0, Math.min(1, ((overlayRect.top + overlayRect.height / 2) - rect.top) / rect.height));
      chrome.storage.local.set({ vidAnchorX: anchorX, vidAnchorY: anchorY });
    }
  }
}

dragHandle.addEventListener('mousedown', handleDragStart);
document.addEventListener('mousemove', handleDragMove, { passive: false });
document.addEventListener('mouseup', handleDragEnd);
dragHandle.addEventListener('touchstart', handleDragStart, { passive: true });
document.addEventListener('touchmove', handleDragMove, { passive: false });
document.addEventListener('touchend', handleDragEnd);

// ПОИСК ВИДЕО (РЕНТГЕН)
function getAbsoluteUrl(url) {
  if (url.startsWith('blob:')) return url; 
  try { return new URL(url, document.baseURI).href; } catch (e) { return url; }
}

function checkElementForVideo(el) {
  if (!el) return null;
  const rect = el.getBoundingClientRect();
  if (rect.width < 100 || rect.height < 100) return null;

  if (el.tagName === 'VIDEO') {
    let src = el.src || el.currentSrc;
    if (!src) {
      const source = el.querySelector('source');
      if (source) src = source.src;
    }
    if (src) {
      return { el: el, src: getAbsoluteUrl(src), rect: rect };
    }
  }
  return null;
}

function detectVideoEvent(e) {
  if (!isOverlayEnabled || isDragging) return;

  if (mouseCheckTimeout) return; 
  mouseCheckTimeout = setTimeout(() => {
    mouseCheckTimeout = null;
    
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const clientY = e.touches ? e.touches[0].clientY : e.clientY;
    
    const elements = document.elementsFromPoint(clientX, clientY);
    let foundVideoData = null;
    let isOverOverlay = false;
    
    if (elements) {
      for (const el of elements) {
        if (el === overlay || overlay.contains(el)) {
            isOverOverlay = true;
        }
        if (!foundVideoData) {
            const targetData = checkElementForVideo(el);
            if (targetData) foundVideoData = targetData;
        }
      }
    }

    if (foundVideoData) {
        // Мышка над видео
        if (foundVideoData.el !== currentVideoElement) {
            isPinned = false; // Прилипаем к НОВОМУ видео
            currentVideoElement = foundVideoData.el;
            currentVideoSrc = foundVideoData.src;
            isBlob = currentVideoSrc.startsWith('blob:');
        }
        btnSave.title = isRecording ? i18n[lang].blobStop : i18n[lang].save;
        
        if (!isPinned) {
            positionOverlay(foundVideoData.rect);
        }
        resetIdleTimer();
    } else if (isOverOverlay) {
        // Мышка над самой панелью
        resetIdleTimer();
    } else {
        // Мышка в другой части экрана (не над видео и не над панелью)
        if (isPinned && currentVideoElement && document.body.contains(currentVideoElement)) {
            // Если панель была откреплена, любое движение мышки по экрану возвращает ее!
            resetIdleTimer();
        }
    }
  }, 150); 
}

document.addEventListener('mousemove', detectVideoEvent);
document.addEventListener('touchstart', detectVideoEvent, { passive: true });

// Если мы скроллим страницу, а панель приклеена к видео - она должна следовать за ним
let scrollTicking = false;
document.addEventListener('scroll', () => {
    if (!scrollTicking && !isPinned && currentVideoElement && overlay.classList.contains('save-vid-visible')) {
        window.requestAnimationFrame(() => {
            const rect = currentVideoElement.getBoundingClientRect();
            // Если видео скрылось за границами экрана - прячем панель
            if (rect.bottom < 0 || rect.top > window.innerHeight || rect.right < 0 || rect.left > window.innerWidth) {
                overlay.classList.remove('save-vid-visible');
                overlay.classList.remove('save-vid-expanded');
                isExpanded = false;
            } else {
                positionOverlay(rect);
            }
            scrollTicking = false;
        });
        scrollTicking = true;
    }
}, { passive: true, capture: true });


// КОПИРОВАНИЕ ССЫЛКИ
function copyTextToClipboard(text, btnElement) {
  const originalContent = btnElement.innerHTML;
  btnElement.innerHTML = '⏳';
  navigator.clipboard.writeText(text).then(() => {
    btnElement.innerHTML = '✅';
    setTimeout(() => { btnElement.innerHTML = originalContent; }, 2000);
  }).catch(() => {
    btnElement.innerHTML = '❌';
    setTimeout(() => { btnElement.innerHTML = originalContent; }, 2000);
  });
}

// ЛОГИКА СКАЧИВАНИЯ
btnSave.addEventListener('click', (e) => {
  e.preventDefault(); e.stopPropagation();
  if (!currentVideoSrc) return;

  if (isRecording) {
    btnSave.innerHTML = '⏳';
    mediaRecorder.stop();
    return;
  }

  isExpanded = !isExpanded;
  if (isExpanded) {
    overlay.classList.add('save-vid-expanded');
    clearTimeout(idleTimeout); // Удерживаем панель открытой пока открыто меню
  } else {
    overlay.classList.remove('save-vid-expanded');
    resetIdleTimer();
  }
});

btn720.addEventListener('click', (e) => {
  e.preventDefault(); e.stopPropagation();
  overlay.classList.remove('save-vid-expanded');
  isExpanded = false;
  startDownloadProcess(2500000); // 2.5 Мбит/с
});

btn1080.addEventListener('click', (e) => {
  e.preventDefault(); e.stopPropagation();
  overlay.classList.remove('save-vid-expanded');
  isExpanded = false;
  startDownloadProcess(8500000); // 8.5 Мбит/с
});

async function startDownloadProcess(targetBitrate) {
  const originalContent = saveIconSVG;
  btnSave.innerHTML = '⏳';
  
  const preventTabClose = (e) => {
    e.preventDefault();
    e.returnValue = '';
  };
  window.addEventListener('beforeunload', preventTabClose);

  try {
    if (isBlob) throw new Error('BLOB_URL');

    const response = await fetch(currentVideoSrc, { method: 'GET', credentials: 'include' });
    if (!response.ok) throw new Error('FETCH_FAILED');
    
    const snippet = await response.clone().blob().then(b => b.slice(0, 50).text());
    if (snippet.trim().toLowerCase().startsWith('<!doctype') || snippet.trim().toLowerCase().startsWith('<html')) {
      throw new Error('SW_HTML_INTERCEPT'); 
    }

    const rawBlob = await response.blob(); 
    const contentType = response.headers.get('content-type');
    let ext = contentType && contentType.includes('webm') ? '.webm' : '.mp4';
    let mime = contentType && contentType.includes('webm') ? 'video/webm' : 'video/mp4';

    const videoBlob = new Blob([rawBlob], { type: mime });
    const localUrl = URL.createObjectURL(videoBlob);
    
    const a = document.createElement('a');
    a.style.display = 'none';
    a.href = localUrl;
    a.download = 'video_' + Date.now() + ext;
    document.body.appendChild(a);
    a.click();
    
    setTimeout(() => { document.body.removeChild(a); URL.revokeObjectURL(localUrl); }, 600000);
    btnSave.innerHTML = '✅';

  } catch (err) {
    const isCorsError = err.name === 'TypeError' || err.message === 'FETCH_FAILED';
    const isTelegramIntercept = err.message === 'SW_HTML_INTERCEPT';

    if (isTelegramIntercept || isBlob || isCorsError) {
      try {
        const stream = currentVideoElement.captureStream ? currentVideoElement.captureStream() : currentVideoElement.mozCaptureStream();
        if (!stream) throw new Error("captureStream not supported");
        
        const options = { mimeType: 'video/webm' };
        if (MediaRecorder.isTypeSupported('video/webm; codecs=vp9')) {
          options.mimeType = 'video/webm; codecs=vp9';
        } else if (MediaRecorder.isTypeSupported('video/webm; codecs=h264')) {
          options.mimeType = 'video/webm; codecs=h264';
        }
        
        options.videoBitsPerSecond = targetBitrate; 
        
        mediaRecorder = new MediaRecorder(stream, options);
        recordedChunks = [];
        
        mediaRecorder.ondataavailable = (event) => {
          if (event.data.size > 0) recordedChunks.push(event.data);
        };
        
        mediaRecorder.onstop = () => {
          isRecording = false;
          window.removeEventListener('beforeunload', preventTabClose);
          
          if (recordedChunks.length === 0) {
             btnSave.innerHTML = '❌';
             setTimeout(() => { btnSave.innerHTML = originalContent; }, 3000);
             return;
          }

          btnSave.innerHTML = '⏳';
          
          const blob = new Blob(recordedChunks, { type: 'video/webm' });
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.style.display = 'none';
          a.href = url;
          a.download = 'record_' + Date.now() + '.webm';
          document.body.appendChild(a);
          a.click();
          
          setTimeout(() => { document.body.removeChild(a); URL.revokeObjectURL(url); }, 600000);
          
          btnSave.innerHTML = '✅';
          setTimeout(() => { btnSave.innerHTML = originalContent; resetIdleTimer(); }, 2000);
        };
        
        mediaRecorder.start();
        isRecording = true;
        currentVideoElement.play(); 
        
        btnSave.innerHTML = '⏹️';
        btnSave.title = i18n[lang].blobStop;
        btnSave.style.backgroundColor = '#ff0000';
        btnSave.style.color = '#ffffff';
        btnSave.style.transform = 'scale(1.1)';
        return; 
        
      } catch (recordErr) {
        chrome.runtime.sendMessage({ action: 'download_video', srcUrl: currentVideoSrc });
        btnSave.innerHTML = '✅';
      }
    } else {
      chrome.runtime.sendMessage({ action: 'download_video', srcUrl: currentVideoSrc });
      btnSave.innerHTML = '✅';
    }
  }

  window.removeEventListener('beforeunload', preventTabClose);
  setTimeout(() => { if (!isRecording) { btnSave.innerHTML = originalContent; resetIdleTimer(); } }, 2000);
  if (isCopyUrlOnSave && !isRecording) copyTextToClipboard(currentVideoSrc, btnCopyLink);
}

btnCopyLink.addEventListener('click', (e) => {
  e.preventDefault(); e.stopPropagation();
  if (currentVideoSrc) {
    copyTextToClipboard(currentVideoSrc, btnCopyLink);
  }
});