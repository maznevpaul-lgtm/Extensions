chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({ 
    id: "save-video-direct", 
    title: "Скачать это видео", 
    contexts: ["video"] 
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "save-video-direct") {
    downloadVideo(info.srcUrl);
  }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'download_video') {
    downloadVideo(request.srcUrl);
  }
});

function downloadVideo(srcUrl) {
  // Защита от blob-ссылок, которые нельзя скачать напрямую через downloads API
  if (srcUrl.startsWith('blob:')) {
    console.warn("Потоковые blob: ссылки не поддерживаются напрямую.");
    return;
  }

  let filename = "video_" + Date.now();
  try {
    const urlPath = new URL(srcUrl).pathname;
    const extractedName = urlPath.substring(urlPath.lastIndexOf('/') + 1);
    if (extractedName && extractedName.includes('.')) {
      filename = extractedName;
    } else {
      filename += ".mp4"; // Дефолтное расширение
    }
    // Ограничение длины имени
    if (filename.length > 50) filename = filename.substring(filename.length - 50);
  } catch (e) {
    filename += ".mp4";
  }

  chrome.downloads.download({
    url: srcUrl,
    filename: filename,
    saveAs: true
  });
}