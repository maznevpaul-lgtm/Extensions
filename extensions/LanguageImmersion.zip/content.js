// ПРОСТЫЕ СПИСКИ СЛОВ
const TARGET_WORDS_RU = [ "я", "меня", "мы", "ты", "он", "его", "она", "её", "они", "их", "это", "человек", "люди", "мужчина", "женщина", "ребенок", "год", "время", "день", "ночь", "утро", "вечер", "жизнь", "работа", "слово", "вопрос", "ответ", "место", "город", "улица", "страна", "мир", "дом", "друг", "деньги", "машина", "книга", "вода", "земля", "свет", "рука", "глаз", "лицо", "конец", "начало", "проблема", "хорошо", "плохо", "большой", "маленький", "новый", "старый", "первый", "последний", "всегда", "никогда", "сегодня", "завтра", "вчера", "здесь", "там", "сейчас", "очень", "кто", "что", "где", "когда", "почему", "как", "если", "да", "нет" ];
const TARGET_WORDS_EN = [ "i", "me", "we", "you", "he", "his", "she", "her", "they", "them", "this", "person", "people", "man", "woman", "child", "year", "time", "day", "night", "morning", "evening", "life", "work", "word", "question", "answer", "place", "city", "street", "country", "world", "house", "friend", "money", "car", "book", "water", "earth", "light", "hand", "eye", "face", "end", "start", "problem", "good", "bad", "big", "small", "new", "old", "first", "last", "always", "never", "today", "tomorrow", "yesterday", "here", "there", "now", "very", "who", "what", "where", "when", "why", "how", "if", "yes", "no" ];
const TARGET_WORDS_ES = [ "yo", "me", "nosotros", "tú", "él", "su", "ella", "ellos", "los", "esto", "persona", "personas", "hombre", "mujer", "niño", "año", "tiempo", "día", "noche", "mañana", "tarde", "vida", "trabajo", "palabra", "pregunta", "respuesta", "lugar", "ciudad", "calle", "país", "mundo", "casa", "amigo", "dinero", "coche", "libro", "agua", "tierra", "luz", "mano", "ojo", "cara", "fin", "inicio", "problema", "bien", "mal", "grande", "pequeño", "nuevo", "viejo", "primero", "último", "siempre", "nunca", "hoy", "mañana", "ayer", "aquí", "allí", "ahora", "muy", "quién", "qué", "dónde", "cuándo", "por qué", "cómo", "si", "sí", "no" ];

const OFFLINE_DICT = {
    "я": { en: "i", es: "yo" }, "меня": { en: "me", es: "me" }, "мы": { en: "we", es: "nosotros" }, "ты": { en: "you", es: "tú" }, "он": { en: "he", es: "él" }, "его": { en: "his", es: "su" }, "она": { en: "she", es: "ella" }, "её": { en: "her", es: "su" }, "они": { en: "they", es: "ellos" }, "их": { en: "them", es: "los" }, "это": { en: "this", es: "esto" }, "человек": { en: "person", es: "persona" }, "люди": { en: "people", es: "personas" }, "мужчина": { en: "man", es: "hombre" }, "женщина": { en: "woman", es: "mujer" }, "ребенок": { en: "child", es: "niño" }, "год": { en: "year", es: "año" }, "время": { en: "time", es: "tiempo" }, "день": { en: "day", es: "día" }, "ночь": { en: "night", es: "noche" }, "утро": { en: "morning", es: "mañana" }, "вечер": { en: "evening", es: "tarde" }, "жизнь": { en: "life", es: "vida" }, "работа": { en: "work", es: "trabajo" }, "слово": { en: "word", es: "palabra" }, "вопрос": { en: "question", es: "pregunta" }, "ответ": { en: "answer", es: "respuesta" }, "место": { en: "place", es: "lugar" }, "город": { en: "city", es: "ciudad" }, "улица": { en: "street", es: "calle" }, "страна": { en: "country", es: "país" }, "мир": { en: "world", es: "mundo" }, "дом": { en: "house", es: "casa" }, "друг": { en: "friend", es: "amigo" }, "деньги": { en: "money", es: "dinero" }, "машина": { en: "car", es: "coche" }, "книга": { en: "book", es: "libro" }, "вода": { en: "water", es: "agua" }, "земля": { en: "earth", es: "tierra" }, "свет": { en: "light", es: "luz" }, "рука": { en: "hand", es: "mano" }, "глаз": { en: "eye", es: "ojo" }, "лицо": { en: "face", es: "cara" }, "конец": { en: "end", es: "fin" }, "начало": { en: "start", es: "inicio" }, "проблема": { en: "problem", es: "problema" }, "хорошо": { en: "good", es: "bien" }, "плохо": { en: "bad", es: "mal" }, "большой": { en: "big", es: "grande" }, "маленький": { en: "small", es: "pequeño" }, "новый": { en: "new", es: "nuevo" }, "старый": { en: "old", es: "viejo" }, "первый": { en: "first", es: "primero" }, "последний": { en: "last", es: "último" }, "всегда": { en: "always", es: "siempre" }, "никогда": { en: "never", es: "nunca" }, "сегодня": { en: "today", es: "hoy" }, "завтра": { en: "tomorrow", es: "mañana" }, "вчера": { en: "yesterday", es: "ayer" }, "здесь": { en: "here", es: "aquí" }, "там": { en: "there", es: "allí" }, "сейчас": { en: "now", es: "ahora" }, "очень": { en: "very", es: "muy" }, "кто": { en: "who", es: "quién" }, "что": { en: "what", es: "qué" }, "где": { en: "where", es: "dónde" }, "когда": { en: "when", es: "cuándo" }, "почему": { en: "why", es: "por qué" }, "как": { en: "how", es: "cómo" }, "если": { en: "if", es: "si" }, "да": { en: "yes", es: "sí" }, "нет": { en: "no", es: "no" }
};

function getOfflineTranslation(word, sourceLang, targetLang) {
    word = word.toLowerCase();
    if (sourceLang === 'ru' && OFFLINE_DICT[word]) return OFFLINE_DICT[word][targetLang];
    if (targetLang === 'ru') {
        for (const [ruWord, trans] of Object.entries(OFFLINE_DICT)) {
            if (trans[sourceLang] === word) return ruWord;
        }
    }
    if ((sourceLang === 'en' && targetLang === 'es') || (sourceLang === 'es' && targetLang === 'en')) {
        for (const trans of Object.values(OFFLINE_DICT)) {
            if (trans[sourceLang] === word) return trans[targetLang];
        }
    }
    return null;
}

let currentRunId = 0;
let translationCache = {};

function fixMixedScriptSpacing(text) {
    if (!text) return text;
    let fixed = text.replace(/([a-zA-ZáéíóúñÁÉÍÓÚÑüÜ])([а-яА-ЯёЁ])/g, '$1 $2');
    fixed = fixed.replace(/([а-яА-ЯёЁ])([a-zA-ZáéíóúñÁÉÍÓÚÑüÜ])/g, '$1 $2');
    return fixed;
}

function showLoader(percentage) {
    let loader = document.getElementById('lingvo-loader');
    if (!loader) {
        loader = document.createElement('div');
        loader.id = 'lingvo-loader';
        document.body.appendChild(loader);
    }
    loader.style.cssText = 'position:fixed; bottom:20px; right:20px; background:#4f46e5; color:white; padding:12px 24px; border-radius:8px; z-index:2147483647; font-family:sans-serif; font-size: 14px; font-weight: bold; box-shadow:0 4px 12px rgba(0,0,0,0.15); transition: opacity 0.3s ease;';
    loader.textContent = `⏳ Перевод (${percentage}%)...`;
    loader.style.opacity = '1';
}

function hideLoader(hasError = false) {
    let loader = document.getElementById('lingvo-loader');
    if (loader) {
        if (hasError) {
            loader.textContent = '❌ Ошибка сети';
            loader.style.background = '#ef4444'; 
        } else {
            loader.textContent = '✅ Готово!';
            loader.style.background = '#10b981'; 
        }
        setTimeout(() => {
            loader.style.opacity = '0';
            setTimeout(() => loader.remove(), 300);
        }, 2000);
    }
}

function restoreWords() {
    const spans = document.querySelectorAll('.lingvo-immersion-word');
    spans.forEach(span => {
        const textNode = document.createTextNode(span.dataset.original);
        span.parentNode.replaceChild(textNode, span);
    });
}

function collectTextNodes(node, textNodes) {
    const skipTags = ['SCRIPT', 'STYLE', 'NOSCRIPT', 'IFRAME', 'CODE', 'PRE', 'A', 'BUTTON', 'INPUT', 'TEXTAREA'];
    if (node.nodeType === Node.TEXT_NODE && node.nodeValue.trim() !== '') {
        textNodes.push(node);
    } else if (node.nodeType === Node.ELEMENT_NODE && !skipTags.includes(node.nodeName)) {
        for (let child of node.childNodes) collectTextNodes(child, textNodes);
    }
}

async function runInBatches(items, batchSize, processFn) {
    const results = [];
    for (let i = 0; i < items.length; i += batchSize) {
        const batch = items.slice(i, i + batchSize);
        for (const item of batch) {
            const res = await processFn(item);
            results.push(res);
        }
    }
    return results;
}

async function translateNodes(nodes, lang, sourceLang, percentage, myRunId) {
    const CHUNK_SIZE = 15; 
    const chunks = [];
    const cacheKey = `dict_${lang}`;
    
    for (let i = 0; i < nodes.length; i += CHUNK_SIZE) {
        chunks.push(nodes.slice(i, i + CHUNK_SIZE));
    }

    let globalError = false;

    await runInBatches(chunks, 1, async (chunkNodes) => {
        if (currentRunId !== myRunId) return;
        
        const texts = chunkNodes.map(n => n.nodeValue.replace(/\n/g, ' '));
        try {
            const response = await chrome.runtime.sendMessage({
                action: 'translateFullText',
                texts: texts,
                lang: lang,
                sourceLang: sourceLang
            });

            if (currentRunId !== myRunId) return;

            if (response && response.translations && !response.translations._error) {
                const toSave = {};
                
                chunkNodes.forEach((node, index) => {
                    const originalText = node.nodeValue;
                    let translatedText = response.translations[index];
                    
                    if (!translatedText || translatedText.trim() === "") translatedText = originalText;
                    
                    const normalizedOriginal = originalText.trim().replace(/\s+/g, ' ');
                    translationCache[normalizedOriginal] = translatedText.trim();
                    toSave[normalizedOriginal] = translatedText.trim();

                    const leadingSpaces = originalText.match(/^\s+/);
                    const trailingSpaces = originalText.match(/\s+$/);
                    
                    if (leadingSpaces) translatedText = leadingSpaces[0] + translatedText.trimStart();
                    if (trailingSpaces) translatedText = translatedText.trimEnd() + trailingSpaces[0];

                    translatedText = fixMixedScriptSpacing(translatedText);

                    const span = document.createElement('span');
                    span.className = 'lingvo-immersion-word full-translation';
                    span.dataset.original = originalText.trim();
                    span.title = `Оригинал: ${originalText.length > 150 ? originalText.substring(0, 150) + '...' : originalText}`;
                    span.textContent = translatedText;
                    
                    node.parentNode.replaceChild(span, node);
                });

                chrome.storage.local.get([cacheKey], (data) => {
                    if (currentRunId !== myRunId) return;
                    const current = data[cacheKey] || {};
                    chrome.storage.local.set({ [cacheKey]: { ...current, ...toSave } });
                });

            } else {
                globalError = true;
            }
        } catch (e) {
            globalError = true;
        }
    });
    
    return globalError;
}

async function runImmersion(percentage, lang) {
    currentRunId++;
    const myRunId = currentRunId;

    showLoader(percentage); 
    restoreWords(); 
    
    const cacheKey = `dict_${lang}`;
    const storageData = await chrome.storage.local.get([cacheKey]);
    if (currentRunId !== myRunId) return;

    translationCache = storageData[cacheKey] || {};

    const textNodes = [];
    collectTextNodes(document.body, textNodes);
    const validNodes = textNodes.filter(node => /[a-zA-Zа-яА-ЯёЁáéíóúñÁÉÍÓÚÑüÜ]/.test(node.nodeValue));

    if (validNodes.length === 0) {
        hideLoader();
        return;
    }

    const sampleText = validNodes.slice(0, 100).map(n => n.nodeValue).join(' ');
    const cyrillicCount = (sampleText.match(/[а-яА-ЯёЁ]/g) || []).length;
    const spanishAccentsCount = (sampleText.match(/[áéíóúñÁÉÍÓÚÑüÜ¡¿]/g) || []).length;
    const latinCount = (sampleText.match(/[a-zA-Z]/g) || []).length;

    let sourceLang = 'en'; 
    if (cyrillicCount > latinCount) {
        sourceLang = 'ru';
    } else if (spanishAccentsCount > 5 || spanishAccentsCount > (latinCount * 0.02)) { 
        sourceLang = 'es';
    }

    if (sourceLang === lang) {
        hideLoader();
        return; 
    }

    let currentTargetWords, wordRegex;
    if (sourceLang === 'ru') {
        currentTargetWords = TARGET_WORDS_RU;
        wordRegex = /([а-яА-ЯёЁ]+)/g;
    } else if (sourceLang === 'es') {
        currentTargetWords = TARGET_WORDS_ES;
        wordRegex = /([a-zA-ZáéíóúñÁÉÍÓÚÑüÜ]+)/g;
    } else {
        currentTargetWords = TARGET_WORDS_EN;
        wordRegex = /([a-zA-Z]+)/g;
    }

    let isError = false;

    if (percentage >= 90) {
        const nodesNeedingTranslation = [];
        
        validNodes.forEach(node => {
            const norm = node.nodeValue.trim().replace(/\s+/g, ' ');
            if (translationCache[norm]) {
                let translatedText = translationCache[norm];
                const originalText = node.nodeValue;
                const leadingSpaces = originalText.match(/^\s+/);
                const trailingSpaces = originalText.match(/\s+$/);
                
                if (leadingSpaces) translatedText = leadingSpaces[0] + translatedText.trimStart();
                if (trailingSpaces) translatedText = translatedText.trimEnd() + trailingSpaces[0];

                const span = document.createElement('span');
                span.className = 'lingvo-immersion-word full-translation';
                span.dataset.original = originalText.trim();
                span.title = `Оригинал: ${originalText.length > 150 ? originalText.substring(0, 150) + '...' : originalText}`;
                span.textContent = translatedText;
                node.parentNode.replaceChild(span, node);
            } else if (Math.random() * 100 <= percentage) {
                nodesNeedingTranslation.push(node);
            }
        });

        if (nodesNeedingTranslation.length > 0) {
            isError = await translateNodes(nodesNeedingTranslation, lang, sourceLang, percentage, myRunId);
            if (currentRunId !== myRunId) return;
            hideLoader(isError);
        } else {
            if (currentRunId !== myRunId) return;
            hideLoader();
        }
        return;
    }

    const itemsToTranslate = new Set();
    const replacements = [];
    const isPhraseMode = percentage >= 70;

    const pTarget = percentage <= 30 ? (percentage / 30) : 1.0;
    const pOther = percentage <= 30 ? 0 : (percentage - 30) / 100; 
    const phraseRegex = /([^.,!?;:\n]+[.,!?;:\n]*)/g;

    validNodes.forEach(node => {
        const text = node.nodeValue;
        let match;
        
        if (isPhraseMode) {
            while ((match = phraseRegex.exec(text)) !== null) {
                const phrase = match[0];
                if (/[a-zA-Zа-яА-ЯёЁáéíóúñÁÉÍÓÚÑüÜ]/.test(phrase) && Math.random() * 100 <= percentage) {
                    const trimmedPhrase = phrase.trim();
                    const normalizedPhrase = trimmedPhrase.replace(/\s+/g, ' '); 
                    if (!translationCache[normalizedPhrase]) itemsToTranslate.add(normalizedPhrase);
                    replacements.push({ node: node, word: phrase, cacheKey: normalizedPhrase, index: match.index });
                }
            }
        } else {
            while ((match = wordRegex.exec(text)) !== null) {
                const word = match[0];
                const lowerWord = word.toLowerCase();
                const prob = currentTargetWords.includes(lowerWord) ? pTarget : pOther;

                if (Math.random() <= prob) {
                    if (!translationCache[lowerWord]) {
                        const offlineTranslation = getOfflineTranslation(lowerWord, sourceLang, lang);
                        if (offlineTranslation) {
                            translationCache[lowerWord] = offlineTranslation;
                        } else {
                            itemsToTranslate.add(lowerWord);
                        }
                    }
                    replacements.push({ node: node, word: word, cacheKey: lowerWord, index: match.index });
                }
            }
        }
    });

    if (itemsToTranslate.size > 0) {
        const newItemsArray = Array.from(itemsToTranslate);
        const CHUNK_SIZE = isPhraseMode ? 15 : 100; 
        const chunks = [];
        
        for (let i = 0; i < newItemsArray.length; i += CHUNK_SIZE) {
            chunks.push(newItemsArray.slice(i, i + CHUNK_SIZE));
        }

        await runInBatches(chunks, 1, async (chunk) => {
            if (currentRunId !== myRunId) return;
            try {
                const response = await chrome.runtime.sendMessage({
                    action: isPhraseMode ? 'translateFullText' : 'translateBulk',
                    texts: isPhraseMode ? chunk : undefined,
                    words: !isPhraseMode ? chunk : undefined,
                    lang: lang,
                    sourceLang: sourceLang
                });

                if (currentRunId !== myRunId) return;

                if (response && response.translations) {
                    if (response.translations._error) {
                        isError = true;
                        return;
                    }
                    if (isPhraseMode && Array.isArray(response.translations)) {
                        chunk.forEach((orig, idx) => {
                            if (response.translations[idx]) translationCache[orig] = response.translations[idx];
                        });
                    } else if (!isPhraseMode) {
                        Object.assign(translationCache, response.translations);
                    }
                }
            } catch (e) {
                isError = true;
            }
        });
    }

    if (currentRunId !== myRunId) return;
    
    // ТЕПЕРЬ СОХРАНЯЕМ ВЕСЬ КЭШ В ПАМЯТЬ БРАУЗЕРА (включая оффлайн-переводы)
    await chrome.storage.local.set({ [cacheKey]: translationCache });

    const nodeMap = new Map();
    replacements.forEach(rep => {
        if (!nodeMap.has(rep.node)) nodeMap.set(rep.node, []);
        nodeMap.get(rep.node).push(rep);
    });

    for (let [node, reps] of nodeMap) {
        reps.sort((a, b) => b.index - a.index);
        let currentText = node.nodeValue;
        const fragments = [];
        let lastCut = currentText.length;

        reps.forEach(rep => {
            let translated = translationCache[rep.cacheKey];
            if (!translated || translated.trim() === "") return;

            if (isPhraseMode) {
                const leadingSpaces = rep.word.match(/^\s+/);
                const trailingSpaces = rep.word.match(/\s+$/);
                if (leadingSpaces) translated = leadingSpaces[0] + translated.trimStart();
                if (trailingSpaces) translated = translated.trimEnd() + trailingSpaces[0];
            } else {
                if (rep.word[0] === rep.word[0].toUpperCase()) {
                    translated = translated.charAt(0).toUpperCase() + translated.slice(1);
                }
            }

            translated = fixMixedScriptSpacing(translated);

            fragments.unshift(document.createTextNode(currentText.substring(rep.index + rep.word.length, lastCut)));
            const span = document.createElement('span');
            span.className = isPhraseMode ? 'lingvo-immersion-word full-translation' : 'lingvo-immersion-word';
            const originalTrimmed = rep.word.trim();
            span.dataset.original = originalTrimmed;
            span.title = `Оригинал: ${originalTrimmed.length > 150 ? originalTrimmed.substring(0, 150) + '...' : originalTrimmed}`;
            span.textContent = translated;
            fragments.unshift(span);
            lastCut = rep.index;
        });

        fragments.unshift(document.createTextNode(currentText.substring(0, lastCut)));
        const parent = node.parentNode;
        fragments.forEach(frag => parent.insertBefore(frag, node));
        parent.removeChild(node);
    }
    
    if (percentage <= 30 && isError) isError = false; 
    hideLoader(isError); 
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'apply') {
        if (request.enabled !== false) {
            runImmersion(request.percentage, request.lang);
        } else {
            restoreWords();
        }
    }
});

let hasRunAuto = false;
let autoRunTimeout = null;

function attemptAutoRun(settings, attemptsLeft = 5) {
    if (hasRunAuto) return; 

    const textNodes = [];
    collectTextNodes(document.body, textNodes);
    const validNodes = textNodes.filter(node => /[a-zA-Zа-яА-ЯёЁáéíóúñÁÉÍÓÚÑüÜ]/.test(node.nodeValue));

    if (validNodes.length > 30 || attemptsLeft === 0) {
        hasRunAuto = true; 
        if (validNodes.length > 0) {
            runImmersion(settings.percentage || 10, settings.lang || 'en');
        }
    } else {
        autoRunTimeout = setTimeout(() => attemptAutoRun(settings, attemptsLeft - 1), 1000);
    }
}

function init() {
    chrome.storage.sync.get(['lang', 'percentage', 'autoRun', 'blacklist'], (settings) => {
        const domain = window.location.hostname;
        const blacklist = settings.blacklist || [];
        const autoRun = settings.autoRun !== false; 

        if (autoRun && !blacklist.includes(domain)) {
            clearTimeout(autoRunTimeout);
            if (document.readyState === 'complete' || document.readyState === 'interactive') {
                setTimeout(() => attemptAutoRun(settings), 500);
            } else {
                window.addEventListener('DOMContentLoaded', () => {
                    setTimeout(() => attemptAutoRun(settings), 500);
                });
            }
        }
    });
}

let lastUrl = location.href; 
new MutationObserver(() => {
  const url = location.href;
  if (url !== lastUrl) {
    lastUrl = url;
    hasRunAuto = false; 
    init(); 
  }
}).observe(document, {subtree: true, childList: true});

init();