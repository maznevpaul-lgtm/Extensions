const translations = {
    ru: {
        title: "Языковое погружение",
        langLabel: "Изучаемый язык:",
        langRu: "Русский 🇷🇺",
        langEn: "Английский 🇬🇧",
        langEs: "Испанский 🇪🇸",
        percentLabel: "Процент замены:",
        applyBtn: "Применить к странице",
        sitePowerLabel: "На этом сайте",
        autoRunLabel: "Автоперевод",
        dictTitle: "Управление словарем:",
        exportBtn: "Скачать",
        importBtn: "Загрузить",
        clearBtn: "Очистить",
        confirmClear: "Точно?"
    },
    en: {
        title: "Language Immersion",
        langLabel: "Target Language:",
        langRu: "Russian 🇷🇺",
        langEn: "English 🇬🇧",
        langEs: "Spanish 🇪🇸",
        percentLabel: "Replacement rate:",
        applyBtn: "Apply to page",
        sitePowerLabel: "On this site",
        autoRunLabel: "Auto-translate",
        dictTitle: "Dictionary Management:",
        exportBtn: "Export",
        importBtn: "Import",
        clearBtn: "Clear",
        confirmClear: "Sure?"
    }
};

function getMsg(key) {
    const userLang = navigator.language.startsWith('ru') ? 'ru' : 'en';
    return translations[userLang][key] || key;
}