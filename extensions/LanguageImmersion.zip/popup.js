document.addEventListener('DOMContentLoaded', () => {
    // Подгрузка перевода интерфейса
    document.getElementById('titleText').textContent = getMsg("title");
    document.getElementById('langLabelText').textContent = getMsg("langLabel");
    document.getElementById('langRuText').textContent = getMsg("langRu");
    document.getElementById('langEnText').textContent = getMsg("langEn");
    document.getElementById('langEsText').textContent = getMsg("langEs");
    document.getElementById('percentLabelText').textContent = getMsg("percentLabel");
    document.getElementById('applyBtn').textContent = getMsg("applyBtn");
    document.getElementById('autoRunLabel').textContent = getMsg("autoRunLabel");
    document.getElementById('dictTitleText').textContent = getMsg("dictTitle");
    document.getElementById('exportBtn').textContent = getMsg("exportBtn");
    document.getElementById('importBtn').textContent = getMsg("importBtn");
    document.getElementById('clearBtn').textContent = getMsg("clearBtn");

    const sitePowerSwitch = document.getElementById('sitePowerSwitch');
    const autoRunSwitch = document.getElementById('autoRunSwitch');
    const languageSelect = document.getElementById('languageSelect');
    const percentRange = document.getElementById('percentRange');
    const percentValue = document.getElementById('percentValue');
    const applyBtn = document.getElementById('applyBtn');
    const dictStatus = document.getElementById('dictStatus');
    const sitePowerLabel = document.getElementById('sitePowerLabel');

    let currentHostname = "";

    function showDictStatus(message, color) {
        dictStatus.textContent = message;
        dictStatus.style.color = color;
        setTimeout(() => { dictStatus.textContent = ''; }, 3000);
    }

    // Получаем текущий сайт
    try {
        chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
            if (tabs[0] && tabs[0].url && !tabs[0].url.startsWith('chrome://')) {
                try {
                    const url = new URL(tabs[0].url);
                    currentHostname = url.hostname;
                    sitePowerLabel.textContent = currentHostname;
                } catch(e) {}
            }
        });

        // Загрузка сохраненных настроек
        chrome.storage.sync.get(['lang', 'percentage', 'autoRun', 'blacklist'], (data) => {
            if (chrome.runtime.lastError) return;
            languageSelect.value = data.lang || 'en';
            percentRange.value = data.percentage || 10;
            percentValue.textContent = percentRange.value + '%';
            autoRunSwitch.checked = data.autoRun !== false; // По умолчанию включено
            
            const blacklist = data.blacklist || [];
            if (currentHostname) {
                // Если домен в черном списке - переключатель ВЫКЛЮЧЕН
                sitePowerSwitch.checked = !blacklist.includes(currentHostname);
            } else {
                sitePowerSwitch.checked = true;
            }
        });
    } catch (e) {
        console.warn("Context invalidated");
    }

    percentRange.addEventListener('input', () => {
        percentValue.textContent = percentRange.value + '%';
    });

    // Моментальное сохранение умных переключателей
    sitePowerSwitch.addEventListener('change', saveToggles);
    autoRunSwitch.addEventListener('change', saveToggles);

    function saveToggles() {
        try {
            chrome.storage.sync.get(['blacklist'], (data) => {
                if (chrome.runtime.lastError) return;
                let blacklist = data.blacklist || [];
                if (currentHostname) {
                    if (!sitePowerSwitch.checked && !blacklist.includes(currentHostname)) {
                        blacklist.push(currentHostname); // Добавляем в черный список
                    } else if (sitePowerSwitch.checked && blacklist.includes(currentHostname)) {
                        blacklist = blacklist.filter(domain => domain !== currentHostname); // Удаляем из черного списка
                    }
                }
                chrome.storage.sync.set({ autoRun: autoRunSwitch.checked, blacklist: blacklist });
            });
        } catch(e) {
            showDictStatus("Обновите страницу (F5)", "#ef4444");
        }
    }

    // Кнопка "Применить к странице"
    applyBtn.addEventListener('click', () => {
        try {
            saveToggles();
            const settings = {
                lang: languageSelect.value,
                percentage: parseInt(percentRange.value)
            };

            chrome.storage.sync.set(settings, () => {
                chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
                    if (tabs[0] && !tabs[0].url.startsWith('chrome://')) {
                        chrome.tabs.sendMessage(tabs[0].id, {
                            action: 'apply',
                            enabled: sitePowerSwitch.checked, 
                            ...settings
                        });
                    }
                });
            });
        } catch(e) {
            showDictStatus("Обновите страницу (F5)", "#ef4444");
        }
    });

    // === ЭКСПОРТ СЛОВАРЯ ===
    document.getElementById('exportBtn').addEventListener('click', () => {
        try {
            const lang = languageSelect.value;
            const cacheKey = `dict_${lang}`;
            
            chrome.storage.local.get([cacheKey], (data) => {
                if (chrome.runtime.lastError) return;
                const dict = data[cacheKey] || {};
                
                // --- УМНЫЙ ФИЛЬТР ---
                // Очищаем экспорт от длинных предложений и кусков с кавычками, оставляем только слова
                const cleanDict = {};
                for (const key in dict) {
                    // Считаем количество слов
                    const wordsCount = key.trim().split(/\s+/).length;
                    
                    // Оставляем только если: от 1 до 3 слов, нет кавычек, скобок и спецсимволов
                    if (wordsCount <= 3 && !/[”"«»\(\)\[\]\:\-\_]/.test(key) && key.trim().length > 1) {
                        cleanDict[key] = dict[key];
                    }
                }

                if (Object.keys(cleanDict).length === 0) {
                    showDictStatus(getMsg("title") === "Language Immersion" ? "No clear words" : "Нет чистых слов", "#f59e0b");
                    return;
                }
                
                const blob = new Blob([JSON.stringify(cleanDict, null, 2)], {type: "application/json"});
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `immersion_dict_${lang}_clean.json`;
                a.click();
                URL.revokeObjectURL(url);
                showDictStatus(getMsg("title") === "Language Immersion" ? `Exported (${Object.keys(cleanDict).length})!` : `Скачан (${Object.keys(cleanDict).length})!`, "#10b981");
            });
        } catch(e) {}
    });

    // ИМПОРТ
    document.getElementById('importBtn').addEventListener('click', () => document.getElementById('importFile').click());
    document.getElementById('importFile').addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = (event) => {
            try {
                const importedDict = JSON.parse(event.target.result);
                const lang = languageSelect.value;
                const cacheKey = `dict_${lang}`;
                
                chrome.storage.local.get([cacheKey], (data) => {
                    if (chrome.runtime.lastError) return;
                    const currentDict = data[cacheKey] || {};
                    const mergedDict = { ...currentDict, ...importedDict };
                    chrome.storage.local.set({ [cacheKey]: mergedDict }, () => {
                        showDictStatus(getMsg("title") === "Language Immersion" ? `Imported (${Object.keys(importedDict).length})!` : `Загружено (${Object.keys(importedDict).length})!`, "#10b981");
                    });
                });
            } catch(err) {
                showDictStatus(getMsg("title") === "Language Immersion" ? "File error!" : "Ошибка!", "#ef4444");
            }
        };
        reader.readAsText(file);
        e.target.value = '';
    });

    // ОЧИСТКА СЛОВАРЯ
    let clearConfirmTimer = null;
    document.getElementById('clearBtn').addEventListener('click', (e) => {
        if (e.target.textContent === getMsg("confirmClear")) {
            const lang = languageSelect.value;
            const cacheKey = `dict_${lang}`;
            chrome.storage.local.remove(cacheKey, () => {
                showDictStatus(getMsg("title") === "Language Immersion" ? "Cleared!" : "Очищено!", "#ef4444");
                e.target.textContent = getMsg("clearBtn");
            });
        } else {
            e.target.textContent = getMsg("confirmClear");
            clearTimeout(clearConfirmTimer);
            clearConfirmTimer = setTimeout(() => {
                e.target.textContent = getMsg("clearBtn");
            }, 3000);
        }
    });
});