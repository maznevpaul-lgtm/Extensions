chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'translateBulk') {
        translateWords(request.words, request.lang, request.sourceLang)
            .then(translations => sendResponse({ translations }))
            .catch(error => sendResponse({ translations: { _error: true } }));
        return true; 
    } else if (request.action === 'translateFullText') {
        translateFullTexts(request.texts, request.lang, request.sourceLang)
            .then(translations => sendResponse({ translations }))
            .catch(error => sendResponse({ translations: { _error: true } }));
        return true;
    }
});

// УМНАЯ ФУНКЦИЯ: По очереди перебирает бесплатные сервисы, пока не получит перевод
async function getTranslationString(query, targetLang, sourceLang) {
    let lastError = null;

    // --- УРОВЕНЬ 1: Разные скрытые шлюзы Google ---
    const googleClients = ['gtx', 'dict-chrome-ex', 'te', 'webapp'];
    for (const client of googleClients) {
        const url = `https://translate.googleapis.com/translate_a/single?client=${client}&sl=${sourceLang}&tl=${targetLang}&dt=t`;
        try {
            const response = await fetch(url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({ q: query })
            });
            
            const textData = await response.text();

            // Если Google вернул капчу или страницу ошибки вместо перевода
            if (textData.trim().startsWith('<')) {
                lastError = new Error(`HTML response (Captcha) on Google ${client}`);
                continue; // Идем к следующему серверу
            }
            if (!response.ok) {
                lastError = new Error(`HTTP ${response.status}`);
                continue;
            }

            const data = JSON.parse(textData);
            let fullTranslation = "";
            if (data && data[0]) {
                data[0].forEach(chunk => { if (chunk[0]) fullTranslation += chunk[0]; });
            }
            return fullTranslation;
        } catch (e) {
            lastError = e;
        }
    }

    // --- УРОВЕНЬ 2: Сторонние прокси-сервера (Lingva Translate) ---
    if (query.length < 1500) {
        const lingvaInstances = ['https://lingva.ml', 'https://lingva.pussthecat.org'];
        for (const instance of lingvaInstances) {
            const url = `${instance}/api/v1/${sourceLang}/${targetLang}/${encodeURIComponent(query)}`;
            try {
                const response = await fetch(url);
                if (!response.ok) {
                    lastError = new Error(`Lingva API Error ${response.status}`);
                    continue;
                }
                const data = await response.json();
                if (data && data.translation) {
                    console.log("Успешный перевод через Lingva Proxy!");
                    return data.translation;
                }
            } catch(e) {
                lastError = e;
            }
        }
    }

    // --- УРОВЕНЬ 3: Совершенно другой переводчик (MyMemory Translation) ---
    if (query.length < 400) {
        const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(query)}&langpair=${sourceLang}|${targetLang}`;
        try {
            const response = await fetch(url);
            const data = await response.json();
            if (data && data.responseData && data.responseData.translatedText) {
                if (!data.responseData.translatedText.includes("MYMEMORY WARNING")) {
                    console.log("Успешный перевод через MyMemory API!");
                    return data.responseData.translatedText;
                }
            }
        } catch(e) {
            lastError = e;
        }
    }

    throw lastError; // Выдаст ошибку, только если упали вообще ВСЕ сервисы
}

async function translateSingle(text, targetLang, sourceLang) {
    if (!text.trim()) return text;
    try {
        const translation = await getTranslationString(text, targetLang, sourceLang);
        return translation.trim() || text;
    } catch (e) {
        return text; // При полной неудаче возвращаем оригинал
    }
}

async function translateWords(wordsArray, targetLang, sourceLang = 'auto') {
    if (!wordsArray || wordsArray.length === 0) return {};
    const query = wordsArray.join('\n');

    try {
        const fullTranslation = await getTranslationString(query, targetLang, sourceLang);
        const translatedArray = fullTranslation.split('\n').map(w => w.trim().toLowerCase());
        const resultDict = {};

        if (translatedArray.length === wordsArray.length) {
            wordsArray.forEach((sourceWord, index) => {
                if (translatedArray[index]) resultDict[sourceWord] = translatedArray[index].replace(/[.,]/g, '');
            });
        } else {
            for (const word of wordsArray) {
                const tr = await translateSingle(word, targetLang, sourceLang);
                resultDict[word] = tr.toLowerCase().replace(/[.,]/g, '');
            }
        }
        return resultDict;
    } catch (e) {
        console.warn("Массовый перевод упал, пробуем по одному слову...", e);
        const resultDict = {};
        let hasSuccess = false;
        for (const word of wordsArray) {
            const tr = await translateSingle(word, targetLang, sourceLang);
            if (tr !== word) hasSuccess = true;
            resultDict[word] = tr.toLowerCase().replace(/[.,]/g, '');
        }
        return hasSuccess ? resultDict : { _error: true };
    }
}

async function translateFullTexts(textsArray, targetLang, sourceLang = 'auto') {
    if (!textsArray || textsArray.length === 0) return [];
    
    const delimiter = '\n\n===||===\n\n';
    const query = textsArray.join(delimiter);

    try {
        const fullTranslation = await getTranslationString(query, targetLang, sourceLang);
        
        // Гибкое разделение (так как сторонние API могут исказить пробелы у разделителя)
        const translatedArray = fullTranslation.split(/\s*(?:=== *\|\| *===|=== *\| *\| *===|===.*?===)\s*/);

        if (translatedArray.length === textsArray.length) {
            return translatedArray.map(w => w.trim());
        } else {
            console.warn("Разделители сломались. Запущен поштучный безопасный перевод.");
            const safeTranslations = [];
            for (const text of textsArray) {
                const tr = await translateSingle(text, targetLang, sourceLang);
                safeTranslations.push(tr);
            }
            return safeTranslations;
        }
    } catch (e) {
        console.warn("Массовый перевод текста упал, пробуем по одному...", e);
        const safeTranslations = [];
        let hasSuccess = false;
        for (const text of textsArray) {
            const tr = await translateSingle(text, targetLang, sourceLang);
            if (tr !== text) hasSuccess = true;
            safeTranslations.push(tr);
        }
        return hasSuccess ? safeTranslations : { _error: true };
    }
}